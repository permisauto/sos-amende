"use client";

import { useRef, useState } from "react";
import Link from "next/link";

type Resultat = { titreFaille: string | null; articleLoi: string | null; score: number; proposition: boolean };
type Preuves = { radar: { checked: boolean; found: boolean; expired: boolean | null; preuveUrl: string | null }; meteo: { checked: boolean; value: string | null; source: string | null }; travaux: { checked: boolean; value: boolean | null }; dureeMs: number };
type Reponse = { scoreGlobal?: number; resultats?: Resultat[]; data?: Record<string, unknown>; texte?: string; erreur?: string; preuves?: Preuves };

export function DeposerClient({ initialType }: { initialType: "AMENDE" | "SUSPENSION" }) {
  const [type, setType] = useState<"AMENDE" | "SUSPENSION">(initialType);
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [infos, setInfos] = useState({ plaque: "", num_pv: "", date: "", montant: "", heure: "", adresse: "", lieu: "", prefecture: "", duree: "", motif: "" });
  const [complement, setComplement] = useState({ paiementDejaFait: false, vehiculeCede: false, vehiculeVole: false, conducteurDifferent: false, plaqueIncorrecte: false, travaux: false, meteoPluie: false, adresseIncorrecte: false });
  const [showComplement, setShowComplement] = useState(true);
  const [loading, setLoading] = useState(false);
  const [autoFilling, setAutoFilling] = useState(false);
  const [reponse, setReponse] = useState<Reponse | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  async function handleFileChange(f: File | null) {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setFile(f);
    if (f?.type.startsWith("image/")) setPreviewUrl(URL.createObjectURL(f));
    else setPreviewUrl(null);
    if (!f) return;
    // Questions ouvertes dès le départ pour un scoring complet
    setShowComplement(true);
    if (f.size > 8 * 1024 * 1024) {
      setReponse({ erreur: "Fichier trop volumineux (8 Mo max). Réduisez la qualité photo dans les réglages de l'appareil." });
      return;
    }
    setAutoFilling(true);
    setReponse(null);
    try {
      // Upload -> OCR extrait les données ET lance directement le scan/scoring (une seule requête)
      const fd = new FormData();
      fd.set("type", type);
      fd.set("pv", f);
      const res = await fetch("/api/demo/analyse", { method: "POST", body: fd });
      const body = (await res.json()) as Reponse & { data?: Record<string, string> };
      if (body.data) {
        setInfos((prev) => ({
          plaque: (body.data?.plaque as string) || prev.plaque,
          num_pv: (body.data?.num_pv as string) || prev.num_pv,
          date: (body.data?.date as string) || prev.date,
          montant: (body.data?.montant as string) || prev.montant,
          heure: (body.data?.heure as string) || prev.heure,
          adresse: (body.data?.adresse as string) || prev.adresse,
          lieu: (body.data?.lieu as string) || prev.lieu,
          prefecture: (body.data?.prefecture as string) || prev.prefecture,
          duree: (body.data?.duree as string) || prev.duree,
          motif: (body.data?.motif as string) || prev.motif,
        }));
      }
      // L'OCR a extrait -> on affiche directement le scoring (l'utilisateur vérifie ensuite)
      if (body.scoreGlobal !== undefined || body.resultats) {
        setReponse(body);
        if (body.data) sessionStorage.setItem("deposer_data", JSON.stringify({ type, data: body.data, scoreGlobal: body.scoreGlobal, resultats: body.resultats }));
      }
    } catch {}
    finally { setAutoFilling(false); }
  }

  async function handleScan() {
    setLoading(true);
    setReponse(null);
    try {
      const fd = new FormData();
      fd.set("type", type);
      if (file) fd.set("pv", file);
      Object.entries(infos).forEach(([k, v]) => v && fd.set(k, v));
      // Questions complémentaires dynamiques (affinent le scoring)
      if (complement.paiementDejaFait) fd.set("paiementDejaFait", "on");
      if (complement.vehiculeCede) fd.set("vehiculeCede", "on");
      if (complement.vehiculeVole) fd.set("vehiculeVole", "on");
      if (complement.conducteurDifferent) fd.set("conducteurDifferent", "on");
      if (complement.plaqueIncorrecte) fd.set("plaqueIncorrecte", "on");
      if (complement.travaux) fd.set("travaux_présents", "true");
      if (complement.meteoPluie) fd.set("conditions_meteo", "Pluie");
      if (complement.adresseIncorrecte) fd.set("adresseIncorrecte", "on");
      // Réutilise l'API démo (scan réel si fichier fourni, sans stockage)
      const res = await fetch("/api/demo/analyse", { method: "POST", body: fd });
      const body = (await res.json()) as Reponse;
      setReponse(body);
      if (body.data) {
        sessionStorage.setItem("deposer_data", JSON.stringify({ type, data: body.data, scoreGlobal: body.scoreGlobal, resultats: body.resultats }));
      }
    } catch {
      setReponse({ erreur: "Erreur lors du scan." });
    } finally {
      setLoading(false);
    }
  }

  const hasResult = reponse && (reponse.scoreGlobal !== undefined || reponse.resultats);

  return (
    <div className="flex flex-col gap-6">
      <div className="rounded-2xl border border-zinc-200 bg-white p-6">
        <label className="flex flex-col gap-1.5">
          <span className="text-sm font-medium">Type</span>
          <select value={type} onChange={(e) => setType(e.target.value as never)} className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm">
            <option value="AMENDE">Amende</option>
            <option value="SUSPENSION">Suspension de permis</option>
          </select>
        </label>

        <div className="mt-4">
          <p className="text-sm font-medium">Téléverser avec votre smartphone — scan auto</p>
          <p className="text-xs text-zinc-500">Cadrez bien le PV, lumière uniforme, évitez le flou. Le formulaire se pré-remplit seul.</p>
          <div
            role="button"
            tabIndex={0}
            onClick={() => inputRef.current?.click()}
            onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") inputRef.current?.click(); }}
            className={`mt-3 flex cursor-pointer flex-col items-center gap-3 rounded-2xl border-2 border-dashed p-6 text-center transition ${autoFilling ? "border-emerald-400 bg-emerald-50" : "border-zinc-300 bg-zinc-50 hover:border-emerald-400"}`}
          >
            <input
              ref={inputRef}
              type="file"
              accept="image/*,application/pdf"
              capture="environment"
              className="hidden"
              onChange={(e) => handleFileChange(e.target.files?.[0] ?? null)}
            />
            {previewUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={previewUrl} alt="Aperçu PV" className="max-h-48 rounded-xl object-contain shadow" />
            ) : (
              <span className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-600 text-2xl text-white" aria-hidden>📷</span>
            )}
            {file ? (
              <>
                <p className="text-sm font-medium text-zinc-800">{file.name} — {(file.size / 1024).toFixed(0)} Ko</p>
                <button type="button" onClick={(e) => { e.stopPropagation(); handleFileChange(null); }} className="text-xs font-medium text-emerald-700 hover:underline">Changer de photo</button>
              </>
            ) : (
              <>
                <p className="text-sm font-medium text-zinc-700">Appuyez pour scanner avec votre smartphone</p>
                <p className="text-xs text-zinc-500">Photo ou PDF — JPEG/PNG/WebP/PDF, 8 Mo max. La numérisation sécurisée capte les infos dès l'upload.</p>
              </>
            )}
            {autoFilling && (
              <span className="inline-flex items-center gap-2 rounded-full bg-emerald-600 px-3 py-1 text-xs font-semibold text-white">
                <span className="h-3 w-3 animate-spin rounded-full border-2 border-white border-t-transparent" /> Numérisation en cours — pré-remplissage…
              </span>
            )}
          </div>
        </div>

        <div className="mt-2 rounded-xl bg-amber-50 px-3 py-2 text-xs text-amber-800">
          La numérisation sécurisée extrait les données dès le téléversement et lance le scan. Vérifiez les champs pré-remplis ci-dessous, corrigez si besoin, puis validez.
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <label className="flex flex-col gap-1 sm:col-span-2"><span className="text-xs font-medium">Adresse {type === "SUSPENSION" ? "(titulaire / préfecture)" : "(titulaire)"} — vérifiable {infos.adresse && <span className="text-emerald-600">✓ pré-rempli</span>}</span><input value={infos.adresse} onChange={(e) => setInfos({ ...infos, adresse: e.target.value })} placeholder="12 rue de Paris, 75001 Paris" className={`rounded-xl border px-3 py-2 text-sm ${infos.adresse ? "border-emerald-300 bg-emerald-50" : "border-zinc-300"}`} /></label>
          <label className="flex flex-col gap-1"><span className="text-xs font-medium">Lieu {type === "SUSPENSION" ? "de la rétention" : "de l'infraction"} {infos.lieu && <span className="text-emerald-600">✓ pré-rempli</span>}</span><input value={infos.lieu} onChange={(e) => setInfos({ ...infos, lieu: e.target.value })} placeholder={type === "SUSPENSION" ? "Route, préfecture" : "Avenue, ville"} className={`rounded-xl border px-3 py-2 text-sm ${infos.lieu ? "border-emerald-300 bg-emerald-50" : "border-zinc-300"}`} /></label>
          <label className="flex flex-col gap-1"><span className="text-xs font-medium">Plaque {type === "SUSPENSION" ? "(si mentionnée)" : ""} {infos.plaque && <span className="text-emerald-600">✓ pré-rempli</span>}</span><input value={infos.plaque} onChange={(e) => setInfos({ ...infos, plaque: e.target.value })} placeholder="AB-123-CD" className={`rounded-xl border px-3 py-2 text-sm ${infos.plaque ? "border-emerald-300 bg-emerald-50" : "border-zinc-300"}`} /></label>
          <label className="flex flex-col gap-1"><span className="text-xs font-medium">N° PV / décision {infos.num_pv && <span className="text-emerald-600">✓ pré-rempli</span>}</span><input value={infos.num_pv} onChange={(e) => setInfos({ ...infos, num_pv: e.target.value })} className={`rounded-xl border px-3 py-2 text-sm ${infos.num_pv ? "border-emerald-300 bg-emerald-50" : "border-zinc-300"}`} /></label>
          <label className="flex flex-col gap-1"><span className="text-xs font-medium">Date {infos.date && <span className="text-emerald-600">✓ pré-rempli</span>}</span><input type="date" value={infos.date} onChange={(e) => setInfos({ ...infos, date: e.target.value })} className={`rounded-xl border px-3 py-2 text-sm ${infos.date ? "border-emerald-300 bg-emerald-50" : "border-zinc-300"}`} /></label>
          {type === "AMENDE" ? (
            <label className="flex flex-col gap-1"><span className="text-xs font-medium">Montant / Heure {infos.montant && <span className="text-emerald-600">✓ pré-rempli</span>}</span><input value={infos.montant} onChange={(e) => setInfos({ ...infos, montant: e.target.value })} placeholder="135 € ou 14h32" className={`rounded-xl border px-3 py-2 text-sm ${infos.montant ? "border-emerald-300 bg-emerald-50" : "border-zinc-300"}`} /></label>
          ) : (
            <>
              <label className="flex flex-col gap-1"><span className="text-xs font-medium">Préfecture {infos.prefecture && <span className="text-emerald-600">✓ pré-rempli</span>}</span><input value={infos.prefecture} onChange={(e) => setInfos({ ...infos, prefecture: e.target.value })} placeholder="Préfecture de…" className={`rounded-xl border px-3 py-2 text-sm ${infos.prefecture ? "border-emerald-300 bg-emerald-50" : "border-zinc-300"}`} /></label>
              <label className="flex flex-col gap-1"><span className="text-xs font-medium">Durée / Motif {infos.duree && <span className="text-emerald-600">✓ pré-rempli</span>}</span><input value={infos.duree || infos.motif} onChange={(e) => setInfos({ ...infos, duree: e.target.value })} placeholder="6 mois, alcool" className="rounded-xl border border-zinc-300 px-3 py-2 text-sm" /></label>
            </>
          )}
        </div>

        <div className="mt-6 rounded-2xl border border-zinc-200 bg-zinc-50 p-4">
          <button type="button" onClick={() => setShowComplement(!showComplement)} className="flex w-full items-center justify-between text-left">
            <span className="text-sm font-semibold text-zinc-800">Questions complémentaires — scan très complet {showComplement ? "▼" : "▶"}</span>
            <span className="text-xs text-zinc-500">{showComplement ? "Masquer" : "Afficher"} — affinent le scoring</span>
          </button>
          {showComplement && (
            <div className="mt-4 grid gap-2.5">
              {type === "AMENDE" ? (
                <>
                  <label className="flex items-start gap-2 text-sm"><input type="checkbox" checked={complement.paiementDejaFait} onChange={(e) => setComplement({ ...complement, paiementDejaFait: e.target.checked })} className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-emerald-600" /> J'ai déjà payé cette amende</label>
                  <label className="flex items-start gap-2 text-sm"><input type="checkbox" checked={complement.vehiculeCede} onChange={(e) => setComplement({ ...complement, vehiculeCede: e.target.checked })} className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-emerald-600" /> Véhicule vendu/cédé avant la date</label>
                  <label className="flex items-start gap-2 text-sm"><input type="checkbox" checked={complement.vehiculeVole} onChange={(e) => setComplement({ ...complement, vehiculeVole: e.target.checked })} className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-emerald-600" /> Véhicule volé / plaque usurpée</label>
                  <label className="flex items-start gap-2 text-sm"><input type="checkbox" checked={complement.conducteurDifferent} onChange={(e) => setComplement({ ...complement, conducteurDifferent: e.target.checked })} className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-emerald-600" /> Je n'étais pas au volant</label>
                  <label className="flex items-start gap-2 text-sm"><input type="checkbox" checked={complement.plaqueIncorrecte} onChange={(e) => setComplement({ ...complement, plaqueIncorrecte: e.target.checked })} className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-emerald-600" /> Plaque sur PV incorrecte</label>
                  <label className="flex items-start gap-2 text-sm"><input type="checkbox" checked={complement.adresseIncorrecte} onChange={(e) => setComplement({ ...complement, adresseIncorrecte: e.target.checked })} className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-emerald-600" /> Adresse/lieu sur PV incorrect</label>
                </>
              ) : (
                <>
                  {/* Aucun questionnaire SUSPENSION : il faudrait envoyer des
                      champs qui n'existent pas. Avant correction, « Notification
                      LRAR non reçue » partait en vehiculeCede et « Erreur sur la
                      décision » en plaqueIncorrecte — de fausses déclarations
                      pour le juriste. Règle alignée sur analyse-form.tsx. */}
                  <p className="text-xs text-zinc-600">
                    Le questionnaire ciblé (paiement, cession, vol, conducteur)
                    s&apos;applique aux amendes. Pour une suspension de permis, le
                    juriste examinera les motifs de la décision à partir des
                    informations saisies.
                  </p>
                </>
              )}
              <label className="flex items-start gap-2 text-sm"><input type="checkbox" checked={complement.travaux} onChange={(e) => setComplement({ ...complement, travaux: e.target.checked })} className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-emerald-600" /> Travaux présents sur la route ce jour-là</label>
              <label className="flex items-start gap-2 text-sm"><input type="checkbox" checked={complement.meteoPluie} onChange={(e) => setComplement({ ...complement, meteoPluie: e.target.checked })} className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-emerald-600" /> Conditions météo défavorables (pluie/brouillard)</label>
              <p className="text-xs text-zinc-500">Ces réponses sont transmises au juriste comme contexte. Le moteur croise failles + preuves via API.</p>

            </div>
          )}
        </div>

        <button onClick={handleScan} disabled={loading || autoFilling} className="mt-6 w-full rounded-full bg-emerald-600 px-6 py-3 font-semibold text-white hover:bg-emerald-700 disabled:opacity-50">
          {loading ? "Numérisation en cours…" : autoFilling ? "Numérisation en cours…" : hasResult ? "Re-vérifier et relancer le scoring complet" : "Vérifier et valider — lancer le scoring complet"}
        </button>
        <p className="mt-2 text-center text-xs text-zinc-500">Le scan s'est lancé automatiquement à l'upload. Répondez aux questions complémentaires pour un scan dynamique et complet, puis re-validez. Aucun email demandé — analyse gratuite.</p>
      </div>

      {hasResult && (
        <div className="flex flex-col gap-4">
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-6">
            <h3 className="flex items-center gap-2 font-semibold text-emerald-900">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-600 text-xs text-white">✓</span>
              Scoring vérifié — failles & preuves (API)
            </h3>
            {typeof reponse?.scoreGlobal === "number" && (
              <>
                <p className="mt-2 text-3xl font-bold text-emerald-700">{reponse.scoreGlobal}%</p>
                <p className="text-sm font-semibold text-emerald-800">Indice de corroboration des motifs</p>
                <p className="mt-1 text-xs text-emerald-700">Cet indice ne prédit pas la décision de l&apos;administration — un juriste examine chaque dossier.</p>
              </>
            )}
            <p className="mt-1 text-xs text-emerald-700">Appels : <code>/api/demo/analyse</code> (failles) + <code>/api/radars</code> (étalonnage) + <code>preuves météo/travaux</code> — croisement automatique.</p>

            <div className="mt-4 grid gap-3 md:grid-cols-2">
              <div className="rounded-xl bg-white p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-zinc-500">Failles juridiques vérifiées</p>
                {reponse?.resultats && reponse.resultats.length > 0 ? (
                  <ul className="mt-2 space-y-2">
                    {reponse.resultats.map((r, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <span className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-xs ${r.score >= 50 ? "bg-emerald-600 text-white" : "bg-amber-500 text-white"}`}>✓</span>
                        <span><span className="font-medium">{r.titreFaille}</span> <span className="text-zinc-500">({r.articleLoi})</span> — <span className="font-bold">{r.score}%</span>{r.proposition && <span className="ml-1 rounded-full bg-amber-100 px-1.5 py-0.5 text-[10px]">proposition</span>}</span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="mt-2 text-sm text-zinc-600">Aucune faille auto détectée — relecture juriste prévue.</p>
                )}
              </div>
              <div className="rounded-xl bg-white p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-zinc-500">Preuves vérifiées (API)</p>
                <ul className="mt-2 space-y-1.5 text-sm">
                  <li className="flex items-center gap-2">{file ? <span className="text-emerald-600">✓</span> : <span className="text-zinc-300">○</span>} <span className={file ? "text-zinc-800" : "text-zinc-400"}>PV/lettre téléversé{file ? ` — ${file.name}` : ""}</span></li>
                  <li className="flex items-center gap-2">{reponse?.preuves?.radar.checked ? (reponse.preuves.radar.found ? <span className="text-emerald-600">✓</span> : <span className="text-amber-600">○</span>) : <span className="text-zinc-300">○</span>} Radar {reponse?.preuves?.radar.found ? (reponse.preuves.radar.expired ? "étalonnage expiré — preuve trouvée" : "étalonnage OK") : infos.lieu ? "vérifié — aucun radar correspondant" : "non vérifié (renseignez N° radar/lieu)"} </li>
                  <li className="flex items-center gap-2">{reponse?.preuves?.meteo.checked ? (reponse.preuves.meteo.value ? <span className="text-emerald-600">✓</span> : <span className="text-zinc-300">○</span>) : <span className="text-zinc-300">○</span>} Météo {reponse?.preuves?.meteo.value ? `${reponse.preuves.meteo.value} (${reponse.preuves.meteo.source})` : "non signalée — cochez si pluie/brouillard"}</li>
                  <li className="flex items-center gap-2">{reponse?.preuves?.travaux.checked ? (reponse.preuves.travaux.value ? <span className="text-emerald-600">✓</span> : <span className="text-zinc-300">○</span>) : <span className="text-zinc-300">○</span>} Travaux {reponse?.preuves?.travaux.value ? "signalés — vérifiés" : "non signalés"}</li>
                  <li className="flex items-center gap-2">{reponse?.texte ? <span className="text-emerald-600">✓</span> : <span className="text-zinc-300">○</span>} Texte numérisé {reponse?.texte ? `capté (${reponse.texte.length} car.)` : "—"}</li>
                </ul>
                <p className="mt-2 text-[11px] text-zinc-500">Vérification croisée : chaque faille est confrontée à sa preuve (ex: étalonnage → certificat radar, météo → bulletin). {reponse?.preuves?.dureeMs ? `Scan ${reponse.preuves.dureeMs}ms.` : ""}</p>
              </div>
            </div>
          </div>
          <Link href={`/paiement?type=${type}`} className="inline-block w-full rounded-full bg-zinc-900 px-6 py-3 text-center font-semibold text-white hover:bg-black">
            Continuer vers le paiement
          </Link>
          <p className="text-center text-xs text-zinc-500">Vous y renseignerez nom, prénom, email, téléphone et choisirez virement ou carte.</p>
        </div>
      )}
      {reponse?.erreur && <p className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">{reponse.erreur}</p>}
    </div>
  );
}
