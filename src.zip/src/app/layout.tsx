import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { SessionProvider } from "next-auth/react";
import "./globals.css";
import { NotificationProvider } from "@/components/NotificationToast";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

function getBaseUrl(): URL {
  // Repli dynamique : en production, jamais localhost — domaine réel de
  // l'app ; localhost réservé au dev local.
  const raw =
    process.env.NEXT_PUBLIC_APP_URL ??
    (process.env.NODE_ENV === "production"
      ? "https://recours-permis-pv.com"
      : "http://localhost:3000");
  // Strip BOM (U+FEFF) anywhere, quotes, and whitespace — Vercel CLI on Windows may inject BOM
  const cleaned = raw.replace(/\uFEFF/g, "").replace(/^"+|"+$/g, "").trim();
  try {
    return new URL(cleaned);
  } catch {
    return new URL("https://sos-amende.vercel.app");
  }
}

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: {
    default: "SOS Amende — Contester vos amendes et défendre votre permis",
    template: "%s · SOS Amende",
  },
  description:
    "Contestez vos amendes routières et votre suspension de permis en quelques clics : analyse des motifs, courrier de recours prêt à envoyer, suivi des délais.",
  metadataBase: getBaseUrl(),
  alternates: { canonical: "/" },
  openGraph: {
    title: "SOS Amende — Contester vos amendes",
    description: "Analyse des motifs juridiques, lettre de recours validée par un juriste, suivi LRAR.",
    locale: "fr_FR",
    type: "website",
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="fr"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col bg-white text-zinc-900">
        <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 rounded bg-zinc-900 px-4 py-2 text-white">
          Aller au contenu principal
        </a>
        <SessionProvider>
          <main id="main">{children}</main>
          <NotificationProvider />
        </SessionProvider>
      </body>
    </html>
  );
}
