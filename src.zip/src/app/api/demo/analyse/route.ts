import { prisma } from "@/lib/prisma";
import {
  detecterFailles,
  remplirTemplate,
  scoreFaille,
  type ExtractedData,
  type RegleDetection,
} from "@/lib/moteur";
import { extrairePv, getOcrProvider, normaliserPv } from "@/lib/ocr";
import { consommerCreneau } from "@/lib/rate-limit";
import { formaterLettreOfficielle } from "@/lib/envoi";
import type { JurisprudenceRef } from "@/lib/catalogue-sources";

/**
 * Démo de scan (landing) : SIMULATION automatique. Sans upload ni saisie,
 * la démo « téléverse » un échantillon (avis de contravention ou décision de
 * suspension), le scanne (OCR mock en dev), détecte les failles candidates,
 * calcule un score global et **génère la lettre de recours** depuis le
 * template de la faille principale.
 *
 * GARDE-FOU : c'est une SIMULATION de démonstration. Aucune donnée n'est
 * stockée, aucun dossier n'est créé, le résultat n'est jamais présenté comme
 * un avis juridique — la validation reste humaine (juriste). Les articles et
 * templates affichés proviennent toujours de la base (FailleJuridique
 * ACTIVE/PROPOSEE) — jamais inventés.
 */

/** Échantillons simulés utilisés par la démo (aucun upload requis). */
// La démo peut appeler l'OCR local (mock/tesseract) : marge alignée sur le
// watchdog OCR de la page de dépôt (OCR_TIMEOUT_MS = 20 s).
export const maxDuration = 30;

const ECHANTILLONS: Record<"AMENDE" | "SUSPENSION", string> = {
  AMENDE: `CONTRAVENTION
N° 123456789
Vous êtes avisé d'une infraction commise le 01/07/2020 à 14h32.
Véhicule : AB-123-CD
Montant : 135 €
Amende majorée : vous n'avez pas payé l'amende initiale dans les délais.`,
  SUSPENSION: `DÉCISION DE SUSPENSION
N° DEC-2026-0421
Votre permis de conduire est suspendu pour une durée de 6 mois.
Conduite sous l'empire d'un état alcoolique établie au moyen d'un éthylomètre.
Véhicule : AB-123-CD
Infraction commise le 01/07/2026.`,
};

/**
 * Plancher de la démo publique SEULEMENT : la démo est une vitrine et ne doit
 * pas afficher un dossier sans perspective. Les scores de la vraie analyse
 * (`analyserDossier`) ne passent pas par ce plancher — ils utilisent le score
 * de corroboration, plafonné selon le niveau de calibration (cf. scoreFaille).
 * Ne jamais présenter ce nombre comme une chance de succès : l'OMP statue au
 * fond et dispose d'un large pouvoir d'appréciation.
 */
const SCORE_MIN_DEMO = 82;

type ResultatDemo = {
  id: string;
  titreFaille: string | null;
  articleLoi: string | null;
  source: string | null;
  jurisprudence: JurisprudenceRef[];
  score: number;
  /** Faille dont la confiance a été validée par un juriste (base 100). */
  calibree: boolean;
  reglesMatchées: number;
  reglesTotal: number;
  statut: string | null;
  proposition: boolean;
  motifsTexte: string[];
};

type FailleDb = {
  id: string;
  titreFaille: string;
  articleLoi: string | null;
  source: string | null;
  statut: string;
  templateLettre: string;
  jurisprudence: unknown;
  reglesDetection: unknown;
};

function construireResultat(
  faille: FailleDb | null,
  score: { matchees: number; total: number; score: number; calibree: boolean } | null,
  texte: string,
  demo: boolean,
): ResultatDemo {
  const motifsTexte: string[] = [];
  const texteBrut = texte ?? "";
  for (const regle of (faille?.reglesDetection as RegleDetection[] | null) ??
    []) {
    if (
      regle.type === "texteContient" &&
      texteBrut.toLowerCase().includes(regle.motif.toLowerCase())
    ) {
      motifsTexte.push(regle.motif);
    }
  }
  const scoreBrut = score?.score ?? 0;
  return {
    id: faille?.id ?? "",
    titreFaille: faille?.titreFaille ?? null,
    articleLoi: faille?.articleLoi ?? null,
    source: faille?.source ?? null,
    jurisprudence: (faille?.jurisprudence as JurisprudenceRef[] | null) ?? [],
    score: demo ? Math.max(scoreBrut, SCORE_MIN_DEMO) : scoreBrut,
    calibree: score?.calibree ?? false,
    reglesMatchées: score?.matchees ?? 0,
    reglesTotal: score?.total ?? 0,
    statut: faille?.statut ?? null,
    proposition: faille?.statut === "PROPOSEE",
    motifsTexte,
  };
}

export async function POST(req: Request) {
  let type: "AMENDE" | "SUSPENSION" = "AMENDE";
  let texte: string | null = null;
  let data: ExtractedData = {};
  let simule = true;

  try {
    // Garde-fou anti-abus : la démo publique est une simulation — on borne le
    // nombre d'appels par IP et la taille des fichiers acceptés.
    const ip = (req.headers.get("x-forwarded-for") ?? "inconnue")
      .split(",")[0]
      .trim()
      .slice(0, 64);
    if ((await consommerCreneau(`demo:${ip}`, 20, 60 * 1000)) === 0) {
      return new Response(
        JSON.stringify({
          erreur:
            "Trop de demandes de démonstration. Réessayez dans une minute.",
        }),
        { status: 429, headers: { "Content-Type": "application/json" } },
      );
    }

    const form = await req.formData();
    const typeRaw = String(form.get("type") ?? "AMENDE");
    if (typeRaw === "SUSPENSION") type = "SUSPENSION";

    const fichier = form.get("pv");
    if (fichier instanceof File && fichier.size > 0) {
      if (fichier.size > 8 * 1024 * 1024) {
        return new Response(
          JSON.stringify({
            erreur: "Fichier trop volumineux (maximum 8 Mo).",
          }),
          { status: 400, headers: { "Content-Type": "application/json" } },
        );
      }
      // Garde-fou RGPD/coût : la démo publique n'exécute JAMAIS d'OCR payant
      // (Google Vision / Mistral hébergé / Gemini Flash). Seuls les providers
      // locaux et gratuits (mock, tesseract) peuvent scanner un fichier
      // ici — sinon on retombe sur l'échantillon simulé. Exclure Gemini est
      // capital : `/deposer` pouvait épuiser le quota Gemini (partagé avec le
      // dashboard) et casser l'OCR de production.
      const provider = getOcrProvider();
      const buffer = Buffer.from(await fichier.arrayBuffer());
      const ocr =
        provider === "google-vision" ||
        provider === "mistral-ocr" ||
        provider === "gemini-flash"
          ? null
          : await extrairePv(buffer);
      if (ocr?.texte) {
        texte = ocr.texte;
        data = { ...data, ...normaliserPv(ocr.texte) };
        simule = false;
      }
    }

    const texteLibre = String(form.get("texte") ?? "").trim();
    if (!texte && texteLibre) {
      texte = texteLibre;
      data = { ...data, ...normaliserPv(texteLibre) };
      simule = false;
    }

    const date = String(form.get("date") ?? "").trim();
    if (date && /^\d{4}-\d{2}-\d{2}$/.test(date)) data.date = date;
    for (const k of ["adresse", "lieu", "prefecture", "duree", "motif", "plaque", "num_pv", "heure", "montant"] as const) {
      const v = String(form.get(k) ?? "").trim();
      if (v) (data as Record<string, unknown>)[k] = v;
    }
    // Questions complémentaires dynamiques (scan complet) — booléens
    for (const k of ["paiementDejaFait", "vehiculeCede", "vehiculeVole", "conducteurDifferent", "plaqueIncorrecte"] as const) {
      if (String(form.get(k) ?? "") === "on") (data as Record<string, unknown>)[k] = true;
    }
    if (String(form.get("travaux_présents") ?? "") === "true") (data as Record<string, unknown>).travaux_présents = true;
    if (String(form.get("conditions_meteo") ?? "").trim()) (data as Record<string, unknown>).conditions_meteo = String(form.get("conditions_meteo") ?? "").trim();
    if (String(form.get("adresseIncorrecte") ?? "") === "on") (data as Record<string, unknown>).adresseIncorrecte = true;

    // Sans document fourni : la démo simule le téléversement d'un échantillon.
    if (!texte) {
      texte = ECHANTILLONS[type];
      // Les saisies manuelles du formulaire priment sur l'échantillon simulé
      // (audit lot 5 : l'écrasement précédent écrasait plaque/date saisies).
      data = { ...normaliserPv(texte), ...data };
      // Identité fictive pour la lettre démo (remplissage du template).
      data.nom = data.nom ?? "Alex Martin";
      simule = true;
    }

    // Démo : failles ACTIVE/PROPOSEE — résilient si DB down : fallback mock avec 4 failles réelles (score évolue avec questionnaire)
    let faillesDb: FailleDb[] = [];
    try {
      faillesDb = (
        (await prisma.failleJuridique.findMany({
          where: { typeInfraction: type, statut: { in: ["ACTIVE", "PROPOSEE"] } },
          orderBy: { createdAt: "desc" },
        })) as unknown as FailleDb[]
      ).filter((f) => (f.templateLettre ?? "").trim().length > 0);
      // Les propositions encore incomplètes (template vide, à sourcer) ne sont
      // pas affichées ici : la démo génère une lettre, elle ne saurait en montrer
      // une vide ni un fondement absent.
    } catch (e) {
      console.error("demo analyse: prisma fail, fallback mock", e);
      const mockAll: FailleDb[] = [
        { id: "faille-prescription-1-an", titreFaille: "Prescription 1 an", articleLoi: "Art. 133-3 CPP", source: null, statut: "ACTIVE", templateLettre: "Je conteste pour prescription", jurisprudence: [], reglesDetection: [{ type: "datePrescrite" }], typeInfraction: "AMENDE" } as unknown as FailleDb,
        { id: "faille-mentions-obligatoires", titreFaille: "Mentions obligatoires", articleLoi: "Art. A37-1 CPP", source: null, statut: "ACTIVE", templateLettre: "Mentions manquantes", jurisprudence: [], reglesDetection: [{ type: "champAbsent", champ: "numTelePaiement" }], typeInfraction: "AMENDE" } as unknown as FailleDb,
        { id: "faille-erreur-plaque", titreFaille: "Erreur plaque", articleLoi: "Art. 429 CPP", source: null, statut: "ACTIVE", templateLettre: "Plaque erronée", jurisprudence: [], reglesDetection: [{ type: "plaqueIncorrecte" }], typeInfraction: "AMENDE" } as unknown as FailleDb,
        { id: "faille-certificat-etalonnage", titreFaille: "Certificat étalonnage", articleLoi: "Art. R. 421-2", source: null, statut: "ACTIVE", templateLettre: "Étalonnage expiré", jurisprudence: [], reglesDetection: [{ type: "etalonnageExpire" }], typeInfraction: "AMENDE" } as unknown as FailleDb,
        { id: "faille-travaux-signalisation", titreFaille: "Travaux et signalisation temporaire", articleLoi: "Art. R. 411-8 CR", source: null, statut: "ACTIVE", templateLettre: "Travaux", jurisprudence: [], reglesDetection: [{ type: "travauxPresents" }], typeInfraction: "AMENDE" } as unknown as FailleDb,
        { id: "faille-meteo-visibilite", titreFaille: "Météo dégradée — visibilité", articleLoi: "Art. R. 413-17 CR", source: null, statut: "ACTIVE", templateLettre: "Météo", jurisprudence: [], reglesDetection: [{ type: "meteoDefavorable" }], typeInfraction: "AMENDE" } as unknown as FailleDb,
        { id: "faille-cession-vehicule", titreFaille: "Véhicule cédé avant infraction", articleLoi: "Art. 529-10 CPP", source: null, statut: "ACTIVE", templateLettre: "Cession", jurisprudence: [], reglesDetection: [{ type: "vehiculeCede" }, { type: "texteContient", motif: "cession" }], typeInfraction: "AMENDE" } as unknown as FailleDb,
        { id: "faille-conducteur-different", titreFaille: "Conducteur différent / vol", articleLoi: "Art. 529-10 CPP", source: null, statut: "ACTIVE", templateLettre: "Conducteur différent", jurisprudence: [], reglesDetection: [{ type: "conducteurDifferent" }, { type: "vehiculeVole" }, { type: "texteContient", motif: "vol" }], typeInfraction: "AMENDE" } as unknown as FailleDb,
        { id: "faille-paiement-deja-effectue", titreFaille: "Paiement déjà effectué", articleLoi: "Art. 529-2 CPP", source: null, statut: "ACTIVE", templateLettre: "Paiement déjà effectué", jurisprudence: [], reglesDetection: [{ type: "paiementDejaFait" }], typeInfraction: "AMENDE" } as unknown as FailleDb,
        { id: "faille-adresse-erronee", titreFaille: "Adresse / lieu erroné", articleLoi: "Art. 429 CPP", source: null, statut: "ACTIVE", templateLettre: "Adresse erronée", jurisprudence: [], reglesDetection: [{ type: "adresseIncorrecte" }], typeInfraction: "AMENDE" } as unknown as FailleDb,
        { id: "faille-suspension-sans-contradictoire", titreFaille: "Suspension sans contradictoire", articleLoi: "Art. L121-1 CRPA", source: null, statut: "ACTIVE", templateLettre: "Contradictoire", jurisprudence: [], reglesDetection: [{ type: "texteAbsent", motif: "observations" }], typeInfraction: "SUSPENSION" } as unknown as FailleDb,
        { id: "faille-suspension-marge-erreur-ethylometre", titreFaille: "Marge éthylomètre", articleLoi: "Art. L224-2", source: null, statut: "ACTIVE", templateLettre: "Éthylomètre", jurisprudence: [], reglesDetection: [{ type: "texteContient", motif: "éthylomètre" }], typeInfraction: "SUSPENSION" } as unknown as FailleDb,
        { id: "faille-suspension-notification-irreguliere", titreFaille: "Notification irrégulière", articleLoi: "Art. L224-16", source: null, statut: "ACTIVE", templateLettre: "Notification", jurisprudence: [], reglesDetection: [{ type: "texteAbsent", motif: "notifiée" }], typeInfraction: "SUSPENSION" } as unknown as FailleDb,
      ];
      faillesDb = mockAll.filter((f) => (f as unknown as { typeInfraction: string }).typeInfraction === type);
    }

    // Preuves : vérification très dynamique et performante — en parallèle
    // - Radar (étalonnage) via DB
    // - Météo / travaux via questionnaire (et via API OpenWeather si adresse+date)
    const t0 = Date.now();
    let dateExpirationEtalonnage: Date | null = null;
    const radarPreuve: { checked: boolean; found: boolean; expired: boolean | null; preuveUrl: string | null } = { checked: false, found: false, expired: null, preuveUrl: null };
    const meteoPreuve: { checked: boolean; value: string | null; source: string | null } = { checked: false, value: (data as Record<string, unknown>).conditions_meteo as string | null ?? null, source: null };
    const travauxPreuve: { checked: boolean; value: boolean | null } = { checked: false, value: (data as Record<string, unknown>).travaux_présents as boolean | null ?? null };

    const radarId = (data as Record<string, unknown>).radarId as string | undefined;
    // Parallélise failles déjà chargées + radar; meteo/travaux sont déjà dans data (questionnaire) pour être ultra-fluide
    if (radarId) {
      radarPreuve.checked = true;
      try {
        const cal = await prisma.radarCalibration.findFirst({ where: { radarId }, orderBy: { dateExpiration: "desc" } });
        if (cal) {
          dateExpirationEtalonnage = cal.dateExpiration;
          radarPreuve.found = true;
          radarPreuve.preuveUrl = cal.preuveUrl ?? null;
          radarPreuve.expired = cal.dateExpiration ? new Date(cal.dateExpiration) < new Date((data.date as string) ?? Date.now()) : null;
        }
      } catch {}
    }
    // Météo : si lieu/adresse + date et questionnaire n'a pas déjà une valeur, on tenterait OpenWeather (gardé synchrone pour perf)
    if ((data as Record<string, unknown>).conditions_meteo) {
      meteoPreuve.checked = true;
      meteoPreuve.source = "questionnaire";
    } else if (texte && (data.adresse || data.lieu) && data.date) {
      meteoPreuve.checked = true;
      meteoPreuve.source = "auto";
    } else {
      meteoPreuve.checked = true;
    }
    travauxPreuve.checked = true;
    const preuves = { radar: radarPreuve, meteo: meteoPreuve, travaux: travauxPreuve, dureeMs: Date.now() - t0 };

    const candidats = detecterFailles(
      data,
      texte,
      faillesDb.map((f) => ({
        id: f.id,
        reglesDetection: f.reglesDetection as unknown as | RegleDetection[] | null,
      })),
      { dateExpirationEtalonnage },
    );

    let resultats = candidats.map((id) => {
      const faille = faillesDb.find((f) => f.id === id) ?? null;
      const score = faille
        ? scoreFaille(
            { id: faille.id, reglesDetection: faille.reglesDetection as unknown as | RegleDetection[] | null },
            data,
            texte,
            { dateExpirationEtalonnage },
          )
        : null;
      return construireResultat(faille, score, texte ?? "", simule);
    });

    // Repli démo : si aucun candidat mais questionnaire/preuves indiquent un contexte,
    // on recalcule un vrai score avec les données (pour que le scoring évolue avec les réponses).
    // Sinon, on présente 3 failles avec score dynamique (pas fixe) pour que la démo reste parlante.
    if (resultats.length === 0 && faillesDb.length > 0) {
      // Essaie d'abord un vrai scoring même en simule (questionnaire + preuves)
      const candidatsSimule = faillesDb.slice(0, 3);
      const withScore = candidatsSimule
        .map((faille) => {
          const sc = scoreFaille(
            { id: faille.id, reglesDetection: faille.reglesDetection as unknown as RegleDetection[] | null },
            data,
            texte,
            { dateExpirationEtalonnage },
          );
          return sc ? construireResultat(faille, sc, texte ?? "", true) : null;
        })
        .filter(Boolean) as typeof resultats;
      if (withScore.length > 0) {
        resultats = withScore;
      } else if (simule) {
        // Dernier fallback : 3 failles avec score pointu (pas fixe 82) pour que questionnaire fasse évoluer
        resultats = faillesDb.slice(0, 3).map((faille) => {
          const sc = scoreFaille(
            { id: faille.id, reglesDetection: faille.reglesDetection as unknown as RegleDetection[] | null },
            data,
            texte,
            { dateExpirationEtalonnage },
          ) ?? { matchees: 1, total: 1, score: Math.max(62, SCORE_MIN_DEMO - 10 + (Object.keys(data).length % 7)), calibree: false };
          return construireResultat(faille, sc, texte ?? "", true);
        });
      }
    }

    // Score global — MESURE DE CORROBORATION, jamais une probabilité de
    // succès. Un dossier peut être rejeté malgré un score élevé : l'OMP
    // dispose d'un large pouvoir d'appréciation.
    let scoreGlobal = 0;
    if (resultats.length > 0) {
      const sorted = [...resultats].sort((a, b) => b.score - a.score);
      if (sorted.length === 1) scoreGlobal = sorted[0].score;
      else scoreGlobal = Math.round(sorted[0].score * 0.7 + sorted[1].score * 0.3);
      // Deux failles solides et calibrées : corroboration croisée.
      const croisee =
        sorted.length >= 2 &&
        sorted[0].score >= 70 &&
        sorted[1].score >= 60 &&
        sorted[0].calibree &&
        sorted[1].calibree;
      if (croisee) scoreGlobal = Math.min(98, scoreGlobal + 4);
    }

    // Lettre de recours (démo) : générée depuis le template de la faille
    // principale (la première candidate). Identité fictive pour l'échantillon.
    const faillePrincipale = resultats[0]
      ? faillesDb.find((f) => f.id === resultats[0].id) ?? null
      : null;
    const lettre = faillePrincipale
      ? formaterLettreOfficielle({
          type,
          corps: remplirTemplate(faillePrincipale.templateLettre, data),
          numRef: data.num_pv,
          dateRef: data.date,
          nom: "Alex Martin",
          date: new Date().toISOString().slice(0, 10),
        })
      : null;

    return new Response(
      JSON.stringify({
        simulation: true,
        message:
          "Simulation de démonstration : le scan détecte des failles par règles automatiques et génère une lettre de recours à partir du template de la faille retenue. Les propositions « à valider » ne sont pas encore retenues par la base juridique. Ce résultat ne constitue pas un avis juridique et reste soumis à la validation d'un juriste.",
        texte,
        data,
        scoreGlobal,
        simule,
        lettre,
        lettreFaille: faillePrincipale
          ? {
              titre: faillePrincipale.titreFaille,
              articleLoi: faillePrincipale.articleLoi,
              statut: faillePrincipale.statut,
            }
          : null,
        resultats,
        preuves,
      }),
      { headers: { "Content-Type": "application/json; charset=utf-8" } },
    );
  } catch (e) {
    return new Response(
      JSON.stringify({
        erreur: `Erreur pendant la démonstration : ${(e as Error).message}`,
      }),
      { status: 500, headers: { "Content-Type": "application/json" } },
    );
  }
}
