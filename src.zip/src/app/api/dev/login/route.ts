import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { devAccessEnabled } from "@/lib/dev-access";

// Accès provisoire simple pour vérification dashboards (dev/E2E uniquement)
// GET /api/dev/login?email=e2e-juriste@test.local -> redirige vers dashboard avec session
// Désactivée par défaut : opt-in explicite ENABLE_DEV_LOGIN=1 (cf. dev-access.ts).
export async function GET(req: Request) {
  if (!devAccessEnabled()) {
    return NextResponse.json({ error: "Dev login désactivé (opt-in ENABLE_DEV_LOGIN requis en hors-prod)" }, { status: 403 });
  }
  const { searchParams } = new URL(req.url);
  const email = searchParams.get("email");
  if (!email) return NextResponse.json({ error: "email requis" }, { status: 400 });

  let user: { role: string } | null = null;
  try {
    user = await prisma.user.findUnique({ where: { email } });
  } catch (e) {
    console.error("dev login: prisma findUnique fail, fallback mock", e);
    // Fallback mock si DB down — on devine le rôle d'après l'email
    if (email.includes("juriste")) user = { role: "JURISTE" };
    else if (email.includes("admin")) user = { role: "ADMIN" };
    else user = { role: "CLIENT" };
  }
  if (!user) return NextResponse.json({ error: "Utilisateur introuvable" }, { status: 404 });

  const dashboards: Record<string, string> = {
    CLIENT: "/dashboard",
    JURISTE: "/dashboard/juriste",
    ADMIN: "/dashboard/admin/dossiers",
  };

  const base = (process.env.NEXT_PUBLIC_APP_URL ?? "https://recours-permis-pv.com").replace(/\uFEFF/g, "").trim();
  const rolePath = dashboards[user.role] ?? "/dashboard";

  // Si appel navigateur (sans Accept: application/json), on redirige directement avec cookie dev_login — marche même si DB down
  const wantsJson = req.headers.get("accept")?.includes("application/json");
  if (!wantsJson) {
    const res = NextResponse.redirect(new URL(`${rolePath}?dev=1`, base));
    res.cookies.set("dev_login", email, { httpOnly: true, maxAge: 3600, path: "/" });
    return res;
  }

  // Sinon (fetch JSON), on tente le magic-link classique + fallback dev
  try {
    const { randomBytes } = await import("crypto");
    const token = randomBytes(32).toString("hex");
    const expires = new Date(Date.now() + 1000 * 60 * 60);
    await prisma.verificationToken.create({ data: { identifier: email, token, expires } });
    const url = `${base}/api/auth/callback/resend?callbackUrl=${encodeURIComponent(rolePath)}&token=${token}&email=${encodeURIComponent(email)}`;
    const res = NextResponse.json({ ok: true, email, role: user.role, dashboard: rolePath, magicLink: url, devLink: `${base}${rolePath}?dev=1`, note: "Lien à usage unique, 1h. Cliquez une fois. Fallback dev=1 si besoin." });
    res.cookies.set("dev_login", email, { httpOnly: true, maxAge: 3600, path: "/" });
    return res;
  } catch (e) {
    console.error("dev login: create token fail, fallback direct", e);
    const res = NextResponse.json({ ok: true, email, role: user.role, dashboard: rolePath, magicLink: `${base}${rolePath}?dev=1`, devLink: `${base}${rolePath}?dev=1`, note: "Mode dégradé — accès direct (DB indisponible)" });
    res.cookies.set("dev_login", email, { httpOnly: true, maxAge: 3600, path: "/" });
    return res;
  }
}
