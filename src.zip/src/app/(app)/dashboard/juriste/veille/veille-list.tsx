"use client";

import { useActionState, useState } from "react";
import {
  ecarterSource,
  extrairePropositionsLot,
  regenererAnalysesVeille,
  relancerVeille,
  retroRemplirFaillesVeille,
  validerPropositionSource,
  type VeilleState,
} from "./actions";
import type { PropositionVeille } from "@/lib/veille-extraction";
import { LectureDrawer } from "./lecture-drawer";

export type SourceDto = {
  id: string;
  statut: string;
  source: string;
  nature: string;
  titre: string;
  juridiction: string | null;
  dateSource: string | null;
  reference: string | null;
  ecli: string | null;
  url: string | null;
  citations: string[];
  matchsCore: string[];
  matchsAppui: string[];
  score: number;
  brouillonRegle: string | null;
  proposition: PropositionVeille | null;
  archive: string | null;
  /** Faille `PROPOSEE` créée automatiquement après extraction (auto-proposition). */
  failleId: string | null;
  /**
   * Pré-filtre déterministe (Lot 1) : score de triage **mécanique** de la
   * publication — c'est cet ordre qui détermine qui passe en premier dans le
   * budget d'extraction IA. Ce n'est pas une qualification juridique.
   */
  priorite?: { score: number; explication: string } | null;
};

const SOURCE_LABEL: Record<string, string> = {
  JADE: "Jurisprudence administrative",
  CASS: "Cour de cassation",
  JORF: "Journal officiel",
  TA: "Tribunaux administratifs",
};

function dateFr(iso: string | null): string {
  if (!iso) return "date inconnue";
  const [a, m, j] = iso.split("-");
  return a && m && j ? `${j}/${m}/${a}` : iso;
}

function Bandeau({ state }: { state: VeilleState }) {
  if (!state) return null;
  if (state.error) {
    return (
      <p className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800">
        {state.error}
      </p>
    );
  }
  if (state.message) {
    return (
      <p className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">
        {state.message}
      </p>
    );
  }
  return null;
}

function dateCourteFr(iso: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" });
}

type ActionEtat = {
  action: (formData: FormData) => void;
  pending: boolean;
  state: VeilleState;
};
export type { ActionEtat };

/**
 * Proposition structurée extraite automatiquement (IA ou secours local) :
 * articles retenus + règle dégagée + conditions, bornée aux verbatims du
 * texte. L'extraction est **toujours automatique** (ingestion + cron + lot) ;
 * la **validation** (→ faille ACTIVE immédiate) est réservée à l'admin.
 */
function BlocProposition({
  s,
  role,
  valider,
}: {
  s: SourceDto;
  role: string;
  valider: ActionEtat;
}) {
  const p = s.proposition;

  const messages = (
    <>
      {valider.state?.error && (
        <p className="mt-2 text-xs text-red-700">{valider.state.error}</p>
      )}
      {valider.state?.message && (
        <p className="mt-2 text-xs text-emerald-700">{valider.state.message}</p>
      )}
    </>
  );

  if (!p) {
    return (
      <div
        className="mt-4 rounded-xl border border-dashed border-zinc-300 bg-zinc-50 p-4"
        data-testid="proposition-encart"
      >
        <p className="text-xs text-zinc-600">
          <strong className="text-zinc-800">
            Proposition (articles + règle dégagée) : non extraite.
          </strong>{" "}
          Extraction automatique au prochain passage du cron (03:30).
        </p>
        {messages}
      </div>
    );
  }

  if (p.etat === "echec") {
    return (
      <div
        className="mt-4 rounded-xl border border-red-200 bg-red-50 p-4"
        data-testid="proposition-encart"
      >
        <p className="text-xs text-red-800">
          <strong>Extraction en échec</strong> — {p.motif}
          <br />
          <span className="text-red-600">
            Relance automatique au prochain passage (cron 03:30).
          </span>
        </p>
        {messages}
      </div>
    );
  }

  const complet = p.etat === "extrait";
  return (
    <div
      className={`mt-4 rounded-xl border p-4 ${
        complet ? "border-emerald-200 bg-emerald-50" : "border-amber-200 bg-amber-50"
      }`}
      data-testid="proposition-encart"
    >
      <div className="flex flex-wrap items-center gap-2">
        <span
          className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${
            complet
              ? "bg-emerald-100 text-emerald-800"
              : "bg-amber-100 text-amber-800"
          }`}
        >
          {p.corrigeLe
            ? `Corrigée par l'admin — ${dateCourteFr(p.corrigeLe)}`
            : complet
              ? `Proposition extraite (${
                  p.methode === "locale" ? "locale — sans IA" : "IA"
                }) — ${dateCourteFr(p.extraitLe)}`
              : `Proposition incomplète (${
                  p.methode === "locale" ? "locale — sans IA" : "IA"
                })`}
        </span>
        {p.methode === "locale" && (
          <span
            className="rounded-full bg-orange-100 px-2.5 py-1 text-[11px] font-semibold text-orange-800"
            data-testid="badge-locale"
            title="Extraction locale (sans IA) — aucune règle dégagée automatiquement"
          >
            locale — sans IA
          </span>
        )}
        <span className="rounded-full border border-zinc-300 bg-white px-2.5 py-1 text-[11px] font-semibold text-zinc-700">
          {p.typeInfraction === "SUSPENSION" ? "Suspension" : "Amende"}
        </span>
        {p.articles.map((a) => (
          <span
            key={a}
            className="rounded-full border border-emerald-300 bg-white px-2.5 py-1 text-[11px] font-semibold text-emerald-900"
          >
            {a}
          </span>
        ))}
      </div>

      {!complet && (
        <>
          <p className="mt-2 text-xs font-medium text-amber-800">{p.motif}</p>
          <p className="mt-1 text-[11px] text-amber-700">
            Ouvrez « Lire la décision » : l&apos;admin corrige la proposition
            (articles, règle, conditions) puis la valide.
          </p>
        </>
      )}

      <p className="mt-3 text-xs font-semibold text-zinc-800">Règle dégagée</p>
      <p className="mt-0.5 text-sm text-zinc-700">{p.regle || "—"}</p>

      {p.resume && (
        <>
          <p className="mt-2 text-xs font-semibold text-zinc-800">
            Objet de la décision
          </p>
          <p className="mt-0.5 text-sm text-zinc-700">{p.resume}</p>
        </>
      )}

      {p.extraits.length > 0 && (
        <ul className="mt-2 space-y-1 border-l-2 border-zinc-200 pl-3">
          {p.extraits.map((e, i) => (
            <li key={i} className="text-xs text-zinc-600">
              « {e} »
            </li>
          ))}
        </ul>
      )}

      <div className="mt-3 flex flex-wrap items-center gap-2">
        {s.statut === "NOUVEAU" && s.failleId && (
          <span
            className="rounded-full bg-sky-100 px-2.5 py-0.5 text-[11px] font-medium text-sky-800"
            data-testid="faille-proposee"
          >
            Faille proposée automatiquement (PROPOSEE)
          </span>
        )}
        {complet && s.statut === "NOUVEAU" && role === "ADMIN" && (
          <form action={valider.action}>
            <input type="hidden" name="id" value={s.id} />
            <button
              type="submit"
              disabled={valider.pending}
              data-testid="valider-proposition"
              className="rounded-full bg-emerald-700 px-4 py-2 text-xs font-semibold text-white transition hover:bg-emerald-800 disabled:opacity-50"
            >
              {valider.pending
                ? "Validation…"
                : "Valider la proposition (→ faille ACTIVE)"}
            </button>
          </form>
        )}
        {complet && s.statut === "NOUVEAU" && role !== "ADMIN" && (
          <p className="text-[11px] text-zinc-600">
            En attente de validation par un administrateur.
          </p>
        )}
      </div>
      {messages}
    </div>
  );
}

function CarteSource({ s, role }: { s: SourceDto; role: string }) {
  const [ouvert, setOuvert] = useState(false);
  const [lecture, setLecture] = useState(false);
  const [stateEcart, actionEcart, pendingEcart] = useActionState<VeilleState, FormData>(
    ecarterSource,
    undefined,
  );
  const [stateValider, actionValider, pendingValider] = useActionState<VeilleState, FormData>(
    validerPropositionSource,
    undefined,
  );

  return (
    <article className="rounded-2xl border border-zinc-200 bg-white p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full bg-zinc-100 px-2.5 py-1 text-[11px] font-semibold text-zinc-700">
              {SOURCE_LABEL[s.source] ?? s.source}
            </span>
            <span className="rounded-full bg-sky-100 px-2.5 py-1 text-[11px] font-semibold text-sky-800">
              score {s.score}
            </span>
            {s.priorite && (
              <span
                className="rounded-full bg-violet-50 px-2.5 py-1 text-[11px] font-medium text-violet-800"
                data-testid="chip-priorite"
                title={`Pré-filtre déterministe (ordre d'extraction) : ${s.priorite.explication}`}
              >
                priorité {s.priorite.score} · {s.priorite.explication}
              </span>
            )}
            {s.matchsCore.slice(0, 3).map((m) => (
              <span
                key={m}
                className="rounded-full bg-amber-50 px-2.5 py-1 text-[11px] font-medium text-amber-800"
              >
                {m}
              </span>
            ))}
          </div>
          <h3 className="mt-2 font-semibold text-zinc-900">{s.titre}</h3>
          <p className="mt-1 text-xs text-zinc-500">
            {[s.juridiction, dateFr(s.dateSource), s.ecli ?? s.reference]
              .filter(Boolean)
              .join(" · ")}
          </p>
        </div>
        {s.url && (
          <a
            href={s.url}
            target="_blank"
            rel="noreferrer noopener"
            className="shrink-0 rounded-full border border-zinc-300 px-3 py-1.5 text-xs font-semibold text-zinc-700 transition hover:bg-zinc-50"
          >
            Source primaire
          </a>
        )}
      </div>

      {s.citations.length > 0 && (
        <ul className="mt-3 space-y-2 border-l-2 border-zinc-200 pl-3">
          {s.citations.map((c, i) => (
            <li key={i} className="text-sm text-zinc-700">
              « {c} »
            </li>
          ))}
        </ul>
      )}

      <BlocProposition
        s={s}
        role={role}
        valider={{
          action: actionValider,
          pending: pendingValider,
          state: stateValider,
        }}
      />

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => setLecture(true)}
          data-testid="lire-decision"
          className="rounded-full bg-zinc-900 px-4 py-2 text-xs font-semibold text-white transition hover:bg-zinc-700"
        >
          Lire la décision
        </button>
        <button
          type="button"
          onClick={() => setOuvert((v) => !v)}
          className="rounded-full border border-zinc-300 px-4 py-2 text-xs font-semibold text-zinc-700 transition hover:bg-zinc-50"
        >
          {ouvert ? "Masquer le brouillon" : "Voir le brouillon de règle"}
        </button>
        <form action={actionEcart}>
          <input type="hidden" name="id" value={s.id} />
          <button
            type="submit"
            disabled={pendingEcart}
            className="rounded-full border border-zinc-300 px-4 py-2 text-xs font-semibold text-zinc-500 transition hover:bg-zinc-50 disabled:opacity-50"
          >
            {pendingEcart ? "…" : "Écarter"}
          </button>
        </form>
        {s.failleId && (
          <p className="text-[11px] text-zinc-500">
            Une faille (PROPOSEE) est déjà liée : gérez-la depuis le drawer de
            lecture ou la bibliothèque juridique.
          </p>
        )}
      </div>

      {stateEcart?.message && (
        <p className="mt-2 text-xs text-zinc-500">{stateEcart.message}</p>
      )}

      {ouvert && (
        <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50 p-4">
          <p className="text-xs font-semibold text-amber-900">
            Brouillon généré par extraction — l&apos;articulation reste à écrire
          </p>
          <pre className="mt-2 max-h-72 overflow-auto whitespace-pre-wrap break-words text-xs text-amber-950">
            {s.brouillonRegle ?? "Brouillon indisponible."}
          </pre>
          {s.archive && (
            <p className="mt-2 text-[11px] text-amber-800">
              Archive d&apos;origine : {s.archive}
            </p>
          )}
        </div>
      )}

      {lecture && (
        <LectureDrawer
          s={s}
          role={role}
          valider={{
            action: actionValider,
            pending: pendingValider,
            state: stateValider,
          }}
          ecart={{
            action: actionEcart,
            pending: pendingEcart,
            state: stateEcart,
          }}
          onClose={() => setLecture(false)}
        />
      )}
    </article>
  );
}

export function VeilleList({
  sources,
  role,
}: {
  sources: SourceDto[];
  role: string;
}) {
  const [state, action, pending] = useActionState<VeilleState, FormData>(
    relancerVeille,
    undefined,
  );
  const [stateLot, actionLot, pendingLot] = useActionState<VeilleState, FormData>(
    extrairePropositionsLot,
    undefined,
  );
  const [stateRegen, actionRegen, pendingRegen] = useActionState<VeilleState, FormData>(
    regenererAnalysesVeille,
    undefined,
  );
  const [stateRetro, actionRetro, pendingRetro] = useActionState<VeilleState, FormData>(
    retroRemplirFaillesVeille,
    undefined,
  );
  const candidatsExtraction = sources.filter(
    (s) =>
      s.statut === "NOUVEAU" &&
      (!s.proposition || s.proposition.etat === "echec"),
  ).length;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-zinc-600">
          {sources.length} publication{sources.length > 1 ? "s" : ""} en attente
          de lecture
        </p>
        <div className="flex flex-wrap items-center gap-2">
          {candidatsExtraction > 0 && (
            <form action={actionLot}>
              <button
                type="submit"
                disabled={pendingLot}
                data-testid="extraire-lot"
                className="rounded-full border border-emerald-300 bg-emerald-50 px-4 py-2 text-xs font-semibold text-emerald-800 transition hover:bg-emerald-100 disabled:opacity-50"
              >
                {pendingLot
                  ? "Extraction en cours…"
                  : `Extraire les propositions (${candidatsExtraction})`}
              </button>
            </form>
          )}
          <form action={action}>
            <button
              type="submit"
              disabled={pending}
              className="rounded-full border border-zinc-300 px-4 py-2 text-xs font-semibold text-zinc-700 transition hover:bg-zinc-50 disabled:opacity-50"
            >
              {pending ? "Interrogation en cours…" : "Relancer la veille maintenant"}
            </button>
          </form>
          {role === "ADMIN" && (
            <>
              <form action={actionRegen}>
                <button
                  type="submit"
                  disabled={pendingRegen}
                  data-testid="regenerer-analyses"
                  className="rounded-full border border-amber-300 bg-amber-50 px-4 py-2 text-xs font-semibold text-amber-800 transition hover:bg-amber-100 disabled:opacity-50"
                >
                  {pendingRegen
                    ? "Régénération en cours…"
                    : "Régénérer les analyses (Veille 2.0)"}
                </button>
              </form>
              <form action={actionRetro}>
                <button
                  type="submit"
                  disabled={pendingRetro}
                  data-testid="retroremplir-failles"
                  className="rounded-full border border-sky-300 bg-sky-50 px-4 py-2 text-xs font-semibold text-sky-800 transition hover:bg-sky-100 disabled:opacity-50"
                >
                  {pendingRetro
                    ? "Rétro-remplissage…"
                    : "Compléter les failles PROPOSEE"}
                </button>
              </form>
            </>
          )}
        </div>
      </div>

      {state?.message && <Bandeau state={state} />}
      {stateLot?.message && <Bandeau state={stateLot} />}
      {stateLot?.error && <Bandeau state={stateLot} />}
      {stateRegen?.message && <Bandeau state={stateRegen} />}
      {stateRegen?.error && <Bandeau state={stateRegen} />}
      {stateRetro?.message && <Bandeau state={stateRetro} />}
      {stateRetro?.error && <Bandeau state={stateRetro} />}

      {sources.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-zinc-300 p-6 text-sm text-zinc-500">
          Aucune publication en attente. Le cron relève chaque jour les
          publications officielles (jurisprudence administrative, Cour de
          cassation, Journal officiel) et n&apos;y dépose que celles qui
          touchent la contestation d&apos;amendes routières.
        </p>
      ) : (
        sources.map((s) => <CarteSource key={s.id} s={s} role={role} />)
      )}
    </div>
  );
}
