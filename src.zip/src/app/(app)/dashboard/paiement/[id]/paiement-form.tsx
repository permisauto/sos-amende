"use client";

import { useActionState, useState } from "react";
import { payerParVirement } from "./actions";
import { PreuveVirementUpload } from "@/components/preuve-virement-upload";
import { libelleMontantDossier, libelleMontantCentimesDossier, PRIX_OPTION_LRAR } from "@/lib/tarifs";
import { RIB } from "@/lib/rib";

export function PaiementForm({
  dossierId,
  type,
  voie,
  defaultEmail,
  defaultName,
}: {
  dossierId: string;
  type: "AMENDE" | "SUSPENSION";
  voie?: string | null;
  defaultEmail: string;
  defaultName: string;
}) {
  const [virementState, virementAction, virementPending] = useActionState(payerParVirement, undefined);

  const [nom, setNom] = useState(defaultName.split(" ").slice(1).join(" ") || "");
  const [prenom, setPrenom] = useState(defaultName.split(" ")[0] || "");
  const [email, setEmail] = useState(defaultEmail);
  const [whatsapp, setWhatsapp] = useState("");
  const [optionLrar, setOptionLrar] = useState(false);

  const [virementConfirme, setVirementConfirme] = useState(false);
  const RIB_IBAN = RIB.iban;
  const RIB_BIC = RIB.bic;
  const RIB_TITULAIRE = RIB.titulaire;

  if (virementState?.ok) {
    return (
      <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-6">
        <h3 className="font-semibold text-emerald-900">Demande de virement enregistrée — voici le RIB à utiliser</h3>
        <p className="mt-2 text-sm text-emerald-800">
          Merci {prenom} — votre demande pour {libelleMontantDossier(type, voie, optionLrar)} (réf. {dossierId.slice(0, 8).toUpperCase()}) est enregistrée. Copiez le RIB ci-dessous dans votre banque :
        </p>
        <div className="mt-4 rounded-xl bg-white p-4 text-sm border-2 border-emerald-200">
          <div className="flex items-center justify-between"><span className="font-semibold">IBAN</span><button type="button" onClick={() => navigator.clipboard.writeText(RIB_IBAN.replace(/\s/g, ""))} className="text-xs text-emerald-700 hover:underline">Copier</button></div>
          <p className="font-mono text-sm">{RIB_IBAN}</p>
          <div className="mt-2 flex items-center justify-between"><span className="font-semibold">BIC</span><button type="button" onClick={() => navigator.clipboard.writeText(RIB_BIC)} className="text-xs text-emerald-700 hover:underline">Copier</button></div>
          <p className="font-mono text-sm">{RIB_BIC}</p>
          <p className="mt-2"><span className="font-semibold">Titulaire :</span> {RIB_TITULAIRE}</p>
          <p className="mt-2"><span className="font-semibold">Montant :</span> {libelleMontantCentimesDossier(type, voie, optionLrar)}{optionLrar ? " — option lettre recommandée incluse" : ""}</p>
          <p className="mt-2 font-mono text-sm bg-amber-50 px-2 py-1 rounded">Référence obligatoire : {dossierId.slice(0, 8).toUpperCase()} — {prenom} {nom}</p>
        </div>
        {!virementConfirme ? (
          <>
            <button type="button" onClick={() => setVirementConfirme(true)} className="mt-4 w-full rounded-full bg-zinc-900 px-6 py-3 font-semibold text-white hover:bg-black">
              J'ai effectué le virement
            </button>
            <p className="mt-3 rounded-xl bg-amber-50 px-3 py-2 text-xs text-amber-800">Dès que le virement est effectué, téléversez la preuve (capture d'écran ou PDF) ci-dessous. Un juriste validera votre paiement sous 24 h ouvrées.</p>
          </>
        ) : (
          <div className="mt-4">
            <p className="rounded-xl bg-emerald-50 px-3 py-2 text-sm text-emerald-800">✓ Merci — virement signalé. Téléversez votre preuve de virement pour accélérer la validation.</p>
            {virementState?.paymentId ? (
              <PreuveVirementUpload paymentId={virementState.paymentId} />
            ) : (
              <p className="mt-3 rounded-xl bg-amber-50 px-3 py-2 text-xs text-amber-800">La preuve ne peut pas être téléversée pour le moment — envoyez-la par email à contact@recours-permis-pv.com.</p>
            )}
          </div>
        )}
        <p className="mt-3 text-xs text-emerald-700">Un juriste validera votre paiement et débloquera la lettre (sous 24h ouvrées). Vous serez notifié par email/WhatsApp.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="rounded-2xl border border-zinc-200 bg-white p-6">
        <h3 className="font-semibold">Vos coordonnées</h3>
        <p className="mt-1 text-xs text-zinc-500">Requises pour la facture et le suivi WhatsApp.</p>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <label className="flex flex-col gap-1.5">
            <span className="text-sm font-medium">Prénom *</span>
            <input value={prenom} onChange={(e) => setPrenom(e.target.value)} required className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm" />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="text-sm font-medium">Nom *</span>
            <input value={nom} onChange={(e) => setNom(e.target.value)} required className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm" />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="text-sm font-medium">Email *</span>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm" />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="text-sm font-medium">WhatsApp *</span>
            <input type="tel" placeholder="+33 6 12 34 56 78" value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} required className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm" />
          </label>
        </div>
      </div>

      <div className="rounded-2xl border-2 border-emerald-600 bg-white p-6">
        <h4 className="font-semibold text-emerald-700">Payer par virement bancaire</h4>
        <p className="mt-1 text-sm text-zinc-600">Copiez le RIB ci-dessous dans votre banque. Montant à virer : {libelleMontantDossier(type, voie, optionLrar)}.</p>
        {RIB.placeholder && (
          <p className="mt-2 rounded-xl border border-amber-300 bg-amber-50 px-3 py-2 text-xs font-medium text-amber-900">
            RIB provisoire de démonstration — à remplacer par les coordonnées bancaires définitives avant mise en production.
          </p>
        )}
        <div className="mt-3 rounded-xl bg-zinc-50 p-3 text-sm border border-emerald-200">
          <div className="flex items-center justify-between"><span className="font-semibold">IBAN</span><button type="button" onClick={() => navigator.clipboard.writeText(RIB_IBAN.replace(/\s/g, ""))} className="text-xs text-emerald-700 hover:underline">Copier</button></div>
          <p className="font-mono">{RIB_IBAN}</p>
          <p className="mt-1 flex items-center gap-2"><span className="font-semibold">BIC</span> {RIB_BIC} <button type="button" onClick={() => navigator.clipboard.writeText(RIB_BIC)} className="text-xs text-emerald-700 hover:underline">Copier</button></p>
          <p className="mt-1"><span className="font-semibold">Titulaire :</span> {RIB_TITULAIRE}</p>
          <p className="mt-1 font-mono bg-amber-50 px-1 rounded">Référence obligatoire : {dossierId.slice(0, 8).toUpperCase()} — {prenom || "Prénom"} {nom || "Nom"}</p>
          <p className="mt-2 text-xs text-zinc-500">Dès que le virement est effectué, envoyez la référence par email <span className="font-semibold">contact@recours-permis-pv.com</span> ou WhatsApp <span className="font-semibold">+33 6 12 34 56 78</span> avec capture d'écran.</p>
        </div>
        <label className="mt-4 flex cursor-pointer items-start gap-3 rounded-xl border border-emerald-200 bg-emerald-50/60 p-3">
          <input type="checkbox" checked={optionLrar} onChange={(e) => setOptionLrar(e.target.checked)} className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-emerald-600" />
          <span className="text-sm">
            <span className="font-semibold text-emerald-800">Option « lettre recommandée » (+{PRIX_OPTION_LRAR} €)</span>
            <span className="mt-0.5 block text-xs text-emerald-700">SOS Amende envoie votre contestation en recommandé avec accusé de réception. Sans cette option, l'envoi se fait en ligne sur le portail officiel.</span>
          </span>
        </label>
        <p className="mt-3 text-2xl font-bold">{libelleMontantDossier(type, voie, optionLrar)}</p>
        <form action={virementAction} className="mt-4">
          <input type="hidden" name="dossierId" value={dossierId} />
          <input type="hidden" name="nom" value={nom} />
          <input type="hidden" name="prenom" value={prenom} />
          <input type="hidden" name="email" value={email} />
          <input type="hidden" name="whatsapp" value={whatsapp} />
          <input type="hidden" name="optionLrar" value={optionLrar ? "1" : "0"} />
          <button disabled={virementPending} className="w-full rounded-full bg-emerald-600 px-6 py-3 font-semibold text-white hover:bg-emerald-700 disabled:opacity-50">
            {virementPending ? "Enregistrement…" : `Valider et recevoir le RIB (${libelleMontantDossier(type, voie, optionLrar)})`}
          </button>
          {virementState?.error && <p className="mt-2 text-xs text-red-600">{virementState.error}</p>}
        </form>
        <p className="mt-3 text-center text-xs text-zinc-400">Le virement est validé par un juriste sous 24 h ouvrées.</p>
      </div>
    </div>
  );
}
