"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/dal";
import { Prisma } from "@/prisma/generated-client";
import type { RegleDetection } from "@/lib/moteur";
import type { JurisprudenceRef } from "@/lib/catalogue-sources";
import { CATALOGUE_SOURCES } from "@/lib/catalogue-sources";
import {
  enregistrerTraceAutoAlimentation,
  executerAutoAlimentation,
  listerMisesAJourCatalogue,
  synchroniserCatalogue,
} from "@/lib/auto-alimentation";
import { validateMockFaille } from "@/lib/mock-failles";
import {
  donneesActivation,
  messageActivationBloquee,
  activerPropositionsCompletes,
} from "@/lib/failles";
import { synchroniserSourceLiee } from "@/lib/veille-ingestion";
import { invalidateQuestionsDynamiquesCache } from "@/lib/questions-dyn";

export type FailleState =
  | {
      error?: string;
      ok?: boolean;
      count?: number;
      activees?: number;
      ignorees?: number;
      message?: string;
      statut?: "ACTIVE" | "INACTIVE";
    }
  | undefined;

const regleSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("champAbsent"), champ: z.string().min(1) }),
  z.object({ type: z.literal("datePrescrite") }),
  z.object({ type: z.literal("plaqueIncorrecte") }),
  z.object({ type: z.literal("etalonnageExpire") }),
  z.object({ type: z.literal("texteContient"), motif: z.string().min(1) }),
  z.object({ type: z.literal("texteAbsent"), motif: z.string().min(1) }),
]);

const jurisprudenceSchema = z.object({
  reference: z.string().min(1),
  juridiction: z.string().min(1),
  date: z.string().optional().nullable(),
  url: z.string().optional().nullable(),
  verifiee: z.boolean().default(false),
  resume: z.string().optional().nullable(),
});

// Lit les règles de détection depuis le textarea JSON du formulaire admin.
function lireRegles(formData: FormData):
  | { regles: RegleDetection[] }
  | { error: string } {
  const raw = String(formData.get("reglesDetection") ?? "").trim();
  if (!raw) return { regles: [] };
  try {
    const parsed = JSON.parse(raw);
    const checked = z.array(regleSchema).safeParse(parsed);
    if (!checked.success) {
      return { error: "Règles de détection invalides (voir le format attendu)." };
    }
    return { regles: checked.data };
  } catch {
    return { error: "Règles de détection : JSON invalide." };
  }
}

// Lit les références de jurisprudence (JSON) depuis le formulaire admin.
function lireJurisprudence(formData: FormData):
  | { jurisprudence: JurisprudenceRef[] }
  | { error: string } {
  const raw = String(formData.get("jurisprudence") ?? "").trim();
  if (!raw) return { jurisprudence: [] };
  try {
    const parsed = JSON.parse(raw);
    const checked = z.array(jurisprudenceSchema).safeParse(parsed);
    if (!checked.success) {
      return { error: "Jurisprudence invalide (voir le format attendu)." };
    }
    return { jurisprudence: checked.data };
  } catch {
    return { error: "Jurisprudence : JSON invalide." };
  }
}

const failleSchema = z.object({
  typeInfraction: z.enum(["AMENDE", "SUSPENSION"]),
  titreFaille: z.string().trim().min(3, "Titre trop court"),
  articleLoi: z.string().trim().min(1, "Article requis"),
  regle: z.string().trim().optional(),
  templateLettre: z.string().trim().min(10, "Template trop court"),
  source: z.string().trim().optional(),
});

export async function creerFaille(
  _prev: FailleState,
  formData: FormData,
): Promise<FailleState> {
  await requireAdmin();

  const parsed = failleSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) {
    return { error: "Champs obligatoires manquants ou invalides." };
  }
  const regles = lireRegles(formData);
  if ("error" in regles) return regles;
  const jurisprudence = lireJurisprudence(formData);
  if ("error" in jurisprudence) return jurisprudence;

  await prisma.failleJuridique.create({
    data: {
      ...parsed.data,
      regle: parsed.data.regle || null,
      reglesDetection: regles.regles.length > 0 ? regles.regles : Prisma.JsonNull,
      jurisprudence:
        jurisprudence.jurisprudence.length > 0
          ? jurisprudence.jurisprudence
          : Prisma.JsonNull,
      statut: "ACTIVE",
    },
  });

  revalidatePath("/dashboard/juriste/failles");
  invalidateQuestionsDynamiquesCache();
  return { ok: true };
}

export async function modifierFaille(
  _prev: FailleState,
  formData: FormData,
): Promise<FailleState> {
  await requireAdmin();

  const id = String(formData.get("id") ?? "");
  const parsed = failleSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) {
    return { error: "Champs obligatoires manquants ou invalides." };
  }
  const regles = lireRegles(formData);
  if ("error" in regles) return regles;
  const jurisprudence = lireJurisprudence(formData);
  if ("error" in jurisprudence) return jurisprudence;

  await prisma.failleJuridique.update({
    where: { id },
    data: {
      ...parsed.data,
      regle: parsed.data.regle || null,
      reglesDetection: regles.regles.length > 0 ? regles.regles : Prisma.JsonNull,
      jurisprudence:
        jurisprudence.jurisprudence.length > 0
          ? jurisprudence.jurisprudence
          : Prisma.JsonNull,
    },
  });

  revalidatePath("/dashboard/juriste/failles");
  invalidateQuestionsDynamiquesCache();
  return { ok: true };
}

export async function basculerFaille(
  _prev: FailleState,
  formData: FormData,
): Promise<FailleState> {
  const admin = await requireAdmin();

  const id = String(formData.get("id") ?? "");
  const faille = await prisma.failleJuridique.findUnique({ where: { id } });
  if (!faille) {
    return { error: "Faille introuvable." };
  }

  // Garde-fou anti-hallucination : une réactivation (→ ACTIVE) passe par le
  // même contrôle que la validation de proposition (règle dégagée + template).
  const devientActive = faille.statut !== "ACTIVE";
  if (devientActive) {
    const bloque = messageActivationBloquee(faille);
    if (bloque) return { error: bloque };
  }

  await prisma.failleJuridique.update({
    where: { id },
    data: devientActive
      ? donneesActivation(faille.jurisprudence)
      : { statut: "INACTIVE" },
  });
  // Faille née de la veille : la publication liée suit la décision de l'admin
  // (invariant « la source suit sa faille », best-effort).
  await synchroniserSourceLiee(id, devientActive ? "PROMU" : "ECARTE", admin.id);

  revalidatePath("/dashboard/juriste/failles");
  invalidateQuestionsDynamiquesCache();
  return { ok: true, statut: devientActive ? "ACTIVE" : "INACTIVE" };
}

/**
 * Auto-alimentation de la base juridique, bouton « Synchroniser et activer » :
 * importe le catalogue issu de la recherche documentaire sur sources publiques
 * (FAILLES.md §H, CATALOGUE_SOURCES) **puis** passe en ACTIVE d'office toutes
 * les propositions complètes — l'admin n'a plus à les valider une par une.
 *
 * Garde-fous conservés : seule une proposition `estActivable` (règle dégagée +
 * template de lettre non vides) change de statut ; les incomplètes (promotion
 * de veille à rédiger, création hors catalogue) restent PROPOSEE, faute de quoi
 * le moteur générerait une lettre vide. Les failles déjà ACTIVE ne sont pas
 * rétrogradées et un écart (INACTIVE) n'est jamais réactivé.
 *
 * La synchronisation **automatique** (cron `/api/cron/auto-alimentation` et
 * ouverture de la page bibliothèque) reste en PROPOSEE : seule l'action
 * explicite de l'admin active.
 */
export async function importerFaillesDepuisSources(
  _prev: FailleState,
  _formData: FormData,
): Promise<FailleState> {
  await requireAdmin();

  const count = await synchroniserCatalogue();
  const bilan = await activerPropositionsCompletes(prisma);

  await enregistrerTraceAutoAlimentation({
    campagne: "catalogue",
    statut: "OK",
    traitees: count,
    nouvelles: bilan.activees.length,
    detail: `Synchronisation manuelle admin : ${count} entrée(s) du catalogue, ${bilan.activees.length} faille(s) activée(s), ${bilan.ignorees} restée(s) en proposition (incomplète(s)).`,
  });

  revalidatePath("/dashboard/juriste/failles");
  invalidateQuestionsDynamiquesCache();
  return {
    ok: true,
    count,
    activees: bilan.activees.length,
    ignorees: bilan.ignorees,
  };
}

const PROPOSEE_ACTIONS = ["ACTIVE", "INACTIVE"] as const;

/**
 * Bouton « Lancer l'auto-alimentation » : déclenche **manuellement** le
 * même passage que le cron quotidien `/api/cron/auto-alimentation`
 * (`executerAutoAlimentation`) — synchronisation du catalogue en statut
 * PROPOSEE + détection de l'édition du JORF, avec traces écrites. **Aucune
 * activation** : seuls les boutons « Synchroniser et activer » / « Activer
 * les propositions » changent un statut.
 */
export async function lancerAutoAlimentation(
  _prev: FailleState,
  _formData: FormData,
): Promise<FailleState> {
  await requireAdmin();

  try {
    const res = await executerAutoAlimentation();
    const misesAJour = await listerMisesAJourCatalogue();

    // On ne remonte que le delta : la base est déjà synchronisée la plupart
    // du temps (idempotent comme le cron) — dire explicitement « rien de
    // nouveau » évite de laisser croire que le bouton n'a rien fait.
    const parties: string[] = [];
    if (res.catalogue > 0) {
      parties.push(`${res.catalogue} entrée(s) du catalogue synchronisée(s)`);
    }
    if (misesAJour.length > 0) {
      parties.push(`${misesAJour.length} mise(s) à jour disponible(s) à appliquer`);
    }
    if (res.veilleNouvelle && res.veilleEdition) {
      parties.push(`nouvelle édition JORF : ${res.veilleEdition}`);
    }

    revalidatePath("/dashboard/juriste/failles");
    return {
      ok: true,
      count: res.catalogue,
      message:
        parties.length > 0
          ? `Auto-alimentation exécutée : ${parties.join(" · ")}. Aucune faille activée (validation humaine inchangée).`
          : `Aucun changement : tout est déjà à jour${res.veilleEdition ? ` (édition JORF ${res.veilleEdition} déjà connue)` : " (index JORF injoignable — réessayez plus tard)"}. Aucune faille activée (validation humaine inchangée).`,
    };
  } catch (e) {
    console.error("lancerAutoAlimentation: échec", e);
    return { error: "Échec de l'auto-alimentation — réessayez (voir logs serveur)." };
  }
}

/**
 * Option B de l'auto-alimentation : applique **explicitement** à une faille
 * déjà en base le contenu à jour du catalogue sourcé. Action admin, une faille
 * à la fois (l'écart est affiché avec un diff avant/après sur la bibliothèque).
 *
 * Garde-fous :
 *  - la faille doit appartenir au catalogue (aucune écriture hors source) ;
 *  - une faille écartée (INACTIVE) n'est jamais réécrite (décision admin
 *    antérieure respectée) ;
 *  - le statut est **conservé** (une faille ACTIVE reste ACTIVE) : on ne
 *    rétrograde ni ne valide à la place de l'admin.
 */
export async function appliquerMiseAJourCatalogue(
  _prev: FailleState,
  formData: FormData,
): Promise<FailleState> {
  await requireAdmin();

  const id = String(formData.get("id") ?? "");
  const entree = CATALOGUE_SOURCES.find((f) => f.id === id);
  if (!entree) return { error: "Cette faille n'existe plus dans le catalogue." };
  if (entree.aCompleter) {
    return {
      error:
        "Proposition encore à sourcer : complétez l'article et la lettre depuis une source primaire avant d'appliquer quoi que ce soit.",
    };
  }

  const faille = await prisma.failleJuridique.findUnique({
    where: { id },
    select: { statut: true },
  });
  if (!faille) return { error: "Faille introuvable." };
  if (faille.statut === "INACTIVE") {
    return { error: "Faille écartée : réactivez-la avant d'appliquer la mise à jour." };
  }

  await prisma.failleJuridique.update({
    where: { id },
    data: {
      typeInfraction: entree.typeInfraction,
      titreFaille: entree.titreFaille,
      articleLoi: entree.articleLoi,
      regle: entree.regle,
      templateLettre: entree.templateLettre,
      source: entree.source,
      reglesDetection: entree.reglesDetection as Prisma.InputJsonValue,
      jurisprudence: entree.jurisprudence as Prisma.InputJsonValue,
      statut: faille.statut,
    },
  });

  await enregistrerTraceAutoAlimentation({
    campagne: "catalogue",
    statut: "OK",
    traitees: 1,
    detail: `Mise à jour appliquée manuellement : ${id} (${faille.statut}).`,
  });

  revalidatePath("/dashboard/juriste/failles");
  invalidateQuestionsDynamiquesCache();
  return { ok: true };
}

/**
 * Validation d'une proposition (auto-alimentation) par l'admin :
 *  - ACTIVE : la faille est retenue et utilisée par le moteur.
 *  - INACTIVE : la proposition est écartée (jurisprudence non confirmée, etc.).
 *
 * Garde-fou : une proposition issue de la veille juridique est créée avec une
 * règle et un template **vides** (seule la référence de la source est
 * pré-remplie). On refuse donc de l'activer tant qu'elle est incomplète —
 * sans quoi le moteur générerait une lettre vide.
 */
export async function validerPropositionFaille(
  _prev: FailleState,
  formData: FormData,
): Promise<FailleState> {
  const admin = await requireAdmin();

  const id = String(formData.get("id") ?? "");
  const action = PROPOSEE_ACTIONS.find((a) => a === formData.get("action"));
  if (!action) return { error: "Action invalide." };

  try {
    const faille = await prisma.failleJuridique.findUnique({ where: { id } });
    if (!faille) return { error: "Faille introuvable." };
    if (faille.statut !== "PROPOSEE") {
      return { error: "Seule une proposition peut être validée ainsi." };
    }
    if (action === "ACTIVE") {
      const bloque = messageActivationBloquee(faille);
      if (bloque) return { error: bloque };
    }

    await prisma.failleJuridique.update({
      where: { id },
      data:
        action === "ACTIVE"
          ? donneesActivation(faille.jurisprudence)
          : { statut: "INACTIVE" },
    });
  } catch (e) {
    console.error("validerPropositionFaille: DB indisponible, fallback mock", e);
    // Fallback mock si DB down : on simule la validation pour la démo
    if (!id.startsWith("faille-")) return { error: "Faille introuvable (mock)." };
    validateMockFaille(id, action);
  }

  // Faille née de la veille : la publication liée suit la décision.
  await synchroniserSourceLiee(id, action === "ACTIVE" ? "PROMU" : "ECARTE", admin.id);

  revalidatePath("/dashboard/juriste/failles");
  invalidateQuestionsDynamiquesCache();
  return { ok: true, statut: action };
}

/**
 * Activation dédiée d'une proposition (PROPOSEE → ACTIVE) — action utilisée
 * par le bouton « Valider (Active) » de la bibliothèque.
 *
 * Garde-fous : admin seulement (`requireAdmin`) ; seule une proposition est
 * activable, et seulement si elle est complète (`estActivable` = règle dégagée
 * + template de lettre rédigés — `messageActivationBloquee` donne le message
 * actionnable) ; le verrou `statut=PROPOSEE` posé dans l'`updateMany` rend le
 * double-clic idempotent (un seul passage en ACTIVE) et refuse toute faille
 * écartée (INACTIVE) ou déjà active.
 */
export async function activerFailleProposee(
  _prev: FailleState,
  formData: FormData,
): Promise<FailleState> {
  const admin = await requireAdmin();

  const id = String(formData.get("id") ?? "");
  const faille = await prisma.failleJuridique.findUnique({ where: { id } });
  if (!faille) return { error: "Faille introuvable." };
  if (faille.statut !== "PROPOSEE") {
    return { error: "Seule une proposition peut être activée ainsi." };
  }
  // messageActivationBloquee est null ⟺ estActivable(faille).
  const bloque = messageActivationBloquee(faille);
  if (bloque) return { error: bloque };

  const maj = await prisma.failleJuridique.updateMany({
    where: { id, statut: "PROPOSEE" },
    data: donneesActivation(faille.jurisprudence),
  });
  if (maj.count === 0) {
    return { error: "Cette proposition a déjà été activée ou écartée." };
  }

  // Faille née de la veille : la publication liée suit la décision.
  await synchroniserSourceLiee(id, "PROMU", admin.id);

  revalidatePath("/dashboard/juriste/failles");
  invalidateQuestionsDynamiquesCache();
  return { ok: true, statut: "ACTIVE" };
}

const importItemSchema = z.object({
  id: z.string().min(1),
  typeInfraction: z.enum(["AMENDE", "SUSPENSION"]),
  titreFaille: z.string().min(1),
  articleLoi: z.string().min(1),
  templateLettre: z.string().min(1),
  source: z.string().nullable().optional(),
  regle: z.string().nullable().optional(),
  statut: z.enum(["ACTIVE", "INACTIVE", "PROPOSEE"]).optional(),
  reglesDetection: z.array(regleSchema).nullable().optional(),
  jurisprudence: z.array(jurisprudenceSchema).nullable().optional(),
});

/**
 * Import de la base juridique par mises à jour (upsert par id) : le juriste /
 * admin maintient la base (export → modification → réimport), et le moteur
 * l'utilise immédiatement.
 */
export async function importerFailles(
  _prev: FailleState,
  formData: FormData,
): Promise<FailleState> {
  await requireAdmin();

  const raw = String(formData.get("json") ?? "").trim();
  if (!raw) {
    return { error: "Collez le JSON à importer." };
  }

  let items: unknown;
  try {
    items = JSON.parse(raw);
  } catch {
    return { error: "JSON invalide." };
  }
  if (!Array.isArray(items)) {
    return { error: "Le JSON doit être un tableau de failles." };
  }
  const checked = z.array(importItemSchema).safeParse(items);
  if (!checked.success) {
    return { error: "Champs invalides dans le JSON (voir le format exporté)." };
  }

  for (const f of checked.data) {
    await prisma.failleJuridique.upsert({
      where: { id: f.id },
      update: {
        typeInfraction: f.typeInfraction,
        titreFaille: f.titreFaille,
        articleLoi: f.articleLoi,
        templateLettre: f.templateLettre,
        source: f.source ?? null,
        regle: f.regle ?? null,
        statut: f.statut ?? "ACTIVE",
        reglesDetection: f.reglesDetection ?? Prisma.JsonNull,
        jurisprudence: f.jurisprudence ?? Prisma.JsonNull,
      },
      create: {
        id: f.id,
        typeInfraction: f.typeInfraction,
        titreFaille: f.titreFaille,
        articleLoi: f.articleLoi,
        templateLettre: f.templateLettre,
        source: f.source ?? null,
        regle: f.regle ?? null,
        statut: f.statut ?? "ACTIVE",
        reglesDetection: f.reglesDetection ?? Prisma.JsonNull,
        jurisprudence: f.jurisprudence ?? Prisma.JsonNull,
      },
    });
  }

  revalidatePath("/dashboard/juriste/failles");
  invalidateQuestionsDynamiquesCache();
  return { ok: true, count: checked.data.length };
}

const radarSchema = z.object({
  radarId: z.string().trim().min(1, "Référence radar requise"),
  dateExpiration: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date invalide"),
  preuveUrl: z.string().trim().optional(),
});

export async function creerRadar(
  _prev: FailleState,
  formData: FormData,
): Promise<FailleState> {
  await requireAdmin();

  const parsed = radarSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) {
    return { error: "Champs obligatoires manquants ou invalides." };
  }

  await prisma.radarCalibration.create({
    data: {
      radarId: parsed.data.radarId,
      dateExpiration: new Date(`${parsed.data.dateExpiration}T00:00:00Z`),
      preuveUrl: parsed.data.preuveUrl ?? "",
    },
  });

  revalidatePath("/dashboard/admin/radars");
  return { ok: true };
}

export async function supprimerRadar(
  _prev: FailleState,
  formData: FormData,
): Promise<FailleState> {
  await requireAdmin();

  const id = String(formData.get("id") ?? "");
  await prisma.radarCalibration.delete({ where: { id } }).catch(() => {});

  revalidatePath("/dashboard/admin/radars");
  return { ok: true };
}

export async function validerVirement(
  _prev: FailleState,
  formData: FormData,
): Promise<FailleState> {
  await requireAdmin();
  const id = String(formData.get("id") ?? "");
  const payment = await prisma.payment.findUnique({ where: { id } });
  if (!payment) {
    if (id.startsWith("pay-mock-")) {
      revalidatePath("/dashboard/admin/paiements");
      return { ok: true };
    }
    return { error: "Paiement introuvable." };
  }
  if (payment.status !== "PENDING_VIREMENT") return { error: "Seuls les virements en attente peuvent être validés." };
  // Le contentieux (149 €) est une offre rattachée à un dossier : jamais un
  // crédit générique. Un paiement orphelin serait une erreur de flux.
  if (payment.kind === "CONTENTIEUX" && !payment.dossierId) {
    return { error: "Un paiement contentieux doit être rattaché à un dossier." };
  }

  // Paiement rattaché à un dossier en attente (EN_ATTENTE_PAIEMENT) : le
  // crédit sert directement le dossier — il passe en EN_ATTENTE_VALIDATION
  // pour le juriste, sans créditer le client (le paiement a été consommé).
  let dossierEnValidation: string | null = null;
  const dejaValide = await prisma.$transaction(async (tx) => {
    // Verrou anti double-validation (double-clic / onglets concurrents) : seul
    // un PENDING_VIREMENT → PAID est accepté — un seul crédit incrémenté.
    const verrou = await tx.payment.updateMany({
      where: { id, status: "PENDING_VIREMENT" },
      data: { status: "PAID", valideLe: new Date() },
    });
    if (verrou.count === 0) return true;

    if (payment.dossierId) {
      const dossierLie = await tx.dossier.findUnique({
        where: { id: payment.dossierId },
        select: { id: true, statut: true },
      });
      if (dossierLie && dossierLie.statut === "EN_ATTENTE_PAIEMENT") {
        dossierEnValidation = dossierLie.id;
        const estContentieux = payment.kind === "CONTENTIEUX";
        await tx.dossier.update({
          where: { id: dossierLie.id },
          // Le client a réellement payé (virement validé) : on marque le débit
          // pour qu'un rejet ultérieur rende bien le crédit (rejeterDossier).
          // Un contentieux est payé 149 € : aucun crédit n'est débité — le
          // remboursement éventuel est manuel et tracé (`REFUND_DUE`).
          data: {
            statut: "EN_ATTENTE_VALIDATION",
            ...(estContentieux ? {} : { creditDebite: true }),
          },
        });
        await tx.dossierEvent.create({
          data: {
            dossierId: dossierLie.id,
            type: "EN_ATTENTE",
            detail: estContentieux
              ? "Paiement contentieux validé (149 €) — dossier transmis au juriste"
              : "Paiement validé — dossier transmis au juriste",
          },
        });
        return false;
      }
    }

    // Contentieux : le paiement est consommé par le dossier, jamais converti en
    // crédit (39 € ≠ 149 €). On ne crédite donc pas le compte.
    if (payment.kind === "CONTENTIEUX") return false;

    await tx.user.update({
      where: { id: payment.userId },
      data: { credits: { increment: 1 } },
    });
    return false;
  });
  if (dejaValide) {
    return { error: "Seuls les virements en attente peuvent être validés." };
  }

  const user = await prisma.user.findUnique({ where: { id: payment.userId } });
  if (user) {
    const { notifierPaiementValide } = await import("@/lib/notifications");
    await notifierPaiementValide(
      user.email,
      user.name,
      payment.kind === "CONTENTIEUX",
    );
  }

  // Le dossier venant de basculer en EN_ATTENTE_VALIDATION : le client est
  // notifié que la lettre est en cours de validation (défensif sans clé).
  if (dossierEnValidation) {
    const { notifierStatut } = await import("@/lib/notifications");
    await notifierStatut(dossierEnValidation).catch(() => false);
  }

  revalidatePath("/dashboard/admin/paiements");
  revalidatePath("/dashboard");
  return { ok: true };
}

export async function refuserVirement(
  _prev: FailleState,
  formData: FormData,
): Promise<FailleState> {
  await requireAdmin();
  const id = String(formData.get("id") ?? "");
  const motif = String(formData.get("motif") ?? "").trim();
  // Motif obligatoire : le client le reçoit par e-mail et dans le bandeau de
  // son espace — il doit savoir ce qu'il faut corriger pour refaire un virement.
  if (motif.length < 3) return { error: "Le motif de refus est obligatoire." };

  const payment = await prisma.payment.findUnique({ where: { id } });
  if (!payment) {
    if (id.startsWith("pay-mock-")) {
      revalidatePath("/dashboard/admin/paiements");
      return { ok: true };
    }
    return { error: "Paiement introuvable." };
  }
  if (payment.status !== "PENDING_VIREMENT") return { error: "Seuls les virements en attente peuvent être refusés." };

  // Verrou anti double-clic (identique à la validation) : seul un
  // PENDING_VIREMENT → REFUSED est accepté — un seul refus enregistré.
  const dejaRefuse = await prisma.$transaction(async (tx) => {
    const verrou = await tx.payment.updateMany({
      where: { id, status: "PENDING_VIREMENT" },
      data: { status: "REFUSED", refuseLe: new Date(), refusMotif: motif },
    });
    if (verrou.count === 0) return true;

    // Transparence côté client : le refus apparaît dans la timeline du dossier
    // (le dossier reste en attente de paiement — un nouveau virement est possible).
    if (payment.dossierId) {
      const dossierLie = await tx.dossier.findUnique({
        where: { id: payment.dossierId },
        select: { id: true, statut: true },
      });
      if (dossierLie && dossierLie.statut === "EN_ATTENTE_PAIEMENT") {
        await tx.dossierEvent.create({
          data: {
            dossierId: dossierLie.id,
            type: "EN_ATTENTE",
            detail: `Virement refusé par l'équipe — ${motif}`,
          },
        });
      }
    }
    return false;
  });
  if (dejaRefuse) {
    return { error: "Seuls les virements en attente peuvent être refusés." };
  }

  const user = await prisma.user.findUnique({ where: { id: payment.userId } });
  if (user) {
    const { notifierPaiementRefuse } = await import("@/lib/notifications");
    await notifierPaiementRefuse(user.email, user.name, motif);
  }

  revalidatePath("/dashboard/admin/paiements");
  revalidatePath("/dashboard");
  return { ok: true };
}

export async function marquerRembourse(
  _prev: FailleState,
  formData: FormData,
): Promise<FailleState> {
  await requireAdmin();
  const id = String(formData.get("id") ?? "");
  const payment = await prisma.payment.findUnique({ where: { id } });
  if (!payment) {
    if (id.startsWith("pay-mock-")) {
      revalidatePath("/dashboard/admin/paiements");
      return { ok: true };
    }
    return { error: "Paiement introuvable." };
  }
  if (payment.status !== "REFUND_DUE") {
    return { error: "Ce paiement n'est pas en attente de remboursement." };
  }

  // Verrou anti double-remboursement : seul REFUND_DUE → REFUNDED passe.
  const dejaRembourse = await prisma.$transaction(async (tx) => {
    const verrou = await tx.payment.updateMany({
      where: { id, status: "REFUND_DUE" },
      data: { status: "REFUNDED", rembourseLe: new Date() },
    });
    if (verrou.count === 0) return true;
    if (payment.dossierId) {
      await tx.dossierEvent.create({
        data: {
          dossierId: payment.dossierId,
          type: "REJET",
          detail: `Remboursement de ${Number(payment.amount).toFixed(2).replace(".", ",")} € effectué`,
        },
      });
    }
    return false;
  });
  if (dejaRembourse) {
    return { error: "Ce paiement n'est pas en attente de remboursement." };
  }

  const user = await prisma.user.findUnique({ where: { id: payment.userId } });
  if (user) {
    const { notifierRemboursement } = await import("@/lib/notifications");
    await notifierRemboursement(user.email, user.name, Number(payment.amount));
  }

  revalidatePath("/dashboard/admin/paiements");
  revalidatePath("/dashboard");
  return { ok: true };
}

export async function activerToutesPropositions(
  _prev: FailleState,
  _formData: FormData,
): Promise<FailleState> {
  const admin = await requireAdmin();

  try {
    const { activees, ignorees, examinees } = await activerPropositionsCompletes(prisma);

    // Failles nées de la veille : la publication liée suit l'activation.
    for (const id of activees) {
      await synchroniserSourceLiee(id, "PROMU", admin.id);
    }

    if (examinees === 0) {
      return { error: "Aucune proposition à activer." };
    }

    // Activation partielle : ce n'est pas une erreur — on le signale en vert
    // (l'UI affiche `count`/`ignorees`), seul le cas « rien d'activé » est un
    // blocage à expliciter.
    if (ignorees > 0 && activees.length > 0) {
      return { ok: true, count: activees.length, ignorees };
    }
    if (ignorees > 0) {
      return {
        error: `${ignorees} proposition(s) incomplète(s) : règle dégagée ou template de lettre manquant. Rédigez-les (bibliothèque → « Modifier ») puis réactivez.`,
      };
    }
    return { ok: true, count: activees.length };
  } catch (e) {
    console.error("activerToutesPropositions: DB indisponible, fallback mock", e);
    // Fallback mock : on active toutes les PROPOSEE du catalogue
    const { CATALOGUE_SOURCES } = await import("@/lib/catalogue-sources");
    const { validateMockFaille } = await import("@/lib/mock-failles");
    const isHistorique = new Set([
      "faille-prescription-1-an",
      "faille-mentions-obligatoires",
      "faille-erreur-plaque",
      "faille-certificat-etalonnage",
      "faille-travaux-signalisation",
      "faille-meteo-visibilite",
      "faille-cession-vehicule",
      "faille-conducteur-different",
      "faille-paiement-deja-effectue",
      "faille-adresse-erronee",
      "faille-prescription-peine-3ans",
    ]);
    for (const f of CATALOGUE_SOURCES) {
      // Même garde-fou qu'en base : une proposition incomplète (à sourcer)
      // ne passe jamais en ACTIVE, même en fallback mock.
      if (f.aCompleter) continue;
      if (!isHistorique.has(f.id)) {
        validateMockFaille(f.id, "ACTIVE");
      }
    }
  }

  revalidatePath("/dashboard/juriste/failles");
  invalidateQuestionsDynamiquesCache();
  return { ok: true };
}