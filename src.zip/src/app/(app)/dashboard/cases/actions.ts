"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { after } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/dal";
import { enrichirApresOcr } from "@/lib/auto-enrichissement";
import { storageRead, storageWrite } from "@/lib/storage";
import {
  FAILLE_IDS,
  dateLimitePv,
  detecterFailles,
  remplirLettreMulti,
  type ExtractedData,
  type RegleDetection,
} from "@/lib/moteur";
import { generateLettrePdf } from "@/lib/lettre-pdf";
import { extrairePv, getOcrProvider, fusionnerPrefill } from "@/lib/ocr";
import { alignerDocType, lireCategorie } from "@/lib/doc-v2";
import { notifierStatut } from "@/lib/notifications";
import {
  detecterProcedure,
  lireMontant,
  lireVoieProcedure,
  type VoieProcedureDetectee,
} from "@/lib/procedure";
import { prixBase, prixDossier } from "@/lib/tarifs";
import {
  formaterLettreOfficielle,
  identiteExtrait,
  type CanalEnvoi,
  type DocTypeAnalyse,
} from "@/lib/envoi";
import {
  listePiecesJointes,
  recupererPreuvesPourDossierId,
  typesPreuvesPourFailles,
} from "@/lib/preuves-api";
import {
  faillesDepuisReponses,
  lireReponses,
  preuvesPourReponses,
  fusionnerQuestionsDynamiques,
} from "@/lib/questions";
import { verifierSiret } from "@/lib/siret";
import { contexteEtalonnage } from "@/lib/etalonnage";
// eslint-disable-next-line @typescript-eslint/no-explicit-any
import {
  estPackTelecours,
  genererPackTelecours,
  texteReferePour,
  type PackTelecours,
} from "@/lib/pack-telerecours";
import {
  activerDepotEnLigne,
  marquerDepotEnvoye,
  peutActiverDepotEnLigne,
} from "@/lib/lien-depot";

const ALLOWED_MIME = ["image/jpeg", "image/png", "image/webp", "application/pdf"];
const MAX_SIZE = 8 * 1024 * 1024; // 8 Mo

export type CreateDossierState = { error?: string } | undefined;

export async function createDossier(
  _prev: CreateDossierState,
  formData: FormData,
): Promise<CreateDossierState> {
  const user = await requireUser();

  const type = formData.get("type");
  const file = formData.get("pv");
  const signature = String(formData.get("signature") ?? "");

  const parsedType = z.enum(["AMENDE", "SUSPENSION"]).safeParse(type);
  if (!parsedType.success) {
    return { error: "Type d'infraction invalide." };
  }

  if (!(file instanceof File) || file.size === 0) {
    return { error: "Veuillez sélectionner votre avis de contravention." };
  }
  if (!ALLOWED_MIME.includes(file.type)) {
    return { error: "Format non supporté (JPEG, PNG, WebP ou PDF)." };
  }
  if (file.size > MAX_SIZE) {
    return { error: "Fichier trop volumineux (maximum 8 Mo)." };
  }

  // Parcours analyse d'abord : le dépôt est gratuit, le paiement n'intervient
  // qu'après le scoring si une faille est validée (le crédit sera débité à ce moment-là).
  const ext = (file.name.split(".").pop() ?? "jpg").replace(/[^a-z0-9]/gi, "");
  const safeName = `pv/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const buffer = Buffer.from(await file.arrayBuffer());
  const pvUrl = await storageWrite(safeName, buffer);

  const prix = prixBase(parsedType.data);

  // Signature du client capturée au dépôt : stockée une fois sur le profil,
  // réutilisée pour chaque lettre (plus besoin de la retracer par dossier).
  // Best-effort : en cas d'échec, le dépôt continue sans signature enregistrée.
  let signatureUrl: string | null = null;
  if (signature && signature.startsWith("data:image/png;base64,")) {
    try {
      const png = Buffer.from(signature.split(",")[1], "base64");
      if (png.length > 0) {
        signatureUrl = await storageWrite(
          `signatures/sig-${user.id}-${Date.now()}.png`,
          png,
        );
      }
    } catch (e) {
      console.error("createDossier: enregistrement signature échoué", e);
    }
  }

  // Le dossier est créé AVANT l'OCR : un OCR qui pend ou plante (timeout,
  // panne API) ne doit jamais empêcher le dépôt — le PV est déjà stocké et le
  // client retombe sur la saisie manuelle (bannière ?ocr=echec).
  const dossier = await prisma.$transaction(async (tx) => {
    if (signatureUrl) {
      await tx.user.update({
        where: { id: user.id },
        data: { signatureUrl },
      });
    }
    const d = await tx.dossier.create({
      data: {
        userId: user.id,
        type: parsedType.data,
        statut: "EN_ANALYSE",
        pvUrl,
        pvTexte: null, // complété après l'OCR (best-effort)
        prix,
        extractedData: {},
      },
    });
    await tx.dossierEvent.create({
      data: { dossierId: d.id, type: "CREATION" },
    });
    return d;
  });

  // OCR (garde-fou human-in-the-loop) : pré-remplit le formulaire d'analyse,
  // jamais l'analyse finale — un humain vérifie puis soumet. Borné par le
  // watchdog d'`extrairePv` ; tout échec laisse le dossier créé sans texte.
  let ocrOk = false;
  const tOcr = Date.now();
  try {
    const ocr = await extrairePv(buffer, file.name);
    // Trace unique et exploitable en prod : provider, format, succès, volumétrie.
    console.log(
      JSON.stringify({
        evt: "createDossier:ocr",
        provider: getOcrProvider(),
        mime: file.type,
        ok: Boolean(ocr),
        chars: ocr?.texte?.length ?? 0,
        ms: Date.now() - tOcr,
      }),
    );
    if (ocr) {
      // Fusion : champs structurés du provider (Gemini) d'abord, puis
      // complément par les regex locales — l'ancien « struct OU regex »
      // laissait « Nom » vide sur les PDF à couche texte (lecture locale
      // sans extrait) et perdait prefecture/duree/motif sans Gemini.
      const prefill: Record<string, unknown> = fusionnerPrefill(
        ocr.extrait,
        ocr.texte,
      );
      // Objets du contrat OCR v2 : `fusionnerPrefill` ne duplique que les
      // chaînes — le document structuré et la mesure technique sont repris
      // tels quels du provider, puis `docType` est aligné sur la catégorie
      // (source de vérité : jamais de mismatch catégorie/docType).
      const dv = ocr.extrait?.doc_v2;
      if (dv && typeof dv === "object") prefill.doc_v2 = dv;
      const mesure = ocr.extrait?.mesure;
      if (mesure && typeof mesure === "object") prefill.mesure = mesure;
      alignerDocType(prefill, ocr.texte);
      await prisma.dossier.update({
        where: { id: dossier.id },
        data: { pvTexte: ocr.texte, extractedData: prefill as object },
      });
      ocrOk = true;
    }
  } catch (e) {
    console.error(
      "[createDossier] OCR indisponible :",
      e instanceof Error ? `${e.name}: ${e.message}` : String(e),
    );
  }
  if (!ocrOk) {
    // Diagnostic prod : un OCR sans résultat laisse le dossier sans texte ni
    // pré-remplissage — le scan/scoring semble « ne rien détecter ». La cause
    // la plus fréquente est un provider non configuré (getOcrProvider →
    // "aucun") ou une clé API manquante/épuisée.
    console.error(
      `createDossier: OCR sans résultat (provider=${getOcrProvider()}, type=${file.type})`,
    );
  }

  revalidatePath("/dashboard");
  // Échec OCR signalé au client (bannière sur la page du dossier) : sans cela,
  // le formulaire s'affiche vide sans explication, car le pré-remplissage
  // n'est qu'un confort — la saisie manuelle reste le chemin principal.
  redirect(
    ocrOk
      ? `/dashboard/cases/${dossier.id}`
      : `/dashboard/cases/${dossier.id}?ocr=echec`,
  );
}

const analyseSchema = z.object({
  nom: z.string().trim().min(1, "Nom requis"),
  plaque: z.string().trim().optional(),
  num_pv: z.string().trim().min(1, "Numéro PV requis"),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date invalide"),
  heure: z.string().trim().optional(),
  montant: z.string().trim().optional(),
  // Choix du client **uniquement** quand la détection est impossible (montant
  // illisible/hors barème) : la détection serveur reste prioritaire sinon.
  voieProcedure: z
    .enum([
      "AMENDE_FORFAITAIRE",
      "CONTENTIEUX_CONTRAVENTION",
      "DELIT",
      "",
    ])
    .optional()
    .transform((v) => (v === "" ? undefined : v)),
  numTelePaiement: z.string().trim().optional(),
  cle: z.string().trim().optional(),
  typeRadar: z.string().trim().optional(),
  radarId: z.string().trim().optional(),
  adresse: z.string().trim().optional(),
  lieu: z.string().trim().optional(),
  prefecture: z.string().trim().optional(),
  duree: z.string().trim().optional(),
  motif: z.string().trim().optional(),
  // Référé-suspension (art. L. 521-2 CJA) — noms identiques aux variables du
  // template {metier}/{entreprise}/{risque_licenciement}. Saisie humaine
  // facultative (SUSPENSION) ; jamais extraite du texte.
  metier: z.string().trim().optional(),
  entreprise: z.string().trim().optional(),
  risque_licenciement: z.string().trim().optional(),
});

export type AnalyseState = { error?: string } | undefined;

export async function analyserDossier(
  _prev: AnalyseState,
  formData: FormData,
): Promise<AnalyseState> {
  const user = await requireUser();

  const dossierId = String(formData.get("dossierId") ?? "");
  const parsed = analyseSchema.safeParse(Object.fromEntries(formData));

  if (!parsed.success) {
    return {
      error: "Champs obligatoires manquants ou invalides (nom, plaque, n° PV, date).",
    };
  }

  const dossier = await prisma.dossier.findFirst({
    where: { id: dossierId, userId: user.id },
  });
  if (!dossier) {
    return { error: "Dossier introuvable." };
  }
  if (dossier.statut !== "EN_ANALYSE") {
    return { error: "Ce dossier n'est plus en attente d'analyse." };
  }

  const failles = await prisma.failleJuridique.findMany({
    where: { statut: "ACTIVE", typeInfraction: dossier.type },
  });

  // Champs OCR non éditables (ex : date de vérification du cinémomètre) :
  // repris du pré-remplissage du dépôt pour survivre à la réécriture du
  // formulaire (human-in-the-loop sur les champs visibles seulement).
  const anterieur = (dossier.extractedData ?? {}) as Record<string, unknown>;
  // Champs pack 3F/48SI extraits à l'OCR (non éditables au formulaire) :
  // repris du pré-remplissage comme dateVerificationAppareil — sans ce
  // portage, `analyseSchema` (zod, strip inconnus) les jetterait et les
  // règles à docType/horodatage ne matcheraient jamais.
  const chaine = (v: unknown): string | undefined =>
    typeof v === "string" && v.trim() ? v.trim() : undefined;
  const nombre = (v: unknown): number | undefined => {
    if (typeof v === "number") return Number.isFinite(v) ? v : undefined;
    if (typeof v === "string" && v.trim()) {
      const n = Number(v.trim().replace(",", "."));
      if (Number.isFinite(n)) return n;
    }
    return undefined;
  };
  const docTypeAnt = chaine(anterieur.docType);
  const pointsAnt = Number(anterieur.pointsRetiresMemesDate);
  // OCR v2 (lots N1+N2) : classification, miroirs numériques et structures —
  // portés explicitement (jamais génériquement : `analyseSchema` strip les
  // clés inconnues, et un portage total recopierait les cases cochées).
  const categorieAnt = lireCategorie(anterieur.categorie);
  const soldeAnt = nombre(anterieur.soldePoints);
  const retraitAnt = nombre(anterieur.pointsEncourus);
  const docV2Ant = anterieur.doc_v2;
  const mesureAnt = anterieur.mesure;

  const data: ExtractedData = {
    ...parsed.data,
    // Questionnaire ciblé dynamique (registre `questions.ts`) : seules les
    // cases cochées écrivent une clé — contexte juriste + preuves externes.
    // Les questions du catalogue veille 2.0 (failles ACTIVE déjà chargées
    // plus haut) suivent les mêmes règles : clé = id, jamais de fondement.
    ...lireReponses(
      formData,
      fusionnerQuestionsDynamiques(
        failles.map((f) => f.questionsDynamiques),
      ),
    ),
    plaqueIncorrecte: formData.get("plaqueIncorrecte") === "on",
    ...(categorieAnt ? { categorie: categorieAnt } : {}),
    ...(chaine(anterieur.neph) ? { neph: chaine(anterieur.neph) } : {}),
    ...(chaine(anterieur.libelleInfraction)
      ? { libelleInfraction: chaine(anterieur.libelleInfraction) }
      : {}),
    ...(chaine(anterieur.dateEmission)
      ? { dateEmission: chaine(anterieur.dateEmission) }
      : {}),
    ...(soldeAnt !== undefined ? { soldePoints: soldeAnt } : {}),
    ...(retraitAnt !== undefined ? { pointsEncourus: retraitAnt } : {}),
    ...(typeof docV2Ant === "object" && docV2Ant !== null
      ? { doc_v2: docV2Ant as ExtractedData["doc_v2"] }
      : {}),
    ...(typeof mesureAnt === "object" &&
    mesureAnt !== null &&
    "valeur" in mesureAnt
      ? { mesure: mesureAnt as ExtractedData["mesure"] }
      : {}),
    ...(typeof anterieur.dateVerificationAppareil === "string"
      ? { dateVerificationAppareil: anterieur.dateVerificationAppareil }
      : {}),
    ...(docTypeAnt === "3F" ||
    docTypeAnt === "48SI" ||
    docTypeAnt === "AMENDE"
      ? { docType: docTypeAnt }
      : {}),
    ...(chaine(anterieur.dateSignatureArrete)
      ? { dateSignatureArrete: chaine(anterieur.dateSignatureArrete) }
      : {}),
    ...(chaine(anterieur.heureSignatureArrete)
      ? { heureSignatureArrete: chaine(anterieur.heureSignatureArrete) }
      : {}),
    ...(chaine(anterieur.dateStage)
      ? { dateStage: chaine(anterieur.dateStage) }
      : {}),
    ...(chaine(anterieur.dateNotification)
      ? { dateNotification: chaine(anterieur.dateNotification) }
      : {}),
    ...(Number.isFinite(pointsAnt) && pointsAnt > 0
      ? { pointsRetiresMemesDate: pointsAnt }
      : {}),
    // Marqueur de débit différé (« paiement déjà signalé ») : survit aux
    // relances d'analyse — c'est lui qui décide du débit à la validation.
    ...(typeof anterieur.creditConsome === "boolean"
      ? { creditConsome: anterieur.creditConsome }
      : {}),
  };

  // Garde-fou « amende déjà payée » : la case questionnaire impose une
  // confirmation explicite — recontrôlée ici côté serveur (le formulaire
  // n'est qu'une guidance : on ne confie jamais un tel contrôle à l'UI).
  const dejaPaye = data.paiementDejaFait === true;
  if (dejaPaye && formData.get("paiementConfirme") !== "on") {
    return {
      error:
        "Paiement déjà signalé : prenez connaissance de l'encart puis cochez la confirmation avant de lancer l'analyse.",
    };
  }

  // OCR v2 : la catégorie est la source de vérité du `docType` (et le supprime
  // pour les catégories hors pack : 48N, annulation, INCONNU). Anciens
  // dossiers sans catégorie → no-op (leur docType survit). Le texte brut
  // permet aussi le garde-fou R0 : suspension de droit commun → pas de 3F.
  alignerDocType(data as Record<string, unknown>, dossier.pvTexte ?? undefined);

  // Vérification du SIRET (lot 4) : best-effort borné — l'API publique est la
  // seule source de vérité sur l'existence de l'établissement (jamais de clé
  // de contrôle locale, testée empiriquement). `null` = sans effet.
  if (data.siret) {
    const info = await verifierSiret(data.siret);
    if (info) {
      data.siretInfo = {
        denomination: info.denomination,
        adresse: info.adresse,
        etatAdministratif: info.etatAdministratif,
      };
      // Pré-remplissage de {entreprise} pour le référé (chantier 2) : la
      // dénomination officielle de l'API vaut mieux qu'une saisie libre.
      if (!data.entreprise) data.entreprise = info.denomination;
    }
  }

  // Voie de procédure (amende uniquement) : la détection serveur fait foi dès
  // qu'elle est confiante (barème des classes 1-5 ou marqueur de délit) — le
  // formulaire n'est qu'une aide, jamais une source de sous-facturation. Quand
  // le montant est illisible/hors barème, le client doit choisir : aucun débit
  // n'est déclenché avant confirmation.
  let voie: VoieProcedureDetectee = "INCONNU";
  if (dossier.type === "AMENDE") {
    const detection = detecterProcedure({
      montant: data.montant,
      texte: dossier.pvTexte,
    });
    voie = detection.voie;
    let classe = detection.classe;
    let consignation = detection.consignationMontant;
    if (voie === "INCONNU") {
      const choix = lireVoieProcedure(formData.get("voieProcedure"));
      if (!choix) {
        return {
          error:
            "Montant non reconnu : précisez la procédure de votre document (amende simple, contentieux ou délit).",
        };
      }
      voie = choix;
      if (choix === "CONTENTIEUX_CONTRAVENTION") {
        consignation = lireMontant(data.montant);
        classe = null;
      }
    }
    data.voieProcedure = voie;
    if (classe) data.classeContravention = classe;
    else delete data.classeContravention;
    if (consignation) data.consignationMontant = consignation;
    else delete data.consignationMontant;
  } else {
    delete data.voieProcedure;
  }

  // Délit détecté : SOS Amende ne traite pas les délits (avocat nécessaire).
  // Aucun débit, aucune lettre, aucune candidature — le dossier est orienté et
  // le client peut agir immédiatement. La détection serveur prime sur un choix
  // contradictoire du formulaire.
  if (voie === "DELIT") {
    const oriente = await prisma.$transaction(async (tx) => {
      const maj = await tx.dossier.updateMany({
        where: { id: dossier.id, statut: "EN_ANALYSE" },
        data: {
          extractedData: data as object,
          statut: "AVOCAT_REQUIS",
          voieProcedure: "DELIT",
          classeContravention: null,
          consignationMontant: null,
          prix: 0,
          failleJuridiqueId: null,
          lettreGeneree: null,
          refereGenere: null,
        },
      });
      if (maj.count === 0) return false;
      await tx.dossierFaille.deleteMany({ where: { dossierId: dossier.id } });
      await tx.dossierEvent.create({
        data: {
          dossierId: dossier.id,
          type: "ANALYSE",
          detail:
            "Délit détecté : aucun traitement possible par SOS Amende — orientation vers un avocat (aucun débit)",
        },
      });
      return true;
    });
    if (!oriente) {
      return { error: "Ce dossier n'est plus en attente d'analyse." };
    }
    await notifierStatut(dossier.id).catch(() => false);
    revalidatePath(`/dashboard/cases/${dossier.id}`);
    revalidatePath("/dashboard/juriste");
    redirect(`/dashboard/cases/${dossier.id}?avocat=1`);
  }

  // Contexte étalonnage (preuve d'entretien du radar) : registre admin
  // prioritaire, sinon date de vérification lue sur le PV — permet au moteur
  // de détecter la faille « certificat d'étalonnage » avec échéance.
  const { dateExpiration: dateExpirationEtalonnage, preuveUrl: preuveRegistre } =
    await contexteEtalonnage(data);

  // Détection par scan (données extraites + texte brut du PV) : toutes les
  // failles candidates sont enregistrées ; le juriste confirme/rejette ensuite.
  const candidats = detecterFailles(
    data,
    dossier.pvTexte,
    failles.map((f) => ({
      id: f.id,
      reglesDetection: f.reglesDetection as unknown as
        | RegleDetection[]
        | null,
    })),
    { dateExpirationEtalonnage },
  );

  // Garde-fou lettre vide (lot M) : la faille principale — celle qui déclenche
  // le débit et porte la lettre — doit avoir un template rédigé. Une faille
  // ACTIVE sans template (ex. faille validée depuis la veille avant rédaction
  // du modèle) reste enregistrée candidate, visible côté juriste, mais
  // n'alimente jamais une lettre ni aucun débit.
  const principalId =
    candidats.find(
      (id) =>
        (failles.find((f) => f.id === id)?.templateLettre ?? "").trim().length >
        0,
    ) ?? null;
  const faille = principalId
    ? failles.find((f) => f.id === principalId) ?? null
    : null;

  if (principalId === FAILLE_IDS.etalonnage && preuveRegistre) {
    data.preuveEtalonnage = preuveRegistre;
  }

  // Lettre multi-arguments : toutes les failles candidates **avec template**
  // sont juxtaposées dans une seule lettre (chaque section reste un template
  // admin validé). La première candidate templateée reste la principale.
  const candidatsFailles = candidats
    .map((id) => failles.find((f) => f.id === id))
    .filter(
      (f): f is NonNullable<typeof f> =>
        !!f && f.templateLettre.trim().length > 0,
    );
  const lettre = remplirLettreMulti(
    candidatsFailles.map((f) => ({
      id: f.id,
      titreFaille: f.titreFaille,
      articleLoi: f.articleLoi,
      templateLettre: f.templateLettre,
    })),
    data,
  );

  // Débit du crédit au moment de la mise en file de validation (payant) :
  // - faille + crédit disponible  → débit immédiat → EN_ATTENTE_VALIDATION ;
  // - faille sans crédit          → EN_ATTENTE_PAIEMENT (le virement est
  //   rattaché au dossier ; à sa validation l'admin consomme le crédit, net à
  //   zéro) ;
  // - sans faille (aucune lettre) → EN_ATTENTE_VALIDATION sans débit : le
  //   juriste examine le fondement, le crédit n'est jamais débité.
  // - « déjà payé » signalé       → aucun débit ici (débit différé) : le
  //   crédit n'est consommé qu'à la validation du juriste, jamais à la
  //   relance, et un rejet ne rembourse pas un crédit jamais débité.
  // Idempotence financière : le crédit n'est débité qu'à la PREMIÈRE analyse
  // du dossier — une relance après retour du juriste (EN_ANALYSE) ne
  // redébite jamais. Un ANALYSE event existe dès la première analyse passée.
  const dejaAnalyse = !!(await prisma.dossierEvent.findFirst({
    where: { dossierId: dossier.id, type: "ANALYSE" },
    select: { id: true },
  }));

  const contentieux = voie === "CONTENTIEUX_CONTRAVENTION";
  // Un dossier contentieux est payé à part (149 €) : la validation du virement
  // ne crédite pas le compteur de crédits. On vérifie donc l'existence d'un
  // paiement contentieux encaissé pour ne jamais renvoyer au paywall après un
  // retour du juriste (relance d'analyse).
  const paiementContentieuxValide = contentieux
    ? await prisma.payment.findFirst({
        where: { dossierId: dossier.id, kind: "CONTENTIEUX", status: "PAID" },
        select: { id: true },
      })
    : null;

  // Débit différé : « déjà payé » déclaré à la PREMIÈRE analyse → le crédit
  // n'est pas consommé ici, `creditConsome: false` marque l'attente — le
  // juriste le débite à la validation (validerDossier) et un rejet ne
  // rembourse que ce qui a réellement été débité (rejeterDossier). Le
  // contentieux n'utilise jamais le crédit générique.
  const differe = !contentieux && dejaPaye && !dejaAnalyse;
  if (differe) data.creditConsome = false;

  let statut: "EN_ATTENTE_VALIDATION" | "EN_ATTENTE_PAIEMENT";
  // Référé-suspension (pack Télérecours) : généré en même temps que la lettre
  // pour que le juriste le relise — et l'éventuellement le modifie — avant de
  // valider. `null` hors suspension, ou sans template validé ni urgence
  // professionnelle (jamais de texte hors base).
  const refereGenere = texteReferePour({
    type: dossier.type,
    templateRefere: faille?.templateRefere ?? null,
    data,
  });
  try {
    statut = await prisma.$transaction(async (tx) => {
      let next: "EN_ATTENTE_VALIDATION" | "EN_ATTENTE_PAIEMENT";
      // Source de vérité du remboursement (`rejeterDossier`) : `true` uniquement
      // si un crédit a réellement été débité. Sur une relance, on n'écrit rien
      // (le marquage de la 1ʳᵉ analyse est conservé — jamais de double débit).
      let creditDebite = false;
      if (contentieux) {
        // Offre séparée à 149 € : jamais de crédit générique. Sans faille, le
        // juriste examine quand même (pas de paiement déclenché à tort).
        next =
          faille && !paiementContentieuxValide
            ? "EN_ATTENTE_PAIEMENT"
            : "EN_ATTENTE_VALIDATION";
      } else if (faille && !dejaAnalyse && !dejaPaye) {
        const debit = await tx.user.updateMany({
          where: { id: user.id, credits: { gte: 1 } },
          data: { credits: { decrement: 1 } },
        });
        if (debit.count === 1) {
          next = "EN_ATTENTE_VALIDATION";
          creditDebite = true;
        } else {
          next = "EN_ATTENTE_PAIEMENT";
        }
      } else {
        next = "EN_ATTENTE_VALIDATION";
      }

      // Verrou anti double-soumission (double-clic / deux onglets) : l'écriture
      // du dossier n'est acceptée que depuis EN_ANALYSE — sinon on annule la
      // transaction entière, rollback du débit compris.
      const maj = await tx.dossier.updateMany({
        where: { id: dossier.id, statut: "EN_ANALYSE" },
        data: {
          extractedData: data as object,
          failleJuridiqueId: faille?.id ?? null,
          lettreGeneree: lettre,
          refereGenere,
          dateLimite: dateLimitePv(data.date, dossier.type),
          statut: next,
          // Prix de base de l'offre (l'option LRAR est ajoutée au paiement).
          prix: prixDossier(dossier.type, voie),
          // La voie est aussi une colonne (lecture rapide fiche/paiement).
          ...(dossier.type === "AMENDE"
            ? {
                voieProcedure: voie,
                classeContravention: data.classeContravention ?? null,
                consignationMontant: data.consignationMontant ?? null,
              }
            : {}),
          ...(creditDebite ? { creditDebite: true } : {}),
        },
      });
      if (maj.count === 0) throw new Error("ANALYSE_DEJA_TRAITEE");
      await tx.dossierEvent.create({
        data: {
          dossierId: dossier.id,
          type: "ANALYSE",
          ...(differe
            ? {
                detail:
                  "Paiement déjà signalé — débit du crédit différé à la validation du juriste",
              }
            : {}),
        },
      });
      await tx.dossierEvent.create({
        data: {
          dossierId: dossier.id,
          type: faille ? "LETTRE_GENEREE" : "EN_ATTENTE",
          detail:
            next === "EN_ATTENTE_PAIEMENT"
              ? contentieux
                ? "En attente du paiement contentieux (149 €, virement bancaire)"
                : "En attente de paiement (virement bancaire)"
              : undefined,
        },
      });
      // Réinitialise les candidatures puis rejoue toutes les failles détectées
      // (une relance de l'analyse relance aussi la détection automatique).
      await tx.dossierFaille.deleteMany({ where: { dossierId: dossier.id } });
      for (const failleId of candidats) {
        await tx.dossierFaille.create({
          data: { dossierId: dossier.id, failleId, statut: "CANDIDATE" },
        });
      }
      // N3 — faits déclarés au questionnaire : une réponse peut établir un fait
      // que le texte du PV ne révèle pas. On ajoute la faille ACTIVE
      // correspondante en **candidate** (jamais dans la lettre, jamais
      // principale) : le juriste la voit et reste seul décideur.
      const documentType = (() => {
        const d = data as { type?: string; docType?: string };
        return d?.type ?? d?.docType ?? "AMENDE";
      })();
      const parsedType = z.enum(["AMENDE", "SUSPENSION"]).safeParse(documentType);
      // A+B — protection divergence client / OCR (si le client se trompe de type)
      if (parsedType.success && dossier.extractedData) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const ocrDocType = (dossier.extractedData as any)?.docType ?? (dossier.extractedData as any)?.doc_v2?.categorie ?? null;
        if (ocrDocType && ocrDocType !== parsedType.data && (ocrDocType === "AMENDE" || ocrDocType === "3F" || ocrDocType === "48SI" || ocrDocType === "SUSPENSION")) {
          // Divergence détectée : avertissement sans bloquer l'analyse (le juriste valide)
          // Peut être tracé dans une variable ou un événement ; ici simple log défensif
          console.warn(`[Divergence OCR/Client] Dossier ${dossier.id} : formulaire=${parsedType.data} vs OCR=${ocrDocType}`);
        }
      }
      const parReponses = await faillesDepuisReponses(
        data,
        failles.map((f) => f.id),
        parsedType.success ? parsedType.data as "AMENDE" | "SUSPENSION" : "AMENDE",
      );
      for (const failleId of parReponses) {
        if (candidats.includes(failleId)) continue;
        await tx.dossierFaille.create({
          data: { dossierId: dossier.id, failleId, statut: "CANDIDATE" },
        });
      }
      return next;
    });
  } catch {
    return { error: "Ce dossier n'est plus en attente d'analyse." };
  }

  // Preuves externes (météo, fiche radar, travaux) récupérées automatiquement
  // depuis les sources publiques, uniquement pour les types pertinents aux
  // failles détectées (voir PREUVES_PAR_FAILLE) **et** aux réponses du
  // questionnaire (N2) — pas de preuve hors-sujet. Best-effort : ne bloque
  // jamais l'analyse.
  const typesPreuves = typesPreuvesPourFailles(candidats);
  for (const t of preuvesPourReponses(data)) typesPreuves.add(t);
  after(() => recupererPreuvesPourDossierId(prisma, dossier.id, {
    types: typesPreuves,
  }).catch((e) => console.error("recupererPreuvesPourDossierId async error:", e)));

  // Habillage professionnel (en-tête, Objet, Madame, Monsieur, politesse) —
  // voir formaterLettreOfficielle ; idempotent, laisse l'argumentation intacte.
  // La liste des pièces jointes figure une seule fois, sous la signature, dans
  // le PDF signé (voir generateLettrePdf) — jamais doublée dans le corps.
  // En-tête : identité extraite du document par l'OCR (nom + prénom + adresse),
  // profil `User.name` en repli seulement (voir identiteExtrait).
  const identite = identiteExtrait(data, user.name);
  const lettreFinale = formaterLettreOfficielle({
    type: dossier.type,
    corps: lettre ?? "",
    docType: data.docType,
    numRef: data.num_pv,
    dateRef: data.date,
    nom: identite.nom,
    adresse: identite.adresse,
    date: new Date().toISOString().slice(0, 10),
  });
  if (lettreFinale !== lettre) {
    await prisma.dossier.update({
      where: { id: dossier.id },
      data: { lettreGeneree: lettreFinale },
    });
  }

  // Notification (défensive : sans AUTH_RESEND_KEY, aucun e-mail envoyé).
  await notifierStatut(dossier.id).catch(() => false);

  // Enrichissement IA post-analyse (fire-and-forget, après la réponse) :
  // suggestions cas d'espèce versées dans les candidatures du dossier
  // (drawer juriste), sans lettre régénérée ni statut touché — voir
  // `src/lib/auto-enrichissement.ts`. `after` s'exécute même si le
  // redirect ci-dessous lève.
  after(() => enrichirApresOcr(dossier.id).catch(() => undefined));

  revalidatePath(`/dashboard/cases/${dossier.id}`);
  revalidatePath("/dashboard/juriste");
  if (statut === "EN_ATTENTE_PAIEMENT") {
    redirect(`/dashboard/paiement/${dossier.id}`);
  }
  redirect(`/dashboard/cases/${dossier.id}?analyse=ok`);
}

export type SignerState = { error?: string } | undefined;

export async function signerDossier(
  _prev: SignerState,
  formData: FormData,
): Promise<SignerState> {
  const user = await requireUser();

  const dossierId = String(formData.get("dossierId") ?? "");
  const signature = String(formData.get("signature") ?? "");

  const dossier = await prisma.dossier.findFirst({
    where: { id: dossierId, userId: user.id },
    include: {
      preuves: { orderBy: { createdAt: "asc" } },
      failleJuridique: { select: { templateRefere: true } },
    },
  });
  if (!dossier) {
    return { error: "Dossier introuvable." };
  }
  if (dossier.statut !== "A_VERIFIER" && dossier.statut !== "EN_ATTENTE_PRE_SIGNATURE") {
    return { error: "La signature n'est disponible qu'une fois la lettre validée par un juriste." };
  }
  if (!dossier.lettreGeneree) {
    return { error: "Aucune lettre à signer." };
  }

  // Le crédit est déjà consommé à l'analyse (EN_ATTENTE_VALIDATION) ou par la
  // validation du virement (EN_ATTENTE_PAIEMENT → EN_ATTENTE_VALIDATION) :
  // la signature ne débite plus rien.

  // Signature : celle capturée au dépôt (User.signatureUrl) est réutilisée ;
  // une nouvelle trace écrase la précédente et devient la référence du profil.
  const userRow = await prisma.user.findUnique({
    where: { id: user.id },
    select: { signatureUrl: true },
  });
  let signatureDataUrl: string | null = null;
  let signatureUrl = userRow?.signatureUrl ?? null;
  if (signature.startsWith("data:image/png;base64,")) {
    signatureDataUrl = signature;
    const png = Buffer.from(signature.split(",")[1], "base64");
    if (png.length > 0) {
      try {
        signatureUrl = await storageWrite(
          `signatures/sig-${user.id}-${Date.now()}.png`,
          png,
        );
        await prisma.user.update({
          where: { id: user.id },
          data: { signatureUrl },
        });
      } catch (e) {
        console.error("signerDossier: maj signature profil échouée", e);
      }
    }
  } else if (signatureUrl) {
    const sig = await storageRead(signatureUrl);
    if (sig) {
      signatureDataUrl = `data:image/png;base64,${sig.toString("base64")}`;
    }
  }
  if (!signatureDataUrl) {
    return { error: "Signature invalide." };
  }

  const dataExt = (dossier.extractedData ?? {}) as Record<string, unknown>;
  const piecesJointes = listePiecesJointes({
    type: dossier.type,
    conditionsMeteo: dossier.conditions_meteo,
    numRef: typeof dataExt["num_pv"] === "string" ? (dataExt["num_pv"] as string) : null,
    preuves: dossier.preuves.map((p) => ({ nom: p.nom, type: p.type, url: p.url })),
  });

  // Habillage aligné sur le canal (une suspension Télérecours devient une
  // requête adressée au tribunal administratif) — idempotent.
  const identiteSign = identiteExtrait(dataExt, null);
  const lettreFinale = formaterLettreOfficielle({
    type: dossier.type,
    corps: dossier.lettreGeneree,
    docType: dataExt["docType"] as DocTypeAnalyse | null,
    canal: (dossier.canalEnvoi as CanalEnvoi | null) ?? null,
    numRef: typeof dataExt["num_pv"] === "string" ? (dataExt["num_pv"] as string) : null,
    dateRef: typeof dataExt["date"] === "string" ? (dataExt["date"] as string) : null,
    nom: identiteSign.nom,
    adresse: identiteSign.adresse,
    date: new Date().toISOString().slice(0, 10),
  });
  if (lettreFinale !== dossier.lettreGeneree) {
    await prisma.dossier.update({
      where: { id: dossier.id },
      data: { lettreGeneree: lettreFinale },
    });
  }

  const pdfBuffer = await generateLettrePdf(
    lettreFinale,
    signatureDataUrl,
    piecesJointes,
  );
  const pdfName = `pdfs/lettre-${dossier.id}.pdf`;
  const pdfUrl = await storageWrite(pdfName, pdfBuffer);

  // Pack Télérecours (Cas B) : la validation juriste n'a pas pu le
  // produire (lettre alors non signée) — il est généré ici, avec la
  // signature, et rattaché au courrier créé. Best-effort jamais bloquant.
  let packUrls: PackTelecours | undefined;
  if (
    estPackTelecours({
      type: dossier.type,
      canal: dossier.canalEnvoi,
      docType: dataExt["docType"],
    })
  ) {
    try {
      packUrls = await genererPackTelecours({
        dossierId: dossier.id,
        lettreFinale,
        data: dataExt as unknown as ExtractedData,
        templateRefere: dossier.failleJuridique?.templateRefere ?? null,
        refereGenere: dossier.refereGenere ?? null,
        piecesJointes,
        signatureDataUrl,
        numRef: typeof dataExt["num_pv"] === "string" ? dataExt["num_pv"] : null,
        dateDecision: typeof dataExt["date"] === "string" ? dataExt["date"] : null,
      });
    } catch (e) {
      console.error("signerDossier: pack Télérecours non généré", e);
    }
  }

  await prisma.courrier.create({
    data: {
      dossierId: dossier.id,
      signatureUrl,
      pdfUrl,
      ...(packUrls ? { packUrls } : {}),
    },
  });

  await prisma.$transaction([
    prisma.dossier.update({
      where: { id: dossier.id },
      data: { statut: "PRET" },
    }),
    prisma.dossierEvent.create({
      data: { dossierId: dossier.id, type: "SIGNATURE" },
    }),
  ]);

  revalidatePath(`/dashboard/cases/${dossier.id}`);
  revalidatePath("/dashboard/juriste");
  revalidatePath(`/dashboard/juriste/${dossier.id}`);

  // Signature du client = feu vert au dépôt : pour un canal en ligne validé
  // (ANTAI/Télérecours), le lien de dépôt assisté est émis maintenant (le
  // dossier est PRET) — le client dépose sa contestation sur le portail
  // officiel puis marque le dossier comme déposé. Canal LRAR : SOS Amende
  // envoie par nos soins (le juriste déclenche le dépôt). Un dossier hérité en
  // A_VERIFIER (jamais validé) reste en PRET : le juriste le validera avant
  // tout dépôt.
  if (peutActiverDepotEnLigne(dossier.canalEnvoi) && dossier.valideLe) {
    await activerDepotEnLigne({
      dossierId: dossier.id,
      canal: dossier.canalEnvoi,
    }).catch(() => null);
    redirect(`/dashboard/cases/${dossier.id}?signe=ok&lien=envoye`);
  }
  redirect(`/dashboard/cases/${dossier.id}?signe=ok`);
}

export type DemanderAvocatState = { error?: string } | undefined;

/**
 * Mise en relation avocat (PLAN §2) : le client demande une orientation vers
 * un avocat partenaire. Aucune consultation juridique n'est faite ici — un
 * juriste traite la demande et affecte (ou refuse) un partenaire.
 */
export async function demanderAvocat(
  _prev: DemanderAvocatState,
  formData: FormData,
): Promise<DemanderAvocatState> {
  const user = await requireUser();

  const dossierId = String(formData.get("dossierId") ?? "");
  const motif = String(formData.get("motif") ?? "").trim();

  const dossier = await prisma.dossier.findFirst({
    where: { id: dossierId, userId: user.id },
  });
  if (!dossier) {
    return { error: "Dossier introuvable." };
  }

  const existant = await prisma.lawyerMatch.findUnique({
    where: { dossierId: dossier.id },
  });
  if (existant) {
    return { error: "Une demande est déjà en cours pour ce dossier." };
  }

  await prisma.lawyerMatch.create({
    data: {
      dossierId: dossier.id,
      userId: user.id,
      motif: motif || null,
    },
  });

  revalidatePath(`/dashboard/cases/${dossier.id}`);
  return undefined;
}

export type DepotAssisteState = { ok?: boolean; error?: string } | undefined;

/**
 * Dépôt assisté depuis l'espace client (bouton « J'ai déposé ») : le client
 * authentifié confirme avoir déposé sa contestation sur le portail officiel
 * (ANTAI/Télérecours). Garde-fous : propriété du dossier, canal en ligne
 * validé, lettre prête (PRET) — le passage ENVOYE est atomique (delta
 * commun avec la page /recours/finaliser via `marquerDepotEnvoye`).
 */
export async function confirmerDepotClient(
  _prev: DepotAssisteState,
  formData: FormData,
): Promise<DepotAssisteState> {
  const user = await requireUser();

  const dossierId = String(formData.get("dossierId") ?? "");
  const dossier = await prisma.dossier.findFirst({
    where: { id: dossierId, userId: user.id },
  });
  if (!dossier) {
    return { error: "Dossier introuvable." };
  }
  if (!peutActiverDepotEnLigne(dossier.canalEnvoi)) {
    return { error: "Ce dossier est transmis par lettre recommandée, pas en ligne." };
  }

  const res = await marquerDepotEnvoye({
    dossierId: dossier.id,
    canal: dossier.canalEnvoi,
    statut: dossier.statut,
  });
  if (!res.ok) return res;

  revalidatePath(`/dashboard/cases/${dossier.id}`);
  revalidatePath("/dashboard/juriste");
  revalidatePath(`/dashboard/juriste/${dossier.id}`);
  revalidatePath("/dashboard/admin/dossiers");
  return { ok: true };
}