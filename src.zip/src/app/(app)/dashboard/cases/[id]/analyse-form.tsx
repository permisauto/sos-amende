"use client";

import { useActionState } from "react";
import { analyserDossier } from "../actions";
import { questionsPour, type QuestionDynamique } from "@/lib/questions";
import { libellePreuve } from "@/lib/preuve-labels";
import {
  detecterProcedure,
  libelleVoieProcedure,
} from "@/lib/procedure";
import {
  dateRefLibelle,
  libelleDocType,
  numeroRefLibelle,
  titreAnalyse,
  type InfractionType,
} from "@/lib/envoi";

export type AnalysePrefill = {
  nom?: string;
  plaque?: string;
  num_pv?: string;
  date?: string;
  heure?: string;
  montant?: string;
  numTelePaiement?: string;
  cle?: string;
  typeRadar?: string;
  radarId?: string;
  adresse?: string;
  lieu?: string;
  prefecture?: string;
  duree?: string;
  motif?: string;
  plaqueIncorrecte?: boolean;
  paiementDejaFait?: boolean;
  vehiculeCede?: boolean;
  vehiculeVole?: boolean;
  conducteurDifferent?: boolean;
  adresseIncorrecte?: boolean;
  travaux_présents?: boolean;
  conditions_meteo?: string;
  stationnementPanneau?: boolean;
  stationnementGene?: boolean;
  stationnementTicket?: boolean;
  stationnementLieu?: boolean;
  // Lot R3 (2026-10-11) — questions amende : cliché ambigu / marquage effacé
  // (faits déclarés, jamais pré-remplis par l'OCR).
  clicheDeuxVehicules?: boolean;
  marquageEfface?: boolean;
  suspNotifIrreguliere?: boolean;
  suspDelaiNotification?: boolean;
  suspMotifsAbsents?: boolean;
  suspObservations?: boolean;
  suspEthylometreCarnet?: boolean;
  suspSecondSouffle?: boolean;
  suspRefereEngage?: boolean;
  // Pack 3F/48SI — questions dérivées des failles (jamais pré-remplies par
  // l'OCR : ce sont des faits déclarés par le client).
  suspSignataireNonPrefet?: boolean;
  suspPrecedentsNonRecapitules?: boolean;
  suspPointsCumulesJour?: boolean;
  suspStageAvantNotif?: boolean;
  suspSoldeInexact?: boolean;
  // Chantier 2 (2026-10-10) — urgence professionnelle (référé L. 521-2).
  // Lot R1 : radio « Votre urgence » (situation principale).
  urgenceSituation?: string;
  siret?: string;
  // Lot 5 (2026-10-10) — enclavement du domicile (référé L. 521-2).
  domicileEnclave?: boolean;
  // Pack 3F/48SI : classificateur lu à l'OCR (badge informatif — le champ
  // n'est pas éditable ici, il est porté automatiquement à l'analyse).
  docType?: string;
  dateSignatureArrete?: string;
  dateNotification?: string;
  // Référé-suspension (art. L. 521-2 CJA) — noms = variables du template.
  metier?: string;
  entreprise?: string;
  risque_licenciement?: string;
};

export function AnalyseForm({
  dossierId,
  prefill,
  type,
  pvTexte,
  questionsDynamiques,
}: {
  dossierId: string;
  prefill?: AnalysePrefill | null;
  type: InfractionType;
  pvTexte?: string | null;
  /** Veille 2.0 : questions auto-générées par les failles ACTIVE liées. */
  questionsDynamiques?: QuestionDynamique[];
}) {
  const [state, formAction, pending] = useActionState(
    analyserDossier,
    undefined,
  );
  const hasPrefill = !!prefill && Object.keys(prefill).length > 0;
  // Questions conditionnées à la nature du document scanné (et aux champs
  // saisis : motif, lieu) — jamais aux règles des failles (groupe vide
  // impossible). Les questions dynamiques (veille 2.0) complètent le registre.
  const groupes = questionsPour({
    type,
    texte: [pvTexte, prefill?.motif, prefill?.lieu]
      .filter(Boolean)
      .join("\n"),
    // Sous-type lu à l'OCR (3F / 48SI) : conditionne les questions spécifiques
    // du pack (Arrêté préfectoral / Calcul du solde de points).
    docType: prefill?.docType,
    dynamiques: questionsDynamiques,
  });

  // Voie de procédure : information (aucun fondement juridique). Le serveur
  // refait la détection sur les valeurs soumises et fait foi ; le sélecteur
  // n'apparaît que si le document ne permet pas de trancher (montant non
  // reconnu, document illisible) — aucun débit avant confirmation.
  const procedure =
    type === "AMENDE"
      ? detecterProcedure({
          montant: prefill?.montant,
          texte: [pvTexte, prefill?.motif, prefill?.lieu]
            .filter(Boolean)
            .join("\n"),
        })
      : null;

  return (
    <form action={formAction} className="flex flex-col gap-4">
      <input type="hidden" name="dossierId" value={dossierId} />

      <div className="rounded-xl bg-zinc-50 px-4 py-3 text-xs text-zinc-600">
        {hasPrefill ? (
          <>
            Les champs ont été <strong>pré-remplis par lecture automatique
            </strong> {titreAnalyse(type)}. Vérifiez-les avant de
            valider : ils sont ensuite relus par un juriste (vérification
            humaine obligatoire).
            {libelleDocType(prefill?.docType) && (
              <span className="mt-2 block w-fit rounded-full bg-indigo-50 px-3 py-1 text-xs font-semibold text-indigo-700">
                Document classé : {libelleDocType(prefill?.docType)}
              </span>
            )}
          </>
        ) : (
          <>
            Aucun pré-remplissage automatique n&apos;a été détecté (qualité du scan ou champ manquant) — saisissez les informations lues {titreAnalyse(type)} : elles seront vérifiées avant toute génération de lettre (vérification humaine obligatoire).
          </>
        )}
      </div>

      {procedure && (
        <div
          data-testid="voie-procedure"
          className={`rounded-xl border px-4 py-3 text-xs ${
            procedure.voie === "DELIT"
              ? "border-orange-300 bg-orange-50 text-orange-900"
              : procedure.voie === "CONTENTIEUX_CONTRAVENTION"
                ? "border-amber-300 bg-amber-50 text-amber-900"
                : "border-sky-200 bg-sky-50 text-sky-900"
          }`}
        >
          <p className="font-semibold">
            {procedure.voie === "AMENDE_FORFAITAIRE"
              ? "Amende forfaitaire (1re à 3e classe)"
              : procedure.voie === "CONTENTIEUX_CONTRAVENTION"
                ? "Contentieux contraventionnel (4e ou 5e classe)"
                : procedure.voie === "DELIT"
                  ? "Procédure pénale — délit"
                  : "Procédure non déterminée"}
          </p>
          <p className="mt-1">{procedure.motif}</p>
          {procedure.voie === "INCONNU" && (
            <label className="mt-3 flex flex-col gap-1.5">
              <span className="text-sm font-medium">
                Précisez la procédure indiquée sur votre document
              </span>
              <select
                name="voieProcedure"
                required
                className="rounded-xl border border-zinc-300 bg-white px-3 py-2.5 text-sm"
              >
                <option value="">— Choisir —</option>
                {["AMENDE_FORFAITAIRE", "CONTENTIEUX_CONTRAVENTION", "DELIT"].map(
                  (v) => (
                    <option key={v} value={v}>
                      {libelleVoieProcedure(v)}
                    </option>
                  ),
                )}
              </select>
              <span className="text-xs text-zinc-600">
                En cas de doute, vérifiez la mention « amende forfaitaire » ou
                « tribunal de police » sur votre avis.
              </span>
            </label>
          )}
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2">
        <label className="flex flex-col gap-1.5">
          <span className="text-sm font-medium text-zinc-700">Nom</span>
          <input
            name="nom"
            required
            defaultValue={prefill?.nom}
            className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100"
          />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-sm font-medium text-zinc-700">Adresse {type === "SUSPENSION" ? "(titulaire / préfecture)" : "(titulaire)"} — vérifiable</span>
          <input
            name="adresse"
            placeholder="12 rue de Paris, 75001 Paris"
            defaultValue={prefill?.adresse}
            className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100"
          />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-sm font-medium text-zinc-700">Lieu {type === "SUSPENSION" ? "de la rétention" : "de l'infraction"}</span>
          <input
            name="lieu"
            placeholder={type === "SUSPENSION" ? "Route D123, Préfecture de ..." : "Avenue, ville, département"}
            defaultValue={prefill?.lieu}
            className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100"
          />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-sm font-medium text-zinc-700">Plaque {type === "SUSPENSION" ? "(si mentionnée)" : ""}</span>
          <input
            name="plaque"
            required={type === "AMENDE"}
            defaultValue={prefill?.plaque}
            className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100"
          />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-sm font-medium text-zinc-700">
            {numeroRefLibelle(type)}
          </span>
          <input
            name="num_pv"
            required
            defaultValue={prefill?.num_pv}
            className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100"
          />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-sm font-medium text-zinc-700">
            {dateRefLibelle(type)}
          </span>
          <input
            type="date"
            name="date"
            required
            defaultValue={prefill?.date}
            className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100"
          />
        </label>
        {type === "AMENDE" ? (
          <>
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-medium text-zinc-700">Heure</span>
              <input
                name="heure"
                placeholder="14h32"
                defaultValue={prefill?.heure}
                className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100"
              />
            </label>
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-medium text-zinc-700">Montant</span>
              <input
                name="montant"
                placeholder="135,00 €"
                defaultValue={prefill?.montant}
                className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100"
              />
            </label>
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-medium text-zinc-700">
                Type de radar
              </span>
              <input
                name="typeRadar"
                placeholder="Radar fixe / mobile"
                defaultValue={prefill?.typeRadar}
                className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100"
              />
            </label>
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-medium text-zinc-700">
                N° du radar
              </span>
              <input
                name="radarId"
                placeholder="Réf. du radar (si visible)"
                defaultValue={prefill?.radarId}
                className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100"
              />
            </label>
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-medium text-zinc-700">
                N° de télépaiement
              </span>
              <input
                name="numTelePaiement"
                defaultValue={prefill?.numTelePaiement}
                className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100"
              />
            </label>
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-medium text-zinc-700">Clé</span>
              <input
                name="cle"
                defaultValue={prefill?.cle}
                className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100"
              />
            </label>
          </>
        ) : (
          <>
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-medium text-zinc-700">Préfecture émettrice</span>
              <input name="prefecture" placeholder="Préfecture de…" defaultValue={prefill?.prefecture} className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100" />
            </label>
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-medium text-zinc-700">Durée de suspension</span>
              <input name="duree" placeholder="6 mois" defaultValue={prefill?.duree} className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100" />
            </label>
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-medium text-zinc-700">Motif</span>
              <input name="motif" placeholder="alcool / stupéfiants / vitesse" defaultValue={prefill?.motif} className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100" />
            </label>
            {(prefill?.docType === "3F" || prefill?.docType === "48SI") && (
              <>
                <label className="flex flex-col gap-1.5">
                  <span className="text-sm font-medium text-zinc-700">
                    Votre métier{" "}
                    <span className="font-normal text-zinc-500">
                      (facultatif — référé d&apos;urgence)
                    </span>
                  </span>
                  <input name="metier" placeholder="Ex. : cariste, chauffeur VTC" defaultValue={prefill?.metier} className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100" />
                </label>
                <label className="flex flex-col gap-1.5">
                  <span className="text-sm font-medium text-zinc-700">
                    Employeur / entreprise{" "}
                    <span className="font-normal text-zinc-500">(facultatif)</span>
                  </span>
                  <input name="entreprise" placeholder="Ex. : Logistique Dupont SAS" defaultValue={prefill?.entreprise} className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100" />
                </label>
                <label className="flex flex-col gap-1.5 sm:col-span-2">
                  <span className="text-sm font-medium text-zinc-700">
                    Conséquence concrète de la décision{" "}
                    <span className="font-normal text-zinc-500">
                      (facultatif — ex. : risque de licenciement)
                    </span>
                  </span>
                  <input name="risque_licenciement" placeholder="Ex. : risque de licenciement si je ne peux plus me déplacer" defaultValue={prefill?.risque_licenciement} className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100" />
                </label>
              </>
            )}
          </>
        )}
      </div>

      <label className="flex items-start gap-2 text-sm text-zinc-700">
        <input
          type="checkbox"
          name="plaqueIncorrecte"
          defaultChecked={prefill?.plaqueIncorrecte}
          className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-emerald-600 focus:ring-emerald-500"
        />
        La plaque indiquée sur le PV n'est pas la mienne
      </label>

      <div className="rounded-2xl border border-zinc-200 p-4">
        <p className="text-sm font-semibold text-zinc-700">
          Questions sur votre situation
        </p>
        <p className="mt-0.5 text-xs text-zinc-500">
          Les groupes affichés dépendent du contenu {titreAnalyse(type)} scanné
          : ils apportent un contexte que le juriste vérifie. Aucune case
          cochée ne fabrique un motif de contestation automatique.
        </p>
        {groupes.map((groupe) => (
          <div key={groupe.groupe} className="mt-3">
            <p className="text-xs font-semibold uppercase tracking-wide text-zinc-500">
              {groupe.groupe}
            </p>
            <div className="mt-2 flex flex-col gap-2.5">
              {groupe.questions.map((q) => {
                const prefillQ = prefill?.[q.champ];
                return (
                <div key={q.cle} className="group">
                  {q.typeChamp === "texte" ? (
                    <label className="flex flex-col gap-1.5 text-sm text-zinc-700">
                      {q.libelle}
                      <input
                        type="text"
                        name={q.cle}
                        defaultValue={
                          typeof prefillQ === "string" ? prefillQ : undefined
                        }
                        className="rounded-xl border border-zinc-300 px-3 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-100"
                      />
                    </label>
                  ) : q.typeChamp === "radio" ? (
                    <fieldset className="flex flex-col gap-1.5">
                      <legend className="text-sm text-zinc-700">
                        {q.libelle}
                      </legend>
                      {(q.options ?? []).map((opt) => {
                        const pieces = q.preuvesOption?.[opt.valeur] ?? [];
                        return (
                          <div key={opt.valeur}>
                            <label className="flex items-start gap-2 text-sm text-zinc-700">
                              <input
                                type="radio"
                                name={q.cle}
                                value={opt.valeur}
                                defaultChecked={prefillQ === opt.valeur}
                                className="mt-0.5 h-4 w-4 border-zinc-300 text-emerald-600 focus:ring-emerald-500"
                              />
                              {opt.libelle}
                            </label>
                            {pieces.length > 0 && (
                              <p className="ml-6 mt-1 text-xs text-amber-700">
                                Pour étayer cette situation :{" "}
                                <strong>
                                  {pieces.map((p) => libellePreuve(p)).join(", ")}
                                </strong>{" "}
                                — à joindre après l&apos;analyse sur la fiche de
                                votre dossier (facultatif : le dossier n&apos;est
                                pas bloqué sans lui).
                              </p>
                            )}
                          </div>
                        );
                      })}
                    </fieldset>
                  ) : (
                    <label className="flex items-start gap-2 text-sm text-zinc-700">
                      <input
                        type="checkbox"
                        name={q.cle}
                        defaultChecked={Boolean(prefillQ)}
                        className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-emerald-600 focus:ring-emerald-500"
                      />
                      {q.libelle}
                    </label>
                  )}
                  {q.preuveClient && (
                    <p className="ml-6 mt-1 text-xs text-amber-700">
                      {q.notePreuve ? (
                        <>
                          {q.notePreuve}{" "}
                        </>
                      ) : (
                        <>
                          Cette réponse appelle un document :{" "}
                        </>
                      )}
                      <strong>{libellePreuve(q.preuveClient)}</strong> — vous
                      pourrez le joindre juste après l&apos;analyse, sur la fiche
                      de votre dossier (facultatif : le dossier n&apos;est pas
                      bloqué sans lui).
                    </p>
                  )}
                  {/* Interstitial « déjà payé » : piloté en CSS (:checked) sur
                      l'état réel de la case — contrairement à un état React, il
                      survit au reset natif du formulaire après une action
                      serveur (React 19), sans jamais désynchroniser l'encart et
                      ce qui part réellement au serveur. */}
                  {q.cle === "paiementDejaFait" && (
                    <div
                      data-testid="interstitial-paiement"
                      className="ml-6 mt-2 hidden rounded-xl border border-amber-300 bg-amber-50 p-3 text-xs text-amber-900 group-has-[:checked]:block"
                    >
                      <p className="font-semibold">
                        Paiement déjà effectué — à lire avant de continuer
                      </p>
                      <p className="mt-1">
                        Une amende déjà payée peut rendre la contestation sans
                        objet (ou ouvrir droit à un remboursement). Un juriste
                        examinera votre dossier avant toute suite : votre crédit
                        ne sera consommé qu&apos;après sa validation.
                      </p>
                      <label className="mt-2 flex items-start gap-2 font-medium">
                        <input
                          type="checkbox"
                          name="paiementConfirme"
                          className="mt-0.5 h-4 w-4 rounded border-amber-400 text-amber-600 focus:ring-amber-500"
                        />
                        J&apos;ai bien compris et confirme que ce paiement a été
                        effectué
                      </label>
                    </div>
                  )}
                </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {state?.error && (
        <p className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">
          {state.error}
        </p>
      )}

      <button
        type="submit"
        disabled={pending}
        className="rounded-full bg-emerald-600 px-6 py-3 font-semibold text-white transition hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-50"
      >
        {pending ? "Analyse en cours…" : "Analyser et générer la lettre"}
      </button>
    </form>
  );
}