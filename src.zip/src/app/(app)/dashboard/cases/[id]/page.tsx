import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/dal";
import { joursRestants } from "@/lib/moteur";
import { controlerForclusion48si } from "@/lib/delais";
import { titreAnalyse } from "@/lib/envoi";
import { getOcrProvider } from "@/lib/ocr";
import { libelleMontantDossier } from "@/lib/tarifs";
import { storageRead, storageUrl } from "@/lib/storage";
import { AnalyseForm, type AnalysePrefill } from "./analyse-form";
import { SignaturePad } from "./signature-pad";
import { EnvoiSuivi } from "./envoi-suivi";
import { DepotAssiste } from "./depot-assiste";
import { AvocatRequest } from "./avocat-request";
import { Preuves, type PreuveDto } from "@/components/preuves";
import { faillesPourTypePreuve } from "@/lib/preuves-api";
import { suggestionsPreuvesClient } from "@/lib/questions";
import { chargerQuestionsDynamiques } from "@/lib/questions-dyn";
import { libellePreuve } from "@/lib/preuve-labels";
import { DossierTimeline, type TimelineEvent } from "@/components/dossier-timeline";
import { FilMessages, type MessageDto } from "@/components/messages";
import { Avancement } from "@/components/avancement";
import { marquerMessagesLus } from "../../messages/actions";

const statusLabels: Record<string, string> = {
  BROUILLON: "Brouillon",
  EN_ANALYSE: "En analyse",
  EN_ATTENTE_PAIEMENT: "Paiement en attente",
  EN_ATTENTE_VALIDATION: "Validation du juriste",
  EN_ATTENTE_PRE_SIGNATURE: "À signer",
  A_VERIFIER: "À vérifier",
  PRET: "Prêt",
  ENVOYE: "Envoyé",
  AVOCAT_REQUIS: "Délit — orientation vers un avocat",
  REJETE: "Rejeté",
  ERREUR_TECHNIQUE: "Erreur technique",
  RESOLU: "Réponse de l'administration",
  ANNULE: "Annulé",
};

type CaseDetail = {
  id: string;
  userId: string;
  type: "AMENDE" | "SUSPENSION";
  statut: string;
  canalEnvoi: string | null;
  voieProcedure: string | null;
  classeContravention: number | null;
  consignationMontant: number | null;
  consignationPayeeLe: Date | null;
  pvUrl: string | null;
  pvTexte: string | null;
  extractedData: Record<string, unknown> | null;
  lettreGeneree: string | null;
  failleJuridique: { titreFaille: string; articleLoi: string } | null;
  courriers: Array<{
    pdfUrl: string | null;
    signatureUrl: string | null;
    preuveDepotUrl: string | null;
    packUrls?: unknown;
  }>;
  preuves: Array<{
    id: string;
    nom: string;
    type: string;
    url: string;
    createdAt: Date;
    userId: string | null;
  }>;
  faillesRetenues: Array<{
    statut: string;
    faille: { id: string; titreFaille: string };
  }>;
  evenements: Array<{ type: string; detail: string | null; createdAt: Date }>;
  lawyerMatch: {
    statut: string;
    motif: string | null;
    partnerName: string | null;
    partnerBarreau: string | null;
    partnerEmail: string | null;
    note: string | null;
  } | null;
  prix: number;
  createdAt: Date;
  dateLimite: Date | null;
  motifRejet: string | null;
  decisionOmp: "ACCEPTE" | "REJETE" | null;
  decisionDetail: string | null;
  decisionRecupereeLe?: Date | null;
  valideLe: Date | null;
  messages: Array<{
    id: string;
    contenu: string;
    createdAt: Date;
    lu: boolean;
    auteurId: string;
    auteur: { id: string; name: string | null; role: string };
  }>;
};

type DemoMock = {
  type: "AMENDE" | "SUSPENSION";
  statut: string;
  pvTexte: string;
  extractedData: Record<string, unknown>;
  failleJuridique: { titreFaille: string; articleLoi: string } | null;
  lettreGeneree: string | null;
  valideLe: Date | null;
  decisionOmp: "ACCEPTE" | "REJETE" | null;
  decisionDetail: string | null;
};

const MOCK_BY_ID: Record<string, DemoMock> = {
  "pv-analyse-001": { type: "AMENDE", statut: "EN_ANALYSE", pvTexte: "CONTRAVENTION N° PV-ANALYSE-001\nVitesse 96km/h limitée 70 le 10/07/2026 à 15:00\nLieu: A6 km 42\nRadar MESTA 210C n° 777\nPlaque AB-123-CD\nMontant 135€\nAdresse 12 RUE DE LA PAIX 75001 PARIS", extractedData: { plaque: "AB-123-CD", num_pv: "PV-ANALYSE-001", date: "2026-07-10", heure: "15h00", lieu: "A6 km 42", adresse: "12 RUE DE LA PAIX 75001 PARIS", montant: "135,00 €", radarId: "777" }, failleJuridique: null, lettreGeneree: null, valideLe: null, decisionOmp: null, decisionDetail: null },
  "pv-sign-002": { type: "AMENDE", statut: "A_VERIFIER", pvTexte: "CONTRAVENTION N° PV-SIGN-002\nPlaque XY-999-ZZ\nDate: 20/05/2026 à 10:15\nLieu: Rue de Rivoli, Paris 1er\nMontant: 90€", extractedData: { plaque: "XY-999-ZZ", num_pv: "PV-SIGN-002", date: "2026-05-20", heure: "10:15", lieu: "Rue de Rivoli Paris", adresse: "8 impasse des Lilas 13001 MARSEILLE", plaqueIncorrecte: true }, failleJuridique: { titreFaille: "Erreur plaque", articleLoi: "Art. 429 CPP" }, lettreGeneree: "À l'attention de l'Officier du Ministère Public,\n\nJe soussigné Jean Dupont, titulaire du certificat d'immatriculation du véhicule portant la plaque XY-999-ZZ, conteste l'avis de contravention n° PV-SIGN-002 du 2026-05-20.\n\nLa plaque d'immatriculation XY-999-ZZ mentionnée sur l'avis de contravention ne correspond pas à mon véhicule. Il s'agit d'une erreur matérielle de la part des services verbalisateurs.\n\nConformément à l'article 429 du Code de procédure pénale, l'exonération est demandée lorsque l'avis de contravention est entaché d'une erreur portant sur l'identification du véhicule ou de son titulaire.\n\nJe demande en conséquence l'exonération de l'amende de 90 € qui m'est réclamée.", valideLe: null, decisionOmp: null, decisionDetail: null },
  "pv-pret-003": { type: "AMENDE", statut: "PRET", pvTexte: "CONTRAVENTION N° PV-PRET-003\nDate 10/05/2026\nPlaque CD-456-EF\nTravaux présents\nLieu: A10 - Orléans\nMontant: 45€", extractedData: { plaque: "CD-456-EF", num_pv: "PV-PRET-003", date: "2026-05-10", heure: "08:45", lieu: "A10 - Orléans", travaux_présents: true, adresse: "45 Avenue des Champs 75008 PARIS" }, failleJuridique: { titreFaille: "Travaux et signalisation temporaire", articleLoi: "Art. R. 411-8 CR" }, lettreGeneree: "À l'attention de l'Officier du Ministère Public,\n\nJe soussigné Jean Dupont, conteste l'avis de contravention n° PV-PRET-003 du 2026-05-10 relatif au véhicule immatriculé CD-456-EF.\n\nDes travaux avec signalisation temporaire étaient présents au lieu dit A10 - Orléans le 10 mai 2026. La signalisation n'était pas conforme aux prescriptions de l'article R. 411-8 du Code de la route, ce qui entache la régularité de la constatation.\n\nEn application de l'article R. 411-8 du Code de la route, la limitation de vitesse dans les zones de travaux n'est opposable que si la signalisation réglementaire est en place.\n\nJe demande en conséquence l'annulation de l'amende de 45 € qui m'est réclamée.", valideLe: new Date("2026-07-15"), decisionOmp: null, decisionDetail: null },
  "pv-envoye-004": { type: "AMENDE", statut: "ENVOYE", pvTexte: "CONTRAVENTION N° PV-ENVOYE-004\nDate 01/04/2026\nPlaque EF-012-IJ\nLieu: A6\nMontant: 135€", extractedData: { plaque: "EF-012-IJ", num_pv: "PV-ENVOYE-004", date: "2026-04-01", heure: "16:20", adresse: "22 rue Nationale 75013 PARIS", lieu: "A6" }, failleJuridique: { titreFaille: "Prescription 1 an", articleLoi: "Art. 133-3 CPP" }, lettreGeneree: "À l'attention de l'Officier du Ministère Public,\n\nJe soussigné Jean Dupont, conteste l'avis de contravention n° PV-ENVOYE-004 du 2026-04-01.\n\nL'action publique pour une contravention se prescrit par une année révolue à compter du jour où l'infraction a été commise (art. 9 CPP). Or, plus d'un an s'est écoulé entre la date de l'infraction et la notification du présent avis.\n\nL'infraction est donc prescrite. Je demande en conséquence l'annulation de l'amende de 135 € qui m'est réclamée.", valideLe: new Date("2026-07-10"), decisionOmp: null, decisionDetail: null },
  "pv-rejete-005": { type: "AMENDE", statut: "REJETE", pvTexte: "CONTRAVENTION N° PV-REJETE-005\nDate 15/03/2026\nPlaque GH-345-KL\nLieu: A7 - Salon-de-Provence\nMontant: 135€", extractedData: { plaque: "GH-345-KL", num_pv: "PV-REJETE-005", date: "2026-03-15", heure: "12:30", lieu: "A7 - Salon-de-Provence", montant: 135 }, failleJuridique: null, lettreGeneree: null, valideLe: null, decisionOmp: null, decisionDetail: null },
  "pv-resolu-006": { type: "AMENDE", statut: "RESOLU", pvTexte: "CONTRAVENTION N° PV-RESOLU-006\nDate 01/02/2026\nPlaque MN-678-OP\nLieu: A10 - Aire de Tours\nMontant: 135€", extractedData: { plaque: "MN-678-OP", num_pv: "PV-RESOLU-006", date: "2026-02-01", heure: "11:00", lieu: "A10 - Aire de Tours", montant: 135 }, failleJuridique: { titreFaille: "Prescription 1 an", articleLoi: "Art. 9 CPP" }, lettreGeneree: "À l'attention de l'Officier du Ministère Public,\n\nJe soussigné Jean Dupont, conteste l'avis de contravention n° PV-RESOLU-006 du 2026-02-01.\n\nL'action publique pour une contravention se prescrit par une année révolue à compter du jour où l'infraction a été commise. L'infraction est prescrite.\n\nJe demande l'annulation de l'amende de 135 €.", valideLe: new Date("2026-06-15"), decisionOmp: "ACCEPTE", decisionDetail: "Amende annulée - prescription acquise" },
  "dec-analyse-007": { type: "SUSPENSION", statut: "EN_ANALYSE", pvTexte: "DÉCISION DE SUSPENSION N° DEC-ANALYSE-007\nPréfecture de Lyon\nDurée: 6 mois\nMotif: Alcoolémie 0,45 mg/L\nDate: 01/07/2026", extractedData: { num_pv: "DEC-ANALYSE-007", date: "2026-07-01", prefecture: "Préfecture de Lyon", duree: "6 mois", motif: "alcoolémie", adresse: "12 RUE DE LA PAIX 75001 PARIS" }, failleJuridique: null, lettreGeneree: null, valideLe: null, decisionOmp: null, decisionDetail: null },
  "dec-sign-008": { type: "SUSPENSION", statut: "A_VERIFIER", pvTexte: "DÉCISION DE SUSPENSION N° DEC-SIGN-008\nPréfecture des Bouches-du-Rhône\nDurée: 4 mois\nMotif: Vitesse 180 km/h\nDate: 15/06/2026", extractedData: { num_pv: "DEC-SIGN-008", date: "2026-06-15", prefecture: "Préfecture des Bouches-du-Rhône", duree: "4 mois", motif: "vitesse", lieu: "A7 - Marseille" }, failleJuridique: { titreFaille: "Suspension sans contradictoire", articleLoi: "Art. L121-1 CRPA" }, lettreGeneree: "À l'attention de Monsieur le Préfet des Bouches-du-Rhône,\n\nJe soussigné Jean Dupont, conteste la décision n° DEC-SIGN-008 du 2026-06-15 par laquelle vous avez prononcé la suspension de mon permis de conduire pour une durée de 4 mois.\n\nCette décision a été prise sans que j'aie été mis en mesure de présenter des observations préalables, alors qu'aucune urgence caractérisée ne justifiait de s'en dispenser. En application des articles L. 121-1 et L. 211-2 du code des relations entre le public et l'administration, une décision individuelle défavorable prise en considération de la personne doit être précédée d'une procédure contradictoire permettant à l'intéressé de présenter ses observations (Conseil d'État, 20 avril 2021, n° 438114).\n\nJe demande en conséquence le retrait de la décision de suspension prise à mon encontre.", valideLe: null, decisionOmp: null, decisionDetail: null },
  "dec-pret-009": { type: "SUSPENSION", statut: "PRET", pvTexte: "DÉCISION DE SUSPENSION N° DEC-PRET-009\nPréfecture de Paris\nDurée: 12 mois\nMotif: Stupéfiants\nDate: 01/06/2026", extractedData: { num_pv: "DEC-PRET-009", date: "2026-06-01", prefecture: "Préfecture de Paris", duree: "12 mois", motif: "stupéfiants" }, failleJuridique: { titreFaille: "Suspension sans contradictoire", articleLoi: "Art. L121-1 CRPA" }, lettreGeneree: "À l'attention de Monsieur le Préfet de Paris,\n\nJe soussigné Jean Dupont, conteste la décision n° DEC-PRET-009 du 2026-06-01 par laquelle vous avez prononcé la suspension de mon permis de conduire pour une durée de 12 mois.\n\nCette décision a été prise sans procédure contradictoire préalable, en violation des articles L. 121-1 et L. 211-2 CRPA.\n\nJe demande le retrait de cette décision.", valideLe: new Date("2026-07-10"), decisionOmp: null, decisionDetail: null },
};

function demoDossier(id: string, userId: string): CaseDetail | null {
  const mock = MOCK_BY_ID[id];
  if (!mock) return null;
  return {
    id,
    userId,
    type: mock.type,
    statut: mock.statut,
    canalEnvoi:
      mock.statut === "PRET" || mock.statut === "ENVOYE" || mock.statut === "RESOLU"
        ? mock.type === "SUSPENSION"
          ? "TELERECOURS"
          : "ANTAI"
        : null,
    voieProcedure: null,
    classeContravention: null,
    consignationMontant: null,
    consignationPayeeLe: null,
    pvUrl: "/uploads/demo-pv.jpg",
    pvTexte: mock.pvTexte,
    extractedData: mock.extractedData,
    lettreGeneree: mock.lettreGeneree,
    failleJuridique: mock.failleJuridique,
    courriers:
      mock.statut === "PRET" || mock.statut === "ENVOYE" || mock.statut === "RESOLU"
        ? [
            {
              pdfUrl: "/uploads/demo-lettre.pdf",
              signatureUrl: "/uploads/demo-signature.png",
              preuveDepotUrl:
                mock.statut === "ENVOYE" ? "/uploads/demo-accuse.pdf" : null,
            },
          ]
        : [],
    preuves: [],
    faillesRetenues: [],
    evenements: [{ type: "CREATION", detail: "Dossier de démo", createdAt: new Date() }],
    messages: [],
    lawyerMatch: null,
    prix: mock.type === "AMENDE" ? 39 : 199,
    createdAt: new Date(),
    dateLimite: new Date(Date.now() + 86400000 * 30),
    motifRejet: null,
    decisionOmp: mock.decisionOmp,
    decisionDetail: mock.decisionDetail,
    valideLe:
      mock.valideLe ??
      (mock.statut === "PRET" || mock.statut === "ENVOYE" || mock.statut === "RESOLU"
        ? new Date()
        : null),
  };
}

export default async function CaseDetailPage(
  props: PageProps<"/dashboard/cases/[id]">,
) {
  const user = await requireUser();
  const { id } = await props.params;
  const searchParams = await props.searchParams;

  let item: CaseDetail | null = null;
  try {
    const isDev = user.id.startsWith("dev-");
    item = (await prisma.dossier.findFirst({
      where: isDev ? { id } : { id, userId: user.id },
      include: {
        courriers: true,
        failleJuridique: true,
        lawyerMatch: true,
        preuves: { orderBy: { createdAt: "asc" } },
        faillesRetenues: { include: { faille: true }, orderBy: { createdAt: "asc" } },
        evenements: { orderBy: { createdAt: "asc" } },
        messages: {
          orderBy: { createdAt: "asc" },
          include: { auteur: { select: { id: true, name: true, role: true } } },
        },
      },
    })) as unknown as CaseDetail | null;
    // Fallback : si dev et dossier non trouvé avec filtre userId, retente sans filtre
    if (!item && isDev) {
      item = (await prisma.dossier.findFirst({
        where: { id },
        include: {
          courriers: true,
          failleJuridique: true,
          lawyerMatch: true,
          preuves: { orderBy: { createdAt: "asc" } },
          faillesRetenues: { include: { faille: true }, orderBy: { createdAt: "asc" } },
          evenements: { orderBy: { createdAt: "asc" } },
          messages: {
            orderBy: { createdAt: "asc" },
            include: { auteur: { select: { id: true, name: true, role: true } } },
          },
        },
      })) as unknown as CaseDetail | null;
    }
  } catch (e) {
    console.error("cases/[id]: DB indisponible", e);
  }

  if (!item) {
    if (user.id.startsWith("dev-")) {
      const mock = demoDossier(id, user.id);
      if (mock) {
        item = mock;
      } else {
        return (
          <div className="mx-auto max-w-4xl p-8">
            <p className="rounded-xl bg-amber-50 px-4 py-3 text-sm text-amber-800">Mode démo — dossier {id.slice(0, 8)} non trouvé. Revenez à <a href="/dashboard?dev=1" className="font-semibold underline">/dashboard?dev=1</a> et cliquez sur un des 9 dossiers listés (PV-TEST-00X).</p>
            <Link href="/dashboard?dev=1" className="mt-4 inline-block rounded-full bg-emerald-600 px-6 py-3 text-sm font-semibold text-white">Retour</Link>
          </div>
        );
      }
    } else {
      notFound();
    }
  }

  const preuves = await Promise.all(
    item.preuves.map(async (p) => ({
      ...p,
      url: (await storageUrl(p.url)) ?? p.url,
    })),
  );
  // Lien preuve externe ↔ faille détectée : chaque preuve « Récupérée »
  // (METEO/RADAR/TRAVAUX) est expliquée au client par la faille qui la rend
  // pertinente (mapping PREUVES_PAR_FAILLE) — transparence de la suggestion.
  const faillesRetenues = (item.faillesRetenues ?? []).filter(
    (df) => df.statut === "CANDIDATE" || df.statut === "CONFIRMEE",
  );
  const contexteParType: Record<string, string | null> = {
    METEO: null,
    RADAR: null,
    TRAVAUX: null,
  };
  for (const type of Object.keys(contexteParType) as Array<"METEO" | "RADAR" | "TRAVAUX">) {
    const faille = faillesRetenues.find((df) =>
      faillesPourTypePreuve(type).includes(df.faille.id),
    );
    if (faille) {
      contexteParType[type] =
        `Suggérée automatiquement pour la faille détectée : ${faille.faille.titreFaille}`;
    }
  }
  const preuvesDto: PreuveDto[] = preuves.map((p) => ({
    id: p.id,
    nom: p.nom,
    type: p.type,
    url: p.url,
    createdAt: p.createdAt,
    userId: p.userId,
    contexte: contexteParType[p.type] ?? null,
  }));
  // Pièces suggérées d'après les réponses cochées (capteur de fait) : une
  // pièce déjà versée au dossier n'est plus proposée. Les questions
  // dynamiques (veille 2.0) complètent le registre pour les suggestions.
  const questionsDynamiques =
    (await chargerQuestionsDynamiques().catch(() => null))?.[item.type] ?? [];
  const suggestionsPreuves = suggestionsPreuvesClient(
    item.extractedData,
    preuves.map((p) => p.type),
    questionsDynamiques,
  );

  const messagesDto: MessageDto[] = (item.messages ?? []).map((m) => ({
    id: m.id,
    contenu: m.contenu,
    createdAt: m.createdAt,
    lu: m.lu,
    auteurId: m.auteurId,
    auteurNom: m.auteur.name ?? m.auteur.role,
    auteurRole: m.auteur.role === "JURISTE" ? "JURISTE" : m.auteur.role === "ADMIN" ? "ADMIN" : "CLIENT",
  }));

  // Marque comme lus les messages du juriste dès l'ouverture du détail.
  await marquerMessagesLus(item.id).catch(() => {});

  const pvUrl = await storageUrl(item.pvUrl);
  const isImage = pvUrl?.match(/\.(jpe?g|png|webp)(\?.*)?$/i);
  const courrier = item.courriers[item.courriers.length - 1];
  const pdfUrl = await storageUrl(courrier?.pdfUrl ?? null);
  const signatureUrl = await storageUrl(courrier?.signatureUrl ?? null);
  const preuveDepotUrl = await storageUrl(courrier?.preuveDepotUrl ?? null);
  // Pack Télérecours (3F/48SI) : les 3 PDF du dépôt en ligne.
  const pack = (courrier?.packUrls ?? null) as {
    requete?: string | null;
    refere?: string | null;
    bordereau?: string | null;
  } | null;
  const packRequeteUrl = await storageUrl(pack?.requete ?? null);
  const packRefereUrl = await storageUrl(pack?.refere ?? null);
  const packBordereauUrl = await storageUrl(pack?.bordereau ?? null);
  const preuveEtalonnage =
    typeof item.extractedData === "object" &&
    item.extractedData !== null &&
    "preuveEtalonnage" in item.extractedData
      ? await storageUrl(String(item.extractedData.preuveEtalonnage))
      : null;
  // Signature du profil (capturée au dépôt) : proposée en réutilisation lors
  // de la signature de la lettre (data-URL pour l'aperçu, lecture via stockage).
  const signatureProfil = await (async () => {
    try {
      const row = await prisma.user.findUnique({
        where: { id: user.id },
        select: { signatureUrl: true },
      });
      if (!row?.signatureUrl) return null;
      const buf = await storageRead(row.signatureUrl);
      return buf ? `data:image/png;base64,${buf.toString("base64")}` : null;
    } catch {
      return null;
    }
  })();
  const evenements = await Promise.all(
    item.evenements.map(async (e) => ({
      ...e,
      detailUrl: e.detail ? await storageUrl(e.detail) : null,
    })),
  );
  const restants = joursRestants(item.dateLimite);
  const deadlineUrgency =
    restants > 10
      ? { badge: "bg-emerald-100 text-emerald-800", text: `J-${restants}` }
      : restants > 0
        ? { badge: "bg-amber-100 text-amber-800", text: `Urgent : J-${restants}` }
        : {
            badge: "bg-red-100 text-red-800",
            text: "Délai dépassé — agissez immédiatement",
          };

  // Forclusion 48SI (60 jours francs de la notification) — encart non
  // bloquant côté client : jamais fabriqué sans date de notification.
  const dataExtraite =
    typeof item.extractedData === "object" && item.extractedData !== null
      ? (item.extractedData as Record<string, unknown>)
      : null;
  const forclusion48si =
    item.type === "SUSPENSION" && dataExtraite?.docType === "48SI"
      ? controlerForclusion48si(
          typeof dataExtraite.dateNotification === "string"
            ? dataExtraite.dateNotification
            : null,
        )
      : null;

  // La lettre n'est révélée au client qu'après l'envoi effectif de la
  // contestation (vérifiée et validée par le juriste).
  const lettreVisible = item.statut === "ENVOYE" || item.statut === "RESOLU";
  const isDemo = item.id.startsWith("pv-") || item.id.startsWith("dec-") || item.pvUrl === "/uploads/demo-pv.jpg";

  // En EN_ANALYSE, l'action attendue du client (saisir + analyser) est remontée
  // en tête : timeline, preuves et messages sont vides ou hors sujet à ce stade.
  const enAnalyse = item.statut === "EN_ANALYSE";

  return (
    <div className="mx-auto max-w-4xl">
      <Link
        href="/dashboard/cases"
        className="text-sm font-medium text-zinc-500 hover:text-zinc-900"
      >
        ← Retour aux dossiers
      </Link>
      <div className="mt-2 flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-2xl font-bold">
          {item.type === "AMENDE"
            ? item.voieProcedure === "CONTENTIEUX_CONTRAVENTION"
              ? "Contentieux contraventionnel"
              : item.voieProcedure === "DELIT"
                ? "Délit routier"
                : "Contestation d'amende"
            : "Suspension de permis"}
        </h1>
        <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-800">
          {statusLabels[item.statut] ?? item.statut}
        </span>
      </div>

      {searchParams.lien === "envoye" && (
        <div className="mt-4 rounded-xl bg-sky-50 px-4 py-3 text-sm text-sky-800">
          Le lien de dépôt assisté vient de vous être envoyé. Déposez votre
          contestation sur le portail officiel puis marquez le dossier dans la
          section ci-dessous.
        </div>
      )}

      {searchParams.envoye === "ok" && (
        <div className="mt-4 rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
          Votre lettre a été envoyée.{" "}
          {item.type === "AMENDE"
            ? "L'OMP examinera votre requête"
            : "Le préfet examinera votre recours"}{" "}
          — pensez à conserver votre récépissé.
        </div>
      )}

      {searchParams.ocr === "echec" && (
        <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
          <p className="font-semibold">
            Nous n&apos;avons pas pu lire automatiquement votre document.
          </p>
          <p className="mt-1 text-amber-800">
            Son fichier est bien enregistré. Complétez le formulaire ci-dessous à
            la main — un juriste vérifiera chaque information avant l&apos;envoi.
            <span className="mt-2 block text-xs text-amber-700/80">
              Diagnostic : provider OCR = <code className="font-mono font-semibold">{getOcrProvider()}</code>
              {getOcrProvider() === "aucun" && " — aucune clé API configurée (voir .env : OCR_PROVIDER / GEMINI_API_KEY / GOOGLE_VISION_KEY / MISTRAL_API_KEY)"}
              {getOcrProvider() === "mock" && process.env.NODE_ENV === "production" && " — simulation (mock) en production (texte fictif)"}
            </span>
          </p>
        </div>
      )}

      {isDemo && (
        <div className="mt-4 rounded-xl border border-sky-200 bg-sky-50 px-4 py-3 text-sm text-sky-800">
          Dossier de démonstration — aperçu sans stockage. Créez un vrai dossier pour tester le flux complet (paiement virement puis signature).
        </div>
      )}

      {item.type === "SUSPENSION" &&
        item.statut !== "REJETE" &&
        item.statut !== "RESOLU" &&
        item.statut !== "ANNULE" && (
          <div className="mt-6 rounded-2xl border border-amber-200 bg-amber-50 p-6">
            <h2 className="font-semibold text-amber-900">
              Suspension de permis : délais de recours très courts
            </h2>
            <p className="mt-1 text-sm text-amber-800">
              Les recours en matière de rétention de permis sont soumis à des
              délais stricts. Agissez rapidement et, en cas de doute, faites-vous
              assister par un avocat.
            </p>
          </div>
        )}

      {item.statut === "AVOCAT_REQUIS" && (
        <div
          data-testid="avocat-requis"
          className="mt-6 rounded-2xl border-2 border-orange-300 bg-orange-50 p-6"
        >
          <h2 className="text-lg font-semibold text-orange-900">
            Votre document relève d&apos;une procédure pénale (délit)
          </h2>
          <p className="mt-2 text-sm text-orange-900">
            Un avis de contravention délictuelle ou une convocation devant le
            tribunal correctionnel ne relève pas de la contestation
            administrative traitée par SOS Amende : ce type de dossier exige
            l&apos;assistance d&apos;un <strong>avocat</strong>.
          </p>
          <p className="mt-2 text-sm text-orange-800">
            <strong>Aucun paiement n&apos;a été débité.</strong> Vous pouvez
            demander une mise en relation avec un avocat partenaire ci-dessous.
          </p>
          <a
            href="#avocat"
            className="mt-4 inline-block rounded-full bg-orange-600 px-6 py-2.5 text-sm font-semibold text-white hover:bg-orange-700"
          >
            Demander un avocat
          </a>
        </div>
      )}

      {item.type === "AMENDE" &&
        item.voieProcedure === "CONTENTIEUX_CONTRAVENTION" &&
        item.statut !== "REJETE" &&
        item.statut !== "RESOLU" &&
        item.statut !== "ANNULE" && (
          <div
            data-testid="consignation"
            className="mt-6 rounded-2xl border border-amber-300 bg-amber-50 p-6"
          >
            <h2 className="font-semibold text-amber-900">
              Contentieux contraventionnel : consignation obligatoire
            </h2>
            <p className="mt-1 text-sm text-amber-900">
              Votre avis relève du tribunal de police. Avant de contester, vous
              devez <strong>consigner</strong>
              {item.consignationMontant
                ? ` ${Number(item.consignationMontant)
                    .toFixed(2)
                    .replace(".", ",")} €`
                : " le montant de l'amende"}
              {" "}— montant indiqué sur votre avis.
            </p>
            <ol className="mt-3 list-decimal space-y-1 pl-5 text-sm text-amber-900">
              <li>
                Consignez sur{" "}
                <a
                  href="https://www.amendes.gouv.fr"
                  target="_blank"
                  rel="noreferrer"
                  className="font-semibold underline"
                >
                  amendes.gouv.fr
                </a>{" "}
                (« Payer ou consigner ») ou sur{" "}
                <a
                  href="https://www.antai.gouv.fr"
                  target="_blank"
                  rel="noreferrer"
                  className="font-semibold underline"
                >
                  antai.gouv.fr
                </a>
                .
              </li>
              <li>Conservez le justificatif de consignation.</li>
              <li>
                Joignez-le à votre dossier dans la section « Preuves » ci-dessous.
              </li>
            </ol>
            <p className="mt-3 text-xs text-amber-800">
              La consignation n&apos;est pas une reconnaissance de
              l&apos;infraction : elle vous est restituée si la contestation
              aboutit. Elle est à effectuer <strong>par vous</strong>, avant le
              dépôt de la contestation.
            </p>
            {item.consignationPayeeLe ? (
              <p className="mt-3 inline-block rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-800">
                Preuve de consignation reçue le{" "}
                {item.consignationPayeeLe.toLocaleDateString("fr-FR")}
              </p>
            ) : (
              <p className="mt-3 inline-block rounded-full bg-white px-3 py-1 text-xs font-semibold text-amber-800">
                En attente de votre justificatif de consignation
              </p>
            )}
          </div>
        )}

      {enAnalyse && (
        <section
          id="analyse"
          data-testid="analyse-en-tete"
          className="mt-6 scroll-mt-6 rounded-2xl border-2 border-emerald-300 bg-white p-6"
        >
          <p className="inline-block rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-emerald-800">
            Étape 1 sur 6 — à vous de jouer
          </p>
          <h2 className="mt-3 text-xl font-semibold">
            Vérifiez les informations de votre {titreAnalyse(item.type)}
          </h2>
          <p className="mt-1 text-sm text-zinc-600">
            Contrôlez les champs ci-dessous, corrigez ce qui ne correspond pas à
            votre document, puis lancez l&apos;analyse. Le moteur recherche les
            motifs de contestation, puis un juriste valide la lettre avant tout
            envoi. C&apos;est gratuit : le paiement intervient seulement si une
            faille est validée.
          </p>
          <div className="mt-6">
            <AnalyseForm
              dossierId={item.id}
              type={item.type}
              pvTexte={item.pvTexte}
              prefill={item.extractedData as AnalysePrefill | null}
              questionsDynamiques={questionsDynamiques}
            />
          </div>
        </section>
      )}

      {item.statut === "REJETE" && (
        <div className="mt-6 rounded-2xl border border-red-200 bg-red-50 p-6">
          <h2 className="font-semibold text-red-900">
            Dossier rejeté après examen
          </h2>
          <p className="mt-1 text-sm text-red-800">
            Un juriste n&apos;a pas retenu de motif de contestation pour ce
            dossier. Motif :
          </p>
          <p className="mt-3 rounded-xl bg-white px-4 py-3 text-sm text-zinc-700">
            {item.motifRejet ?? "—"}
          </p>
          <p className="mt-3 text-xs text-red-700">
            {item.voieProcedure === "CONTENTIEUX_CONTRAVENTION"
              ? "Votre paiement de 149 € vous sera remboursé : l'équipe exécute le remboursement et vous en informe. Aucun crédit n'est débité sur ce dossier."
              : "Votre crédit a été rendu : vous pouvez lancer un nouveau dossier sans repayer."}
          </p>
          <p className="mt-1 text-xs text-red-700">
            Pour toute question, contactez le support avec la référence de ce
            dossier.
          </p>
        </div>
      )}

      {item.statut === "RESOLU" && item.decisionOmp && (
        <div className={`mt-6 rounded-2xl border p-6 ${item.decisionOmp === "ACCEPTE" ? "border-emerald-200 bg-emerald-50" : "border-zinc-300 bg-zinc-50"}`}>
          <h2 className={`font-semibold ${item.decisionOmp === "ACCEPTE" ? "text-emerald-900" : "text-zinc-900"}`}>
            {item.decisionOmp === "ACCEPTE"
              ? "Dossier résolu : votre contestation a été acceptée"
              : "Dossier résolu : votre contestation a été rejetée"}
          </h2>
          <p className={`mt-1 text-sm ${item.decisionOmp === "ACCEPTE" ? "text-emerald-800" : "text-zinc-600"}`}>
            {item.decisionOmp === "ACCEPTE"
              ? "L'amende a été annulée. Vous n'avez plus rien à faire."
              : "La requête a été rejetée par l'OMP. Pour toute question, contactez le support avec la référence de ce dossier."}
          </p>
          {item.decisionDetail && (
            <p className="mt-3 rounded-xl bg-white px-4 py-3 text-sm text-zinc-700">
              {item.decisionDetail}
            </p>
          )}
          {item.decisionRecupereeLe && (
            <p className="mt-2 text-xs text-zinc-500">
              La décision a été récupérée automatiquement par SOS Amende depuis
              le portail officiel.
            </p>
          )}
        </div>
      )}

      {item.statut !== "ANNULE" && (
        <Avancement statut={item.statut} variante="complet" withLabel={true} />
      )}

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <div>
          <h2 className="text-sm font-semibold uppercase tracking-wide text-zinc-500">
            Avis de contravention
          </h2>
          {pvUrl ? (
            isImage ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={pvUrl}
                alt="Avis de contravention"
                className="mt-3 rounded-2xl border border-zinc-200 bg-zinc-50 object-contain"
              />
            ) : (
              <a
                href={pvUrl}
                target="_blank"
                rel="noreferrer"
                className="mt-3 inline-block rounded-xl border border-zinc-200 px-4 py-3 text-sm font-medium text-emerald-700 hover:bg-zinc-50"
              >
                📄 Ouvrir le PV (PDF)
              </a>
            )
          ) : (
            <p className="mt-3 text-sm text-zinc-500">Aucun PV uploadé.</p>
          )}
        </div>

        <div className="flex flex-col gap-4">
          <div className="rounded-2xl border border-zinc-200 bg-white p-5">
            <h2 className="text-sm font-semibold uppercase tracking-wide text-zinc-500">
              Informations
            </h2>
            <dl className="mt-3 space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-zinc-500">Type</dt>
                <dd className="font-medium">
                  {item.type === "AMENDE" ? "Amende" : "Suspension"}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-zinc-500">Prix</dt>
                <dd className="font-medium">{item.prix.toString()} €</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-zinc-500">Créé le</dt>
                <dd className="font-medium">
                  {item.createdAt.toLocaleDateString("fr-FR")}
                </dd>
              </div>
              {typeof item.extractedData === "object" &&
                item.extractedData !== null &&
                !!(
                  item.extractedData as Record<string, unknown>
                ).dateVerificationAppareil && (
                  <div className="flex justify-between">
                    <dt className="text-zinc-500">Vérification radar</dt>
                    <dd className="font-medium">
                      {String(
                        (item.extractedData as Record<string, unknown>)
                          .dateVerificationAppareil,
                      )}
                    </dd>
                  </div>
                )}
            </dl>
          </div>

          {item.dateLimite && (
            <div className="rounded-2xl border border-zinc-200 bg-white p-5">
              <h2 className="text-sm font-semibold uppercase tracking-wide text-zinc-500">
                Délai de contestation
              </h2>
              <p className="mt-2 text-sm text-zinc-600">
                Date limite :{" "}
                <span className="font-medium">
                  {item.dateLimite.toLocaleDateString("fr-FR")}
                </span>
              </p>
              <span
                className={`mt-2 inline-block rounded-full px-3 py-1 text-xs font-semibold ${deadlineUrgency.badge}`}
              >
                {deadlineUrgency.text}
              </span>
            </div>
          )}

          {forclusion48si?.depasse && (
            <div
              data-testid="forclusion-48si"
              className="rounded-2xl border border-amber-300 bg-amber-50 p-5"
            >
              <h2 className="text-sm font-semibold uppercase tracking-wide text-amber-700">
                Délai de recours 48SI dépassé
              </h2>
              <p className="mt-2 text-sm text-amber-900">
                Votre recours contre l&apos;invalidation du permis devait être
                engagé avant le{" "}
                <span className="font-medium">
                  {forclusion48si.dateForclusion.toLocaleDateString("fr-FR")}
                </span>{" "}
                ({forclusion48si.joursDepasse} jour
                {forclusion48si.joursDepasse > 1 ? "s" : ""} de dépassement).
                Ce délai conditionne la recevabilité : contactez le juriste
                avant toute démarche.
              </p>
            </div>
          )}

          <div className="rounded-2xl border border-zinc-200 bg-white p-5">
            <h2 className="text-sm font-semibold uppercase tracking-wide text-zinc-500">
              Faille juridique
            </h2>
            {item.failleJuridique ? (
              <div className="mt-3">
                <p className="font-medium">{item.failleJuridique.titreFaille}</p>
                <p className="mt-1 text-sm text-zinc-600">
                  {item.failleJuridique.articleLoi}
                </p>
                {typeof item.extractedData === "object" &&
                  item.extractedData !== null &&
                  preuveEtalonnage && (
                    <a
                      href={preuveEtalonnage}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-2 inline-block text-sm font-medium text-emerald-700 hover:underline"
                    >
                      Voir le certificat d'étalonnage
                    </a>
                  )}
              </div>
            ) : (
              <p className="mt-3 text-sm text-zinc-500">
                En attente d'analyse par le moteur juridique.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Pièces manquantes : rappel souple, jamais bloquant (le client peut
          signer et déposer sans elles) — ancre vers le bloc de téléversement. */}
      {!enAnalyse && suggestionsPreuves.length > 0 && (
        <div className="mt-8 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-5 py-4">
          <div className="text-sm text-amber-900">
            <p className="font-semibold">
              Pièce{suggestionsPreuves.length > 1 ? "s" : ""} à joindre :{" "}
              {suggestionsPreuves.map((s) => libellePreuve(s.type)).join(", ")}
            </p>
            <p className="mt-0.5 text-xs">
              Réponse{suggestionsPreuves.length > 1 ? "s" : ""} cochée
              {suggestionsPreuves.length > 1 ? "s" : ""} :{" "}
              {suggestionsPreuves.map((s) => `« ${s.raison} »`).join(", ")} —
              facultatif, votre dossier n&apos;est pas bloqué sans{" "}
              {suggestionsPreuves.length > 1 ? "elles" : "elle"}, mais elle
              renforce la contestation.
            </p>
          </div>
          <a
            href="#preuves"
            className="rounded-full bg-amber-600 px-5 py-2 text-sm font-semibold text-white transition hover:bg-amber-700"
          >
            Joindre maintenant
          </a>
        </div>
      )}

      {item.evenements.length > 0 && !enAnalyse && (
        <div className="mt-8">
          <DossierTimeline events={evenements as TimelineEvent[]} />
        </div>
      )}

      {!enAnalyse && (
        <div className="mt-8" id="preuves">
          <Preuves
            dossierId={item.id}
            preuves={preuvesDto}
            currentUserId={user.id}
            suggestions={suggestionsPreuves}
          />
        </div>
      )}

      {!enAnalyse && (
        <div className="mt-8">
          <FilMessages
            dossierId={item.id}
            messages={messagesDto}
            currentUserId={user.id}
            currentRole={user.role as "CLIENT" | "JURISTE" | "ADMIN"}
          />
        </div>
      )}

      {/* La demande de mise en relation reste accessible à tout moment, y
          compris pendant l'analyse : c'est une action du client, pas du
          juriste, et la retirer reviendrait à casser une fonctionnalité. */}
      <div className="mt-8" id="avocat">
        <AvocatRequest
          dossierId={item.id}
          match={
            item.lawyerMatch
              ? {
                  statut: item.lawyerMatch.statut,
                  motif: item.lawyerMatch.motif,
                  partnerName: item.lawyerMatch.partnerName,
                  partnerBarreau: item.lawyerMatch.partnerBarreau,
                  partnerEmail: item.lawyerMatch.partnerEmail,
                  note: item.lawyerMatch.note,
                }
              : null
          }
        />
      </div>

      {(item.statut === "EN_ATTENTE_VALIDATION" ||
        item.statut === "A_VERIFIER") &&
        !item.lettreGeneree ? (
        <div className="mt-8 rounded-2xl border border-zinc-200 bg-white p-6">
          <h2 className="text-lg font-semibold">
            Examen par un juriste en cours
          </h2>
          <p className="mt-2 text-sm text-zinc-600">
            Aucune faille juridique automatique n&apos;a été détectée pour ce
            dossier. Un juriste examine actuellement votre demande et vous
            tiendra informé. Aucune lettre ne sera générée sans base juridique
            validée.
          </p>
          <span className="mt-4 inline-block rounded-full bg-zinc-100 px-3 py-1 text-xs font-semibold text-zinc-600">
            En attente de l&apos;avis du juriste
          </span>
        </div>
      ) : item.statut === "EN_ATTENTE_VALIDATION" && item.lettreGeneree ? (
        <div className="mt-8 rounded-2xl border border-zinc-200 bg-white p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-lg font-semibold">
              Lettre en cours de validation
            </h2>
            <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-800">
              En attente de validation du juriste
            </span>
          </div>
          <p className="mt-2 text-sm text-zinc-600">
            Votre lettre de contestation a été préparée sur une base juridique
            validée. Un juriste la vérifie ainsi que les pièces versées — vous
            serez notifié dès qu&apos;elle est prête pour signature.
          </p>
        </div>
      ) : item.statut === "EN_ATTENTE_PAIEMENT" ? (
        <div className="mt-8 rounded-2xl border-2 border-emerald-600 bg-emerald-50 p-6">
          <h2 className="text-lg font-semibold text-emerald-900">✓ Faille validée — finalisez votre paiement</h2>
          <p className="mt-2 text-sm text-emerald-800">
            Le scan et le scoring de votre dossier sont terminés. Pour débloquer
            la lettre et la faire valider par un juriste, réglez votre dossier
            ({libelleMontantDossier(item.type, item.voieProcedure)}) par virement bancaire.
          </p>
          <Link href={`/dashboard/paiement/${item.id}`} className="mt-4 inline-block rounded-full bg-emerald-600 px-6 py-3 font-semibold text-white hover:bg-emerald-700">
            Payer — virement bancaire
          </Link>
        </div>
      ) : (item.statut === "A_VERIFIER" && item.lettreGeneree) ||
        item.statut === "EN_ATTENTE_PRE_SIGNATURE" ? (
        // Pas de bandeau « crédits épuisés » ici : le paiement de CE dossier est
        // déjà résolu avant ces statuts (débit à l'analyse, virement validé par
        // l'admin, ou voie sans faille non débitée par conception) — demander un
        // nouveau paiement relierait un compteur global déjà consommé ailleurs.
        // Les dossiers non payés passent par EN_ATTENTE_PAIEMENT (bloc ci-dessus).
        <div className="mt-8 flex flex-col gap-6">
            <div className="rounded-2xl border border-zinc-200 bg-white p-6">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h2 className="text-lg font-semibold">Signature de la lettre</h2>
                <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-800">
                  En attente de votre signature
                </span>
              </div>
              <p className="mt-2 text-sm text-zinc-600">
                Votre lettre de contestation a été préparée par notre équipe
                juridique. Elle vous sera présentée après l&apos;envoi de la
                contestation. Tracez simplement votre signature ci-dessous :
                elle sera apposée en bas de la lettre et le PDF final généré.
              </p>
              <div className="mt-4 flex items-center gap-3 rounded-xl border border-zinc-200 bg-zinc-50 p-4">
                <svg
                  viewBox="0 0 20 20"
                  fill="currentColor"
                  className="h-5 w-5 shrink-0 text-zinc-400"
                  aria-hidden
                >
                  <path
                    fillRule="evenodd"
                    d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z"
                    clipRule="evenodd"
                  />
                </svg>
                <p className="text-sm text-zinc-600">
                  Lettre confidentielle — révélée après l&apos;envoi validé par
                  un juriste.
                </p>
              </div>
            </div>

            <div className="rounded-2xl border border-zinc-200 bg-white p-6">
              <h2 className="text-lg font-semibold">Signature électronique</h2>
              <p className="mt-1 text-sm text-zinc-600">
                Votre signature sera collée automatiquement en bas de la lettre
                de contestation.
              </p>
              <div className="mt-6">
                <SignaturePad dossierId={item.id} signatureInitiale={signatureProfil} />
              </div>
            </div>
          </div>
      ) : item.statut === "PRET" && item.courriers.length > 0 ? (
        item.valideLe ? (
          item.canalEnvoi === "ANTAI" || item.canalEnvoi === "TELERECOURS" ? (
            <>
              <DepotAssiste
                dossierId={item.id}
                canal={item.canalEnvoi}
                type={item.type}
                numRef={
                  typeof item.extractedData?.num_pv === "string"
                    ? item.extractedData.num_pv
                    : null
                }
                plaque={
                  typeof item.extractedData?.plaque === "string"
                    ? item.extractedData.plaque
                    : null
                }
                dateLimite={item.dateLimite}
              />
              {pdfUrl && (
                <div className="mt-6">
                  <a href={pdfUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-4 py-2 text-sm font-semibold text-emerald-800 hover:bg-emerald-100">
                    Télécharger la lettre signée (PDF)
                  </a>
                </div>
              )}
              {(packRequeteUrl || packBordereauUrl) && (
                <div
                  data-testid="pack-telerecours"
                  className="mt-6 rounded-2xl border border-indigo-200 bg-indigo-50/50 p-6"
                >
                  <h2 className="text-sm font-semibold text-indigo-900">
                    Pack de dépôt Télérecours (3 documents)
                  </h2>
                  <p className="mt-1 text-sm text-indigo-800/90">
                    Téléchargez ces pièces, puis déposez-les avec votre
                    contestation sur le portail officiel (bouton ci-dessus).
                  </p>
                  <div className="mt-3 flex flex-wrap gap-3">
                    {packRequeteUrl && (
                      <a
                        data-testid="pack-requete"
                        href={packRequeteUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-2 rounded-full bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700"
                      >
                        Requête (PDF)
                      </a>
                    )}
                    {packRefereUrl && (
                      <a
                        data-testid="pack-refere"
                        href={packRefereUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-2 rounded-full border border-indigo-300 bg-white px-4 py-2 text-sm font-semibold text-indigo-800 hover:bg-indigo-100"
                      >
                        Référé-suspension L. 521-2 (PDF)
                      </a>
                    )}
                    {packBordereauUrl && (
                      <a
                        data-testid="pack-bordereau"
                        href={packBordereauUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-2 rounded-full border border-indigo-300 bg-white px-4 py-2 text-sm font-semibold text-indigo-800 hover:bg-indigo-100"
                      >
                        Bordereau des pièces (PDF)
                      </a>
                    )}
                  </div>
                </div>
              )}
            </>
          ) : (
            <>
              <EnvoiSuivi
                dateLimite={item.dateLimite}
                type={item.type}
              />
              {pdfUrl && (
                <div className="mt-6">
                  <a href={pdfUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-4 py-2 text-sm font-semibold text-emerald-800 hover:bg-emerald-100">
                    Télécharger la lettre signée (PDF)
                  </a>
                </div>
              )}
            </>
          )
        ) : (
          <div className="mt-8 rounded-2xl border border-zinc-200 bg-white p-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="text-lg font-semibold">Lettre signée</h2>
              <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-800">
                En attente de validation du juriste
              </span>
            </div>
            <p className="mt-1 text-sm text-zinc-600">
              Votre lettre est signée. Un juriste la vérifie avant que SOS
              Amende transmette votre contestation.
            </p>
            {item.lettreGeneree && (
              <div className="mt-4 whitespace-pre-wrap rounded-xl bg-zinc-50 p-6 text-sm leading-relaxed text-zinc-800">
                {item.lettreGeneree}
              </div>
            )}
            <p className="mt-3 text-xs font-medium text-zinc-500">
              Votre signature est apposée en bas de la lettre :
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-4">
              {signatureUrl && (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={signatureUrl}
                  alt="Votre signature"
                  className="h-16 w-auto rounded-lg border border-zinc-200 bg-white p-1"
                />
              )}
            </div>
          </div>
        )
      ) : item.statut === "ENVOYE" || item.statut === "RESOLU" ? (
        <div className="mt-8 flex flex-col gap-6">
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-6">
            <h2 className="font-semibold text-emerald-900">
              Contestation envoyée
            </h2>
            <p className="mt-1 text-sm text-emerald-800">
              {item.type === "AMENDE"
                ? "Votre contestation a été transmise par SOS Amende — l'OMP examinera votre requête"
                : "Votre contestation a été transmise par SOS Amende — le préfet examinera votre recours"}
              . Conservez votre accusé d&apos;envoi, il fait foi de la date.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {preuveDepotUrl ? (
                <a href={preuveDepotUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-semibold text-emerald-700 shadow hover:bg-emerald-50">
                  Voir l&apos;accusé de dépôt
                </a>
              ) : (
                <span className="inline-flex items-center gap-2 rounded-full bg-white/70 px-4 py-2 text-sm font-medium text-zinc-600">
                  Accusé : conservez le récépissé LRAR / dépôt en ligne
                </span>
              )}
              {pdfUrl && (
                <a href={pdfUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-4 py-2 text-sm font-semibold text-emerald-800 hover:bg-emerald-100">
                  Télécharger la lettre envoyée (PDF)
                </a>
              )}
            </div>
          </div>
          {lettreVisible && item.lettreGeneree && (
            <div className="rounded-2xl border border-zinc-200 bg-white p-6">
              <h2 className="text-lg font-semibold">
                Votre lettre de contestation
              </h2>
              <p className="mt-1 text-sm text-zinc-600">
                Contenu de la lettre vérifiée et validée par un juriste, telle
                que transmise.
              </p>
              <div className="mt-4 whitespace-pre-wrap rounded-xl bg-zinc-50 p-6 text-sm leading-relaxed text-zinc-800">
                {item.lettreGeneree}
              </div>
              {pdfUrl && (
                <a
                  href={pdfUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-4 inline-block rounded-full bg-emerald-600 px-6 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-700"
                >
                  Télécharger la lettre signée (PDF)
                </a>
              )}
            </div>
          )}
        </div>
      ) : item.statut === "AVOCAT_REQUIS" ? null : (
        <div className="mt-8 rounded-2xl border border-amber-200 bg-amber-50 p-6">
          <h2 className="font-semibold text-amber-900">Prochaines étapes</h2>
          <p className="mt-1 text-sm text-amber-800">
            Une fois signée et validée par un juriste, votre lettre sera
            transmise par SOS Amende (en ligne ou en recommandé avec accusé de
            réception).
          </p>
        </div>
      )}
    </div>
  );
}