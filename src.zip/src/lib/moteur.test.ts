import { describe, expect, it } from "vitest";
import {
  FAILLE_IDS,
  dateLimitePv,
  datePrescrite,
  detecterFaille,
  detecterFailles,
  echeanceVerificationRadar,
  etalonnageExpire,
  joursRestants,
  margeEthylometre,
  margeEthylometreSeuil,
  margeNonDeduite,
  margeTechniqueVitesse,
  meteoDefavorable,
  remplirLettreMulti,
  remplirTemplate,
  scoreFaille,
  type ExtractedData,
  type RegleDetection,
} from "./moteur";

const failles = Object.values(FAILLE_IDS).map((id) => ({ id }));

describe("datePrescrite", () => {
  it("prescrit une amende datée de plus d'un an", () => {
    expect(datePrescrite("2023-01-15")).toBe(true);
  });

  it("ne prescrit pas un PV récent", () => {
    expect(datePrescrite("2026-07-01")).toBe(false);
  });

  it("refuse une date absente ou invalide", () => {
    expect(datePrescrite(undefined)).toBe(false);
    expect(datePrescrite("pas-une-date")).toBe(false);
  });
});

describe("dateLimitePv", () => {
  it("applique 45 jours pour une amende", () => {
    const limite = dateLimitePv("2026-08-01", "AMENDE");
    expect(limite?.toISOString().slice(0, 10)).toBe("2026-09-15");
  });

  it("applique 2 mois pour une suspension", () => {
    const limite = dateLimitePv("2026-08-01", "SUSPENSION");
    expect(limite?.toISOString().slice(0, 10)).toBe("2026-09-30");
  });

  it("retourne null sans date", () => {
    expect(dateLimitePv(undefined, "AMENDE")).toBeNull();
  });
});

describe("joursRestants", () => {
  it("donne 0 restant à la date limite", () => {
    const limite = new Date();
    expect(joursRestants(limite)).toBe(0);
  });

  it("gère l'absence de date", () => {
    expect(joursRestants(null)).toBe(Number.POSITIVE_INFINITY);
  });
});

describe("detecterFaille", () => {
  it("priorise la prescription", () => {
    const faille = detecterFaille({ date: "2024-01-01" }, failles);
    expect(faille?.id).toBe(FAILLE_IDS.prescription);
  });

  it("détecte une erreur de plaque", () => {
    const faille = detecterFaille(
      { plaqueIncorrecte: true, numTelePaiement: "X", cle: "1" },
      failles,
    );
    expect(faille?.id).toBe(FAILLE_IDS.erreurPlaque);
  });

  it("détecte les mentions obligatoires manquantes", () => {
    expect(
      detecterFaille({ numTelePaiement: "" }, failles)?.id,
    ).toBe(FAILLE_IDS.mentions);
    expect(detecterFaille({ numTelePaiement: "X" }, failles)?.id).toBe(
      FAILLE_IDS.mentions,
    );
  });

  it("n'utilise plus le certificat d'étalonnage sans indice (exigence d'une preuve)", () => {
    expect(
      detecterFaille({ numTelePaiement: "X", cle: "1" }, failles),
    ).toBeNull();
  });

  it("détecte l'étalonnage quand le certificat du radar était expiré", () => {
    const faille = detecterFaille(
      { date: "2026-06-15", numTelePaiement: "X", cle: "1" },
      failles,
      { dateExpirationEtalonnage: "2026-01-01T00:00:00Z" },
    );
    expect(faille?.id).toBe(FAILLE_IDS.etalonnage);
  });

  it("ignore les failles absentes de la base", () => {
    expect(detecterFaille({ numTelePaiement: "X", cle: "1" }, [])).toBeNull();
  });
});

describe("detecterFailles (base juridique auto-alimentée)", () => {
  type FailleTest = { id: string; reglesDetection: RegleDetection[] };

  it("retourne toutes les failles candidates par règles, dans l'ordre de priorité", () => {
    const base: FailleTest[] = [
      {
        id: FAILLE_IDS.mentions,
        reglesDetection: [{ type: "champAbsent", champ: "cle" }],
      },
      {
        id: "faille-texte",
        reglesDetection: [{ type: "texteContient", motif: "radar" }],
      },
    ];
    expect(
      detecterFailles({ numTelePaiement: "X" }, "radar automatique MESTA", base),
    ).toEqual([FAILLE_IDS.mentions, "faille-texte"]);
  });

  it("une faille est candidate si l'une au moins de ses règles matche (OU)", () => {
    const base: FailleTest[] = [
      {
        id: "faille-ou",
        reglesDetection: [
          { type: "champAbsent", champ: "a" },
          { type: "champAbsent", champ: "b" },
        ],
      },
    ];
    expect(
      detecterFailles({ a: "présent" } as ExtractedData, null, base),
    ).toEqual(["faille-ou"]);
  });

  it("texteAbsent : la faille matche quand le motif est absent du texte scanné", () => {
    const base: FailleTest[] = [
      {
        id: "faille-absente",
        reglesDetection: [{ type: "texteAbsent", motif: "minorée" }],
      },
    ];
    expect(detecterFailles({}, "avis de contravention", base)).toEqual([
      "faille-absente",
    ]);
  });

  it("texteContient : la faille matche quand le motif est présent dans le texte", () => {
    const base: FailleTest[] = [
      {
        id: "faille-vitesse",
        reglesDetection: [{ type: "texteContient", motif: "exces de vitesse" }],
      },
    ];
    expect(
      detecterFailles({}, "PV pour exces de vitesse constaté", base),
    ).toEqual(["faille-vitesse"]);
  });

  it("les règles explicites priment sur les prédicats hérités", () => {
    const base: FailleTest[] = [
      {
        id: FAILLE_IDS.prescription,
        reglesDetection: [{ type: "texteContient", motif: "prescrit" }],
      },
    ];
    // date ancienne mais texte sans le mot : la règle explicite ne matche pas
    expect(
      detecterFailles({ date: "2024-01-01" }, "avis de contravention", base),
    ).toEqual([]);
  });
});

describe("etalonnageExpire", () => {
  it("détecte un certificat expiré le jour de l'infraction", () => {
    expect(
      etalonnageExpire("2026-01-01T00:00:00Z", "2026-06-15"),
    ).toBe(true);
  });

  it("valide un certificat encore en cours", () => {
    expect(
      etalonnageExpire("2026-12-31T00:00:00Z", "2026-06-15"),
    ).toBe(false);
  });

  it("refuse des entrées absentes ou invalides", () => {
    expect(etalonnageExpire(null, "2026-06-15")).toBe(false);
    expect(etalonnageExpire("2026-01-01", undefined)).toBe(false);
    expect(etalonnageExpire("pas-une-date", "2026-06-15")).toBe(false);
  });
});

describe("echeanceVerificationRadar", () => {
  const jour = (d: Date | null) => d?.toISOString().slice(0, 10) ?? null;

  it("+1 an par défaut (vérification annuelle obligatoire)", () => {
    expect(jour(echeanceVerificationRadar("2023-05-12"))).toBe("2024-05-12");
  });

  it("exception poste fixe : +2 ans quand la vérification suit la mise en service (≤ 26 mois)", () => {
    expect(
      jour(echeanceVerificationRadar("2023-05-12", "2022-06-01T00:00:00Z")),
    ).toBe("2025-05-12");
  });

  it("+1 an passé les 26 mois (vérifications suivantes redevenues annuelles)", () => {
    expect(
      jour(echeanceVerificationRadar("2025-05-12", "2022-06-01T00:00:00Z")),
    ).toBe("2026-05-12");
  });

  it("accepte le format français dd/mm/yyyy l'OCR peut produire", () => {
    expect(jour(echeanceVerificationRadar("12/05/2023"))).toBe("2024-05-12");
  });

  it("refuse les dates absentes ou illisibles (jamais de date fabriquée)", () => {
    expect(echeanceVerificationRadar(null)).toBeNull();
    expect(echeanceVerificationRadar(undefined)).toBeNull();
    expect(echeanceVerificationRadar("pas-une-date")).toBeNull();
    expect(echeanceVerificationRadar("2023-13-45")).toBeNull();
  });
});

describe("meteoDefavorable", () => {
  it("retient les conditions connues pour nuire à la visibilité", () => {
    expect(meteoDefavorable("Pluie forte • 8/12°C")).toBe(true);
    expect(meteoDefavorable("Bruine modérée")).toBe(true);
    expect(meteoDefavorable("Brouillard • 3/6°C")).toBe(true);
    expect(meteoDefavorable("Neige modérée")).toBe(true);
    expect(meteoDefavorable("Verglas")).toBe(true);
    expect(meteoDefavorable("Averses de pluie modérées")).toBe(true);
    expect(meteoDefavorable("Orages avec grêle légère")).toBe(true);
    expect(meteoDefavorable("Tempête")).toBe(true);
  });

  it("retient des rafales fortes même sans mot-clé de condition", () => {
    expect(meteoDefavorable("Ciel dégagé • 9/15°C • Rafales: 80 km/h")).toBe(
      true,
    );
    expect(meteoDefavorable("Rafales: 70 km/h")).toBe(true);
  });

  it("écarte une journée clémente ou de simples rafales faibles", () => {
    expect(meteoDefavorable("Ciel dégagé • 9/15°C")).toBe(false);
    expect(meteoDefavorable("Partiellement nuageux • 12/18°C • Rafales: 25 km/h")).toBe(
      false,
    );
    expect(meteoDefavorable("Principalement clair")).toBe(false);
  });

  it("refuse une valeur absente", () => {
    expect(meteoDefavorable(null)).toBe(false);
    expect(meteoDefavorable(undefined)).toBe(false);
    expect(meteoDefavorable("")).toBe(false);
  });
});

describe("remplirTemplate", () => {
  it("remplace toutes les variables connues", () => {
    const template =
      "Je soussigné {nom}, véhicule {plaque}, conteste le PV {num_pv}.";
    const lettre = remplirTemplate(template, {
      nom: "DUPONT",
      plaque: "AB-123-CD",
      num_pv: "123456",
    });
    expect(lettre).toBe(
      "Je soussigné DUPONT, véhicule AB-123-CD, conteste le PV 123456.",
    );
  });

  it("écrit les dates en toutes lettres (qualité rédaction française)", () => {
    const lettre = remplirTemplate(
      "J'ai reçu le PV {num_pv} en date du {date}.",
      { num_pv: "123", date: "2026-05-01" },
    );
    expect(lettre).toContain("en date du 1er mai 2026");
    expect(lettre).not.toContain("2026-05-01");
  });

  it("retire les variables inconnues et leurs artefacts (jamais {x} brut)", () => {
    expect(remplirTemplate("PV {num_pv} motif {inconnu}", {})).toBe(
      "PV motif",
    );
    expect(remplirTemplate("cinémomètre n° {radarId}", {})).toBe(
      "cinémomètre",
    );
  });

  it("nettoie les espaces et la ponctuation résiduels", () => {
    expect(remplirTemplate("Texte  avec   des   espaces .", {})).toBe(
      "Texte avec des espaces.",
    );
  });

  it("préserve la typographie française (espace avant « : » « ; » « ! » « ? »)", () => {
    const lettre = remplirTemplate(
      "infraction : celui-ci ne m'a pas été notifié ; l'amende est, dès lors, inopposable !",
      {},
    );
    expect(lettre).toContain("infraction : celui-ci");
    expect(lettre).toContain("notifié ; l'amende");
    expect(lettre).toContain("inopposable !");
  });
});

describe("remplirLettreMulti", () => {
  const data: ExtractedData = {
    nom: "DUPONT",
    plaque: "AB-123-CD",
    num_pv: "123",
  };
  const prescription = {
    id: FAILLE_IDS.prescription,
    titreFaille: "Prescription de l'action publique",
    articleLoi: "Art. 9 CPP",
    templateLettre:
      "Je soussigné {nom}, conteste le PV {num_pv}.\n\nLa prescription est acquise après un an.\n\nJe demande l'annulation.",
  };
  const erreurPlaque = {
    id: FAILLE_IDS.erreurPlaque,
    titreFaille: "Erreur de plaque",
    articleLoi: "Art. 530-1 CPP",
    templateLettre:
      "Je soussigné {nom}, véhicule {plaque}.\n\nLa plaque ne correspond pas à mon véhicule.",
  };

  it("retourne le template unique tel quel quand une seule faille", () => {
    expect(remplirLettreMulti([prescription], data)).toBe(
      remplirTemplate(prescription.templateLettre, data),
    );
  });

  it("fond toutes les failles en une lettre fluide, sans étiquette ni répétition de l'identification", () => {
    const lettreOk = remplirLettreMulti([prescription, erreurPlaque], data)!;
    expect(lettreOk).not.toContain("Argument n°");
    // pas de sous-titre « — titre (article) »
    expect(lettreOk).not.toContain("Prescription de l'action publique");
    expect(lettreOk).not.toContain("Erreur de plaque");
    // identification portée une seule fois (première faille)
    expect(lettreOk).toContain("Je soussigné DUPONT, conteste le PV 123.");
    // la 2e faille ne répète pas l'identification (« véhicule AB-123-CD »)
    expect(lettreOk).not.toContain("véhicule AB-123-CD");
    // ses arguments s'enchaînent naturellement
    expect(lettreOk).toContain("La prescription est acquise après un an.");
    expect(lettreOk).toContain("Je demande l'annulation.");
    expect(lettreOk).toContain("La plaque ne correspond pas à mon véhicule.");
  });

  it("garde le texte entier d'une faille monopharagraphique (pas d'en-tête détachable)", () => {
    const une = {
      id: "faille-x",
      titreFaille: "Faille X",
      articleLoi: "",
      templateLettre: "En-tête de {nom}.",
    };
    const lettre = remplirLettreMulti([prescription, une], data)!;
    expect(lettre).not.toContain("Argument n°");
    expect(lettre).toContain("En-tête de DUPONT.");
  });

  it("ne conclut qu'une seule fois : les conclusions redondantes des autres failles sont retirées", () => {
    const conclusionDeux = {
      id: "faille-y",
      titreFaille: "Faille Y",
      articleLoi: "Art. X",
      templateLettre:
        "Je soussigné {nom}, conteste aussi le PV {num_pv}.\n\nLe lieu est imprécis.\n\nEn conséquence, je vous demande de bien vouloir annuler la contravention.",
    };
    const lettre = remplirLettreMulti([prescription, conclusionDeux], data)!;
    // l'argument des deux failles est présent
    expect(lettre).toContain("Le lieu est imprécis.");
    expect(lettre).toContain("La prescription est acquise après un an.");
    // une seule conclusion finale (celle retenue), jamais répétée au milieu
    const occurrencesEnConsequence =
      lettre.split("En conséquence").length - 1;
    expect(occurrencesEnConsequence).toBe(1);
    expect(lettre.trim().endsWith("En conséquence, je vous demande de bien vouloir annuler la contravention.")).toBe(
      true,
    );
  });

  it("retourne null sans faille", () => {
    expect(remplirLettreMulti([], data)).toBeNull();
  });
});

describe("scoreFaille", () => {
  it("retourne null si aucune règle ne matche (faille non candidate)", () => {
    expect(
      scoreFaille(
        {
          id: "faille-x",
          reglesDetection: [
            { type: "texteContient", motif: "introuvable" },
          ],
        },
        {},
        "texte sans motif",
      ),
    ).toBeNull();
  });

  it("plafonne une faille de catalogue à score non calibré", () => {
    // Une règle unique prouve la candidature, pas la réussite : pas de 98 %.
    expect(
      scoreFaille(
        { id: "faille-x", reglesDetection: [{ type: "champAbsent", champ: "cle" }] },
        {},
        null,
      ),
    ).toEqual({ matchees: 1, total: 1, score: 45, calibree: false });
  });

  it("respecte la calibration d'une faille calibrée à règle unique", () => {
    // Étalonnage : base 82 + 13 (certificat expiré) = 95, calibration juriste.
    expect(
      scoreFaille(
        {
          id: FAILLE_IDS.etalonnage,
          reglesDetection: [{ type: "etalonnageExpire" }],
        },
        { radarId: "1248", date: "2026-07-01" },
        null,
        { dateExpirationEtalonnage: "2020-01-01" },
      ),
    ).toMatchObject({ matchees: 1, total: 1, score: 95, calibree: true });
  });

  it("plafonne à 45 une faille de catalogue même avec une règle sur deux", () => {
    expect(
      scoreFaille(
        {
          id: "faille-x",
          reglesDetection: [
            { type: "texteContient", motif: "vitesse" },
            { type: "texteContient", motif: "introuvable" },
          ],
        },
        {},
        "excès de vitesse constaté",
      ),
    ).toEqual({ matchees: 1, total: 2, score: 45, calibree: false });
  });

  it("une faille calibrée à 1 règle sur 2 reste plafonnée à 60", () => {
    expect(
      scoreFaille(
        {
          id: FAILLE_IDS.mentions,
          reglesDetection: [
            { type: "texteContient", motif: "vitesse" },
            { type: "texteContient", motif: "introuvable" },
          ],
        },
        {},
        "excès de vitesse constaté",
      ),
    ).toEqual({ matchees: 1, total: 2, score: 60, calibree: true });
  });

  it("deux règles corroborantes débloquent le plafond de 98", () => {
    expect(
      scoreFaille(
        {
          id: FAILLE_IDS.mentions,
          reglesDetection: [
            { type: "texteContient", motif: "vitesse" },
            { type: "texteContient", motif: "constat" },
          ],
        },
        {},
        "excès de vitesse constaté sur le radar",
      ),
    ).toEqual({ matchees: 2, total: 2, score: 92, calibree: true });
  });

  it("évalue le prédicat hérité pour une faille connue sans règles", () => {
    expect(
      scoreFaille(
        { id: FAILLE_IDS.prescription },
        { date: "2020-01-01" },
        null,
      ),
    ).toEqual({ matchees: 1, total: 1, score: 88, calibree: true });
  });
});

describe("FAILLE_IDS — synchronisation seed (audit lot 5)", () => {
  it("ne contient que les 4 failles AMENDE seedées (aucun id fantôme)", () => {
    expect([...Object.values(FAILLE_IDS)].sort()).toEqual(
      [
        "faille-certificat-etalonnage",
        "faille-erreur-plaque",
        "faille-mentions-obligatoires",
        "faille-prescription-1-an",
      ].sort(),
    );
  });
});
describe("règles du pack 3F/48SI (types additifs)", () => {
  const uneSeule = (id: string, regle: unknown) => [
    { id, reglesDetection: [regle as RegleDetection] },
  ];
  const PACK_ID = "faille-3f-delai-retention";

  it("delaiDepasse : horodatage contrôle → signature (72 h)", () => {
    const faillesPack = uneSeule(PACK_ID, { type: "delaiDepasse", limiteHeures: 72 });
    // 97 h entre le contrôle et la signature de l'arrêté → dépassé.
    expect(
      detecterFailles(
        { date: "2026-07-01", heure: "08:00", dateSignatureArrete: "2026-07-05", heureSignatureArrete: "09:00" },
        null,
        faillesPack,
      ),
    ).toEqual([PACK_ID]);
    // 26 h → dans les délais.
    expect(
      detecterFailles(
        { date: "2026-07-01", heure: "08:00", dateSignatureArrete: "2026-07-02", heureSignatureArrete: "09:00" },
        null,
        faillesPack,
      ),
    ).toEqual([]);
    // Date de signature absente → aucun horodatage fabriqué.
    expect(
      detecterFailles(
        { date: "2026-07-01", heure: "08:00" },
        null,
        faillesPack,
      ),
    ).toEqual([]);
    expect(
      detecterFailles(
        { dateSignatureArrete: "2026-07-05", heureSignatureArrete: "09:00" },
        null,
        faillesPack,
      ),
    ).toEqual([]);
  });

  it("delaiDepasse : siChamp conditionne le délai au motif (72 h vitesse)", () => {
    const faillesPack = uneSeule(PACK_ID, {
      type: "delaiDepasse",
      limiteHeures: 72,
      siChamp: { champ: "motif", valeur: "vitesse" },
    });
    const base = { date: "2026-07-01", heure: "08:00", dateSignatureArrete: "2026-07-05", heureSignatureArrete: "09:00" };
    expect(detecterFailles({ ...base, motif: "excès de vitesse" }, null, faillesPack)).toEqual([PACK_ID]);
    expect(detecterFailles({ ...base, motif: "alcoolémie" }, null, faillesPack)).toEqual([]);
    expect(detecterFailles(base, null, faillesPack)).toEqual([]);
  });

  it("datePrealable : stage effectué avant la notification (48SI)", () => {
    const faillesPack = uneSeule("faille-48si-stage-avant-notification", {
      type: "datePrealable",
      champ: "dateStage",
      reference: "dateNotification",
    });
    expect(
      detecterFailles({ dateStage: "2026-06-01", dateNotification: "2026-06-15" }, null, faillesPack),
    ).toEqual(["faille-48si-stage-avant-notification"]);
    // Stage postérieur à la notification → pas de candidature.
    expect(
      detecterFailles({ dateStage: "2026-06-20", dateNotification: "2026-06-15" }, null, faillesPack),
    ).toEqual([]);
    expect(
      detecterFailles({ dateStage: "2026-06-01" }, null, faillesPack),
    ).toEqual([]);
  });

  it("valeurSuperieure : cumul de points, en nombre ou en chaîne", () => {
    const faillesPack = uneSeule("faille-48si-plafond-8pts", {
      type: "valeurSuperieure",
      champ: "pointsRetiresMemesDate",
      seuil: 8,
    });
    expect(detecterFailles({ pointsRetiresMemesDate: 9 }, null, faillesPack)).toEqual(["faille-48si-plafond-8pts"]);
    expect(detecterFailles({ pointsRetiresMemesDate: "9" }, null, faillesPack)).toEqual(["faille-48si-plafond-8pts"]);
    expect(detecterFailles({ pointsRetiresMemesDate: "9,5" }, null, faillesPack)).toEqual(["faille-48si-plafond-8pts"]);
    // Seuil strict : 8 n'est pas supérieur à 8.
    expect(detecterFailles({ pointsRetiresMemesDate: 8 }, null, faillesPack)).toEqual([]);
    expect(detecterFailles({ pointsRetiresMemesDate: "" }, null, faillesPack)).toEqual([]);
    expect(detecterFailles({}, null, faillesPack)).toEqual([]);
  });

  it("et : toutes les sous-règles doivent matcher (sinon OU entre règles d'une faille)", () => {
    const faillesPack = uneSeule("faille-48si-plafond-8pts", {
      type: "et",
      regles: [
        { type: "valeurSuperieure", champ: "pointsRetiresMemesDate", seuil: 8 },
        { type: "champAbsent", champ: "dateNotification" },
      ],
    });
    expect(detecterFailles({ pointsRetiresMemesDate: 9 }, null, faillesPack)).toEqual(["faille-48si-plafond-8pts"]);
    expect(detecterFailles({ pointsRetiresMemesDate: 9, dateNotification: "2026-06-15" }, null, faillesPack)).toEqual([]);
    expect(detecterFailles({ dateNotification: "2026-06-15" }, null, faillesPack)).toEqual([]);
  });

  it("cloisonnement docType : une règle 3F ne matche jamais sur une 48SI (ni sans classement)", () => {
    const faillesPack = uneSeule(PACK_ID, {
      type: "texteContient",
      motif: "vitesse",
      docType: "3F",
    });
    expect(detecterFailles({ docType: "3F" }, "avis pour excès de vitesse", faillesPack)).toEqual([PACK_ID]);
    expect(detecterFailles({ docType: "48SI" }, "avis pour excès de vitesse", faillesPack)).toEqual([]);
    expect(detecterFailles({ docType: "AMENDE" }, "avis pour excès de vitesse", faillesPack)).toEqual([]);
    expect(detecterFailles({}, "avis pour excès de vitesse", faillesPack)).toEqual([]);
  });

  it("les failles pack passent après les 4 failles seedées, les autres après", () => {
    const faillesOrdre = [
      { id: PACK_ID, reglesDetection: [{ type: "texteContient", motif: "vitesse" } as RegleDetection] },
      { id: FAILLE_IDS.prescription },
      { id: "faille-autre-suspension", reglesDetection: [{ type: "texteContient", motif: "vitesse" } as RegleDetection] },
    ];
    expect(
      detecterFailles({ date: "2024-01-01" }, "avis pour excès de vitesse", faillesOrdre),
    ).toEqual([FAILLE_IDS.prescription, PACK_ID, "faille-autre-suspension"]);
  });
});

describe("marges arithmétiques (chantier 1)", () => {
  const uneSeule = (id: string, regle: unknown) => [
    { id, reglesDetection: [regle as RegleDetection] },
  ];
  const VITESSE = "faille-marge-tolerance-vitesse";
  const ALCOOL = "faille-suspension-marge-erreur-ethylometre";

  describe("helpers purs", () => {
    it("margeTechniqueVitesse : −5 sous 100, −5 % au-delà (arrondi supérieur)", () => {
      expect(margeTechniqueVitesse(50)).toBe(5);
      expect(margeTechniqueVitesse(99)).toBe(5);
      expect(margeTechniqueVitesse(100)).toBe(5); // 5 % de 100 = 5
      expect(margeTechniqueVitesse(101)).toBe(6); // 5,05 → 6 (supérieur favorable au client)
      expect(margeTechniqueVitesse(110)).toBe(6); // 5,5 → 6
      expect(margeTechniqueVitesse(120)).toBe(6);
      expect(margeTechniqueVitesse(137)).toBe(7); // 6,85 → 7
      expect(margeTechniqueVitesse(200)).toBe(10);
    });

    it("margeEthylometre : fixe sous le seuil, 8 % au-delà (3 décimales)", () => {
      expect(margeEthylometre(0.3, "g/L")).toBeCloseTo(0.032, 3);
      expect(margeEthylometre(0.4, "g/L")).toBeCloseTo(0.032, 3); // seuil inclus → fixe
      expect(margeEthylometre(0.5, "g/L")).toBeCloseTo(0.04, 3); // 8 % de 0,5
      expect(margeEthylometre(0.1, "mg/L")).toBeCloseTo(0.016, 3);
      expect(margeEthylometre(0.2, "mg/L")).toBeCloseTo(0.016, 3);
      expect(margeEthylometre(0.25, "mg/L")).toBeCloseTo(0.02, 3); // 8 % de 0,25
    });

    it("margeNonDeduite : retenu absent → false (jamais de contexte fabriqué)", () => {
      expect(
        margeNonDeduite({ valeur: 93, unite: "km/h" }, 5),
      ).toBe(false);
    });

    it("margeNonDeduite : déduction insuffisante → true ; marge appliquée → false", () => {
      // 93 mesuré, retenu 93 (rien déduit) → faille.
      expect(margeNonDeduite({ valeur: 93, retenu: 93, unite: "km/h" }, 5)).toBe(true);
      // 93 mesuré, retenu 88 (−5 exact) → pas de faille.
      expect(margeNonDeduite({ valeur: 93, retenu: 88, unite: "km/h" }, 5)).toBe(false);
      // Déduction partielle (−3 sur −5 requis) → faille.
      expect(margeNonDeduite({ valeur: 93, retenu: 90, unite: "km/h" }, 5)).toBe(true);
      // Alcoolémie : 0,50 g/L retenu 0,50 (8 % non déduit) → faille.
      expect(margeNonDeduite({ valeur: 0.5, retenu: 0.5, unite: "g/L" }, 0.04)).toBe(true);
      // 0,50 g/L retenu 0,46 (−0,04 = 8 %) → pas de faille.
      expect(margeNonDeduite({ valeur: 0.5, retenu: 0.46, unite: "g/L" }, 0.04)).toBe(false);
    });
  });

  describe("règle margeTechniqueVitesse", () => {
    const failles = uneSeule(VITESSE, { type: "margeTechniqueVitesse" });

    it("active la faille si la marge n'est pas déduite (< 100 km/h)", () => {
      // 93 mesuré, retenu 93 → 0 < 5.
      expect(
        detecterFailles({ docType: "AMENDE", mesure: { valeur: 93, retenu: 93, unite: "km/h" } }, null, failles),
      ).toEqual([VITESSE]);
      // 93 mesuré, retenu 91 → 2 < 5.
      expect(
        detecterFailles({ docType: "AMENDE", mesure: { valeur: 93, retenu: 91, unite: "km/h" } }, null, failles),
      ).toEqual([VITESSE]);
    });

    it("n'active pas la faille si la marge est appliquée", () => {
      expect(
        detecterFailles({ docType: "AMENDE", mesure: { valeur: 93, retenu: 88, unite: "km/h" } }, null, failles),
      ).toEqual([]);
      expect(
        detecterFailles({ docType: "AMENDE", mesure: { valeur: 137, retenu: 130, unite: "km/h" } }, null, failles),
      ).toEqual([]); // −7 ≥ marge 7
    });

    it("utilise 5 % au-delà de 100 km/h (arrondi supérieur)", () => {
      // 137 mesuré, retenu 133 → 4 < 7.
      expect(
        detecterFailles({ docType: "AMENDE", mesure: { valeur: 137, retenu: 133, unite: "km/h" } }, null, failles),
      ).toEqual([VITESSE]);
      // 137 mesuré, retenu 130 → −7 = marge → pas de faille.
      expect(
        detecterFailles({ docType: "AMENDE", mesure: { valeur: 137, retenu: 130, unite: "km/h" } }, null, failles),
      ).toEqual([]);
      // 101 mesuré, retenu 96 → −5 < marge 6 (5,05 arrondi supérieur) → faille.
      expect(
        detecterFailles({ docType: "AMENDE", mesure: { valeur: 101, retenu: 96, unite: "km/h" } }, null, failles),
      ).toEqual([VITESSE]);
      // 101 mesuré, retenu 95 → −6 = marge → pas de faille.
      expect(
        detecterFailles({ docType: "AMENDE", mesure: { valeur: 101, retenu: 95, unite: "km/h" } }, null, failles),
      ).toEqual([]);
    });

    it("n'exige plus la présence du mot « marge » dans le texte", () => {
      expect(
        detecterFailles(
          { docType: "AMENDE", mesure: { valeur: 93, retenu: 93, unite: "km/h" } },
          "PV sans le mot marge",
          failles,
        ),
      ).toEqual([VITESSE]);
    });

    it("exige mesure.valeur ET mesure.retenu (aucun contexte fabriqué)", () => {
      expect(
        detecterFailles({ docType: "AMENDE", mesure: { valeur: 93, unite: "km/h" } }, null, failles),
      ).toEqual([]); // retenu absent
      expect(
        detecterFailles(
          { docType: "AMENDE", mesure: { retenu: 88, unite: "km/h" } as unknown as { valeur: number; retenu?: number; unite: "km/h" } },
          null,
          failles,
        ),
      ).toEqual([]); // valeur absente
      expect(detecterFailles({ docType: "AMENDE" }, null, failles)).toEqual([]); // mesure absente
    });

    it("cloisonne : jamais sur un document de suspension", () => {
      expect(
        detecterFailles({ docType: "3F", mesure: { valeur: 93, retenu: 93, unite: "km/h" } }, null, failles),
      ).toEqual([]);
      expect(
        detecterFailles({ docType: "48SI", mesure: { valeur: 93, retenu: 93, unite: "km/h" } }, null, failles),
      ).toEqual([]);
    });

    it("n'exige pas d'unité fausse (mg/L sur une règle vitesse)", () => {
      expect(
        detecterFailles({ docType: "AMENDE", mesure: { valeur: 93, retenu: 93, unite: "mg/L" } }, null, failles),
      ).toEqual([]);
    });
  });

  describe("règle margeEthylometre", () => {
    const failles = uneSeule(ALCOOL, { type: "margeEthylometre" });

    it("active la faille si les 8 % ne sont pas déduits (g/L)", () => {
      expect(
        detecterFailles({ mesure: { valeur: 0.5, retenu: 0.5, unite: "g/L" } }, null, failles),
      ).toEqual([ALCOOL]);
      expect(
        detecterFailles({ mesure: { valeur: 0.5, retenu: 0.48, unite: "g/L" } }, null, failles),
      ).toEqual([ALCOOL]); // −0,02 < 0,04
    });

    it("n'active pas la faille si la marge 8 % est appliquée (g/L)", () => {
      expect(
        detecterFailles({ mesure: { valeur: 0.5, retenu: 0.46, unite: "g/L" } }, null, failles),
      ).toEqual([]);
    });

    it("marge fixe sous le seuil (mg/L)", () => {
      // 0,18 mg/L mesuré, retenu 0,18 → 0 < 0,016.
      expect(
        detecterFailles({ mesure: { valeur: 0.18, retenu: 0.18, unite: "mg/L" } }, null, failles),
      ).toEqual([ALCOOL]);
      // 0,18 mg/L retenu 0,16 → −0,02 ≥ 0,016 → pas de faille.
      expect(
        detecterFailles({ mesure: { valeur: 0.18, retenu: 0.16, unite: "mg/L" } }, null, failles),
      ).toEqual([]);
    });

    it("exige retenu présent (jamais de contexte fabriqué)", () => {
      expect(
        detecterFailles({ mesure: { valeur: 0.5, unite: "g/L" } }, null, failles),
      ).toEqual([]);
      expect(detecterFailles({}, null, failles)).toEqual([]);
    });

    it("n'exige pas d'unité fausse (km/h sur une règle alcool)", () => {
      expect(
        detecterFailles({ mesure: { valeur: 0.5, retenu: 0.5, unite: "km/h" } }, null, failles),
      ).toEqual([]);
    });
  });

  describe("règle margeEthylometreSeuil (P3 — seuil 0,2 g/L nouveau conducteur)", () => {
    const SEUIL02 = "faille-alcool-marge-seuil-02";
    const failles = uneSeule(SEUIL02, { type: "margeEthylometreSeuil", seuil: 0.2 });

    it("margeEthylometreSeuil : fixe seuil×0,08 sous le seuil, 8 % au-delà", () => {
      expect(margeEthylometreSeuil(0.19, "g/L", 0.2)).toBeCloseTo(0.016, 3);
      expect(margeEthylometreSeuil(0.21, "g/L", 0.2)).toBeCloseTo(0.017, 3); // 8 % de 0,21
      expect(margeEthylometreSeuil(0.25, "g/L", 0.2)).toBeCloseTo(0.02, 3); // 8 % de 0,25
    });

    it("active la faille si la marge ramène sous le seuil (0,21 → 0,193 < 0,2)", () => {
      expect(
        detecterFailles({ mesure: { valeur: 0.21, unite: "g/L" } }, null, failles),
      ).toEqual([SEUIL02]);
    });

    it("n'active pas la faille si après marge on reste au-dessus (0,25 → 0,23 > 0,2)", () => {
      expect(
        detecterFailles({ mesure: { valeur: 0.25, unite: "g/L" } }, null, failles),
      ).toEqual([]);
    });

    it("n'active pas la faille si pas de dépassement allégué (valeur ≤ seuil)", () => {
      expect(
        detecterFailles({ mesure: { valeur: 0.19, unite: "g/L" } }, null, failles),
      ).toEqual([]);
      expect(
        detecterFailles({ mesure: { valeur: 0.2, unite: "g/L" } }, null, failles),
      ).toEqual([]);
    });

    it("cloisonne l'unité (km/h ignoré) et sans mesure → rien", () => {
      expect(
        detecterFailles({ mesure: { valeur: 0.21, unite: "km/h" } }, null, failles),
      ).toEqual([]);
      expect(detecterFailles({}, null, failles)).toEqual([]);
    });
  });

  describe("règle valeurPlageMesure (P3 — bande nouveau conducteur ]0,2 ; 0,5] g/L)", () => {
    const NON_PROUVE = "faille-alcool-seuil-02-non-prouve";
    const failles = uneSeule(NON_PROUVE, {
      type: "valeurPlageMesure",
      min: 0.2,
      max: 0.5,
      unite: "g/L",
    });

    it("active la faille dans la bande (0,21 à 0,5 g/L)", () => {
      for (const valeur of [0.21, 0.25, 0.4, 0.5]) {
        expect(
          detecterFailles({ mesure: { valeur, unite: "g/L" } }, null, failles),
        ).toEqual([NON_PROUVE]);
      }
    });

    it("n'active pas la faille hors bande (≤ 0,2 ou > 0,5 g/L)", () => {
      for (const valeur of [0.15, 0.2, 0.51, 0.8]) {
        expect(
          detecterFailles({ mesure: { valeur, unite: "g/L" } }, null, failles),
        ).toEqual([]);
      }
    });

    it("cloisonne l'unité (mg/L ignoré même dans la plage numérique)", () => {
      expect(
        detecterFailles({ mesure: { valeur: 0.3, unite: "mg/L" } }, null, failles),
      ).toEqual([]);
    });

    it("sans mesure → rien", () => {
      expect(detecterFailles({}, null, failles)).toEqual([]);
    });
  });
});

describe("règles questionnaire (veille 2.0 — reponseVrai / reponseFausse / reponseTexte)", () => {
  const uneSeule = (id: string, regle: unknown) => [
    { id, reglesDetection: [regle as RegleDetection] },
  ];
  const ID = "faille-veille-dyn";

  it("reponseVrai : case cochée (true) → candidature", () => {
    // Clé hors ExtractedData : le moteur lit le champ tel quel (Record).
    const liste = uneSeule(ID, { type: "reponseVrai", champ: "question_dyn" });
    expect(detecterFailles({ question_dyn: true } as never, null, liste)).toEqual([ID]);
    // Absence, false ou valeur fausse → jamais.
    expect(detecterFailles({}, null, liste)).toEqual([]);
    expect(detecterFailles({ question_dyn: false } as never, null, liste)).toEqual([]);
    expect(detecterFailles({ question_dyn: "true" } as never, null, liste)).toEqual([]);
  });

  it("reponseFausse : case NON cochée (absente / false) → candidature", () => {
    const liste = uneSeule(ID, { type: "reponseFausse", champ: "question_dyn" });
    // Absence (jamais cochée) = la réponse avérée est « non » → match.
    expect(detecterFailles({}, null, liste)).toEqual([ID]);
    expect(detecterFailles({ question_dyn: false } as never, null, liste)).toEqual([ID]);
    // Cochée (true) → pas de match.
    expect(detecterFailles({ question_dyn: true } as never, null, liste)).toEqual([]);
  });

  it("reponseTexte : champ texte non vide (trim) → candidature", () => {
    const liste = uneSeule(ID, { type: "reponseTexte", champ: "question_dyn" });
    expect(detecterFailles({ question_dyn: "12345678901234" } as never, null, liste)).toEqual([ID]);
    expect(detecterFailles({ question_dyn: "  " } as never, null, liste)).toEqual([]);
    expect(detecterFailles({ question_dyn: "" } as never, null, liste)).toEqual([]);
    expect(detecterFailles({}, null, liste)).toEqual([]);
    expect(detecterFailles({ question_dyn: 0 } as never, null, liste)).toEqual([]);
  });

  it("reponseVrai : une valeur texte (radio) ne matche jamais — seuls les booléens true", () => {
    // Le mapping `reglesDetectionPourQuestions` n'émet `reponseVrai` que pour
    // une case booléenne ; une valeur de radio (string) n'est jamais érigée en
    // « true » par le moteur (anti-fabrique de fondement).
    const liste = uneSeule(ID, { type: "reponseVrai", champ: "question_dyn" });
    expect(detecterFailles({ question_dyn: true } as never, null, liste)).toEqual([ID]);
    expect(detecterFailles({ question_dyn: "salarie" } as never, null, liste)).toEqual([]);
    expect(detecterFailles({}, null, liste)).toEqual([]);
  });

  it("plusieurs règles d'une même faille : sémantique OU", () => {
    const liste = [
      {
        id: ID,
        reglesDetection: [
          { type: "reponseVrai", champ: "paiementDejaFait" },
          { type: "reponseVrai", champ: "vehiculeVole" },
        ] as RegleDetection[],
      },
    ];
    expect(detecterFailles({ paiementDejaFait: true }, null, liste)).toEqual([ID]);
    expect(detecterFailles({ vehiculeVole: true }, null, liste)).toEqual([ID]);
    expect(detecterFailles({}, null, liste)).toEqual([]);
  });

  it("cloisonnement docType : une règle questionnaire pack ne matche jamais sans classement", () => {
    const liste = uneSeule("faille-3f-delai-retention", {
      type: "reponseVrai",
      champ: "suspSignataireNonPrefet",
      docType: "3F",
    });
    expect(
      detecterFailles({ docType: "3F", suspSignataireNonPrefet: true }, null, liste),
    ).toEqual(["faille-3f-delai-retention"]);
    expect(
      detecterFailles({ suspSignataireNonPrefet: true }, null, liste),
    ).toEqual([]);
    expect(
      detecterFailles({ docType: "AMENDE", suspSignataireNonPrefet: true }, null, liste),
    ).toEqual([]);
  });
});
