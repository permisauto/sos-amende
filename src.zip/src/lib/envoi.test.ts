import { describe, expect, it } from "vitest";
import {
  canauxEnvoi,
  civiliteJugeAdministratif,
  corpsDepuisLettreHabillee,
  dateRefLibelle,
  delaiLibelle,
  destinataireLrar,
  formuleAppel,
  formuleEnTeteDestinataire,
  formulePolitesse,
  formaterLettreOfficielle,
  identiteExtrait,
  libelleCanal,
  libelleCanalDepuisStockage,
  lireDocType,
  numeroRefLibelle,
  objetLettre,
  organismeEnvoi,
  pieceAJoindre,
  portailEnLigne,
  titreAnalyse,
  titreRequete,
} from "./envoi";

describe("envoi — libellés par type d'infraction", () => {
  it("destinataire LRAR : OMP pour une amende, préfet pour une suspension", () => {
    expect(destinataireLrar("AMENDE")).toContain("OMP");
    expect(destinataireLrar("SUSPENSION")).toContain("préfet");
  });

  it("pièce à joindre adaptée", () => {
    expect(pieceAJoindre("AMENDE")).toContain("avis de contravention");
    expect(pieceAJoindre("SUSPENSION")).toContain("décision");
  });

  it("délais : 45 jours (amende) vs 2 mois (suspension)", () => {
    expect(delaiLibelle("AMENDE")).toContain("45 jours");
    expect(delaiLibelle("SUSPENSION")).toContain("2 mois");
  });

  it("labels du formulaire d'analyse adaptés", () => {
    expect(numeroRefLibelle("AMENDE")).toBe("Numéro de PV");
    expect(numeroRefLibelle("SUSPENSION")).toBe("Numéro de décision");
    expect(dateRefLibelle("AMENDE")).toBe("Date du PV");
    expect(dateRefLibelle("SUSPENSION")).toBe("Date de la décision");
    expect(titreAnalyse("AMENDE")).toContain("avis");
    expect(titreAnalyse("SUSPENSION")).toContain("décision");
  });

  it("portails officiels de dépôt en ligne : ANTAI vs Télérecours", () => {
    const amende = portailEnLigne("AMENDE");
    expect(amende.label).toContain("ANTAI");
    expect(amende.url).toContain("usagers.antai.gouv.fr");

    const suspension = portailEnLigne("SUSPENSION");
    expect(suspension.label).toContain("Télérecours");
    expect(suspension.url).toContain("citoyens.telerecours.fr");
  });

  it("organisme destinataire de l'envoi automatisé", () => {
    expect(organismeEnvoi("AMENDE")).toContain("ANTAI");
    expect(organismeEnvoi("SUSPENSION")).toContain("Télérecours");
  });

  it("canaux d'envoi restreints au type d'infraction", () => {
    expect(canauxEnvoi("AMENDE")).toEqual(["ANTAI", "LRAR"]);
    expect(canauxEnvoi("SUSPENSION")).toEqual(["TELERECOURS", "LRAR"]);
    // Jamais de Télérecours pour une amende, jamais d'ANTAI pour une suspension.
    expect(canauxEnvoi("AMENDE")).not.toContain("TELERECOURS");
    expect(canauxEnvoi("SUSPENSION")).not.toContain("ANTAI");
  });

  it("libellés de canal explicites", () => {
    expect(libelleCanal("ANTAI")).toContain("ANTAI");
    expect(libelleCanal("TELERECOURS")).toContain("Télérecours");
    expect(libelleCanal("LRAR")).toContain("recommandé");
  });

  it("libellé de canal depuis la valeur stockée, avec repli sur le défaut du type", () => {
    expect(libelleCanalDepuisStockage("LRAR", "AMENDE")).toContain("recommandé");
    expect(libelleCanalDepuisStockage(null, "AMENDE")).toContain("ANTAI");
    expect(libelleCanalDepuisStockage("", "SUSPENSION")).toContain("Télérecours");
  });
});

describe("envoi — formalisme de la lettre", () => {
  it("formule d'appel type-aware : neutre (amende) vs Monsieur le Préfet (suspension)", () => {
    expect(formuleAppel("AMENDE")).toBe("Madame, Monsieur,");
    expect(formuleAppel("SUSPENSION")).toBe("Monsieur le Préfet,");
  });

  it("formule de politesse professionnelle en clôture, alignée sur le destinataire", () => {
    expect(formulePolitesse("AMENDE")).toContain("considération distinguée");
    expect(formulePolitesse("SUSPENSION")).toContain("Monsieur le Préfet");
  });

  it("objet type-aware : avis de contravention vs décision de suspension", () => {
    expect(
      objetLettre({ type: "AMENDE", numRef: "123", dateRef: "2026-05-10" }),
    ).toBe("Contestation de l'avis de contravention n° 123 du 10 mai 2026");
    expect(
      objetLettre({ type: "SUSPENSION", numRef: "456", dateRef: "2026-07-01" }),
    ).toBe("Recours contre la décision de suspension n° 456 du 1er juillet 2026");
  });

  it("objet sans numéro ni date : pas de valeur fabriquée", () => {
    expect(objetLettre({ type: "AMENDE" })).toBe(
      "Contestation de l'avis de contravention",
    );
  });

  it("habillage complet : en-tête, Objet, Madame Monsieur, corps, politesse", () => {
    const lettre = formaterLettreOfficielle({
      type: "AMENDE",
      corps: "Je soussigné(e) DUPONT, conteste le PV 123.",
      numRef: "123",
      dateRef: "2026-05-10",
      nom: "DUPONT Jeanne",
      date: "2026-05-20",
    });
    expect(lettre.startsWith("DUPONT Jeanne")).toBe(true);
    expect(lettre).toContain("Monsieur l'Officier du ministère public");
    expect(lettre).toContain("Le 20 mai 2026");
    expect(lettre).toContain(
      "Objet : Contestation de l'avis de contravention n° 123 du 10 mai 2026",
    );
    // La liste des pièces jointes n'est jamais répliquée dans le corps
    // (éliminée ici : elle figure une seule fois, sous la signature, au PDF).
    expect(lettre).not.toContain("P.J.");
    expect(lettre).toContain("Madame, Monsieur,");
    expect(lettre).toContain("Je soussigné(e) DUPONT, conteste le PV 123.");
    expect(lettre.endsWith(formulePolitesse("AMENDE"))).toBe(true);
  });

  it("idempotent : une lettre déjà habillée n'est pas re-habillée", () => {
    const uneFois = formaterLettreOfficielle({
      type: "AMENDE",
      corps: "Je conteste le PV 123.",
    });
    const deuxFois = formaterLettreOfficielle({
      type: "AMENDE",
      corps: uneFois,
    });
    expect(deuxFois).toBe(uneFois);
    const nbObjets = deuxFois.split(/^Objet :/m).length - 1;
    expect(nbObjets).toBe(1);
    const nbPolitesses = deuxFois.split(formulePolitesse("AMENDE")).length - 1;
    expect(nbPolitesses).toBe(1);
  });

  it("en-tête destinataire type-aware : préfet pour une suspension (voie administrative)", () => {
    const lettre = formaterLettreOfficielle({
      type: "SUSPENSION",
      corps: "Je conteste la décision du 1er août 2026.",
      date: "2026-08-10",
    });
    expect(lettre).toContain("Monsieur le Préfet");
    expect(lettre).toContain("Le 10 août 2026");
    expect(lettre).toContain(
      "Objet : Recours contre la décision de suspension",
    );
  });

  it("aucune valeur inventée : pas d'adresse ni de date fabriquées", () => {
    const lettre = formaterLettreOfficielle({
      type: "AMENDE",
      corps: "Je conteste le PV.",
    });
    expect(lettre).not.toMatch(/adresse/i);
    expect(lettre.startsWith("Monsieur l'Officier du ministère public")).toBe(
      true,
    );
  });

  it("retourne une chaîne vide quand le corps est vide", () => {
    expect(formaterLettreOfficielle({ type: "AMENDE", corps: "  " })).toBe("");
  });
});
describe("envoi — destinataire par docType (lot H1)", () => {
  it("lireDocType : n'accepte que AMENDE / 3F / 48SI", () => {
    expect(lireDocType("3F")).toBe("3F");
    expect(lireDocType("48SI")).toBe("48SI");
    expect(lireDocType("AMENDE")).toBe("AMENDE");
    expect(lireDocType("INCONN")).toBeUndefined();
    expect(lireDocType(null)).toBeUndefined();
    expect(lireDocType(undefined)).toBeUndefined();
  });

  it("3F → le préfet (auteur de l'arrêté) ; 48SI → le ministre de l'Intérieur", () => {
    expect(formuleEnTeteDestinataire("SUSPENSION", "3F")).toBe(
      "Monsieur le Préfet",
    );
    expect(formuleEnTeteDestinataire("SUSPENSION", "48SI")).toBe(
      "Monsieur le Ministre de l'Intérieur",
    );
    // docType inconnu : repli prudent sur le préfet (défaut SUSPENSION).
    expect(formuleEnTeteDestinataire("SUSPENSION")).toBe("Monsieur le Préfet");
    expect(formuleAppel("SUSPENSION", "48SI")).toBe(
      "Monsieur le Ministre de l'Intérieur,",
    );
    expect(formuleAppel("SUSPENSION", "3F")).toBe("Monsieur le Préfet,");
    expect(formulePolitesse("SUSPENSION", "48SI")).toContain(
      "Monsieur le Ministre de l'Intérieur",
    );
  });

  it("LRAR 48SI : adresse de la notification, jamais « préfet »", () => {
    expect(destinataireLrar("SUSPENSION", "48SI")).toContain("notification");
    expect(destinataireLrar("SUSPENSION", "48SI")).not.toContain("préfet");
    expect(destinataireLrar("SUSPENSION", "3F")).toContain("préfet");
    expect(destinataireLrar("AMENDE", "AMENDE")).toContain("OMP");
  });

  it("lettre 48SI habillée au ministre, en-tête + appel + politesse alignés", () => {
    const lettre = formaterLettreOfficielle({
      type: "SUSPENSION",
      docType: "48SI",
      corps: "Je conteste l'invalidation pour solde de points nul.",
      numRef: "789",
      date: "2026-10-01",
    });
    expect(lettre).toContain("Monsieur le Ministre de l'Intérieur");
    expect(lettre).not.toContain("Monsieur le Préfet");
    expect(lettre.endsWith(formulePolitesse("SUSPENSION", "48SI"))).toBe(true);
    // Changement de docType = changement de destinataire : la lettre est
    // re-habillée au préfet (3F), sans double habilitation ni perte du corps.
    const relance = formaterLettreOfficielle({
      type: "SUSPENSION",
      docType: "3F",
      corps: lettre,
    });
    expect(relance).toContain("Monsieur le Préfet");
    expect(relance).not.toContain("Monsieur le Ministre de l'Intérieur");
    const corpsAttendu = "Je conteste l'invalidation pour solde de points nul.";
    expect(relance.split(corpsAttendu).length - 1).toBe(1);
    expect(relance.split("Objet :").length - 1).toBe(1);
  });

  it("non-régression amende : le docType ne change rien au tunnel 39 €", () => {
    const lettre = formaterLettreOfficielle({
      type: "AMENDE",
      docType: "AMENDE",
      corps: "Je conteste le PV 42.",
    });
    expect(lettre).toContain("Madame, Monsieur,");
    expect(lettre).toContain("Monsieur l'Officier du ministère public");
    expect(lettre.endsWith(formulePolitesse("AMENDE"))).toBe(true);
  });
});

describe("identiteExtrait — en-tête = identité OCR, profil en repli", () => {
  it("nom et adresse extraits du document sont retenus tels quels (trim)", () => {
    const id = identiteExtrait(
      { nom: " MARTIN Jean ", adresse: "12 RUE DE LA PAIX 75001 PARIS" },
      "Profil Autre",
    );
    expect(id.nom).toBe("MARTIN Jean");
    expect(id.adresse).toBe("12 RUE DE LA PAIX 75001 PARIS");
  });

  it("nom OCR prioritaire sur le nom du profil (User.name = repli)", () => {
    expect(identiteExtrait({ nom: "MARTIN Jean" }, "Profil Autre").nom).toBe(
      "MARTIN Jean",
    );
  });

  it("sans nom extrait, repli sur le profil — jamais de valeur fabriquée", () => {
    expect(identiteExtrait({}, "Jean Dupont").nom).toBe("Jean Dupont");
    expect(identiteExtrait({ adresse: "1 rue A 75001 PARIS" }, "Jean Dupont").nom).toBe(
      "Jean Dupont",
    );
  });

  it("chaînes vides ou blanches traitées comme absentes", () => {
    const id = identiteExtrait({ nom: "   ", adresse: "\t" }, "Jean Dupont");
    expect(id.nom).toBe("Jean Dupont");
    expect(id.adresse).toBeNull();
  });

  it("tout absent : null des deux côtés (l'en-tête omet simplement les lignes)", () => {
    expect(identiteExtrait(null, null)).toEqual({ nom: null, adresse: null });
    expect(identiteExtrait(undefined, undefined)).toEqual({
      nom: null,
      adresse: null,
    });
    expect(identiteExtrait({}, "").nom).toBeNull();
  });

  it("type non objet (défensif) : repli profil, aucun crash", () => {
    expect(identiteExtrait("oops", "Jean Dupont").nom).toBe("Jean Dupont");
    expect(identiteExtrait(42, null)).toEqual({ nom: null, adresse: null });
  });

  it("l'habillage place bien l'identité extraite en tête de lettre", () => {
    const lettre = formaterLettreOfficielle({
      type: "AMENDE",
      corps: "Je conteste le PV 42.",
      ...identiteExtrait(
        { nom: "MARTIN Jean", adresse: "12 RUE DE LA PAIX 75001 PARIS" },
        "Jean Dupont",
      ),
      date: "2026-10-12",
    });
    expect(lettre.startsWith("MARTIN Jean\n12 RUE DE LA PAIX 75001 PARIS")).toBe(
      true,
    );
    expect(lettre).not.toContain("Jean Dupont");
  });
});

describe("envoi — requête contentieuse (REP, Télérecours)", () => {
  const corps = "Je soussigné(e) DUPONT, conteste la décision de suspension.";

  it("civiliteJugeAdministratif sans tribunal : générique, sans ville inventée", () => {
    expect(civiliteJugeAdministratif()).toContain("Tribunal administratif");
    expect(civiliteJugeAdministratif()).toContain("Président");
    expect(civiliteJugeAdministratif()).not.toContain("Tribunal administratif de ");
    expect(titreRequete()).toContain("EXCÈS DE POUVOIR");
  });

  it("suspension + TELERECOURS : titre de requête + destinataire TA + politesse juge", () => {
    const lettre = formaterLettreOfficielle({
      type: "SUSPENSION",
      canal: "TELERECOURS",
      corps,
      numRef: "456",
      date: "2026-10-20",
    });
    expect(lettre).toContain(titreRequete());
    expect(lettre).toContain("Tribunal administratif");
    expect(lettre).not.toContain("Monsieur le Préfet");
    expect(lettre).not.toContain("Monsieur le Ministre");
    expect(lettre).toContain("Monsieur le Président");
    expect(lettre).toContain(
      "Objet : Recours contre la décision de suspension n° 456",
    );
    expect(lettre.endsWith(formulePolitesse("SUSPENSION", null, true))).toBe(
      true,
    );
  });

  it("suspension + TELERECOURS : TA nommé d'après le département de l'adresse", () => {
    const lettre = formaterLettreOfficielle({
      type: "SUSPENSION",
      canal: "TELERECOURS",
      corps,
      adresse: "12 RUE DE LA PAIX 69001 LYON",
      numRef: "456",
      date: "2026-10-20",
    });
    expect(lettre).toContain("Tribunal administratif de Lyon");
    // Sans adresse exploitable : formule générique, aucune ville inventée.
    const sansAdresse = formaterLettreOfficielle({
      type: "SUSPENSION",
      canal: "TELERECOURS",
      corps,
    });
    expect(sansAdresse).toContain("Tribunal administratif");
    expect(sansAdresse).not.toContain("Tribunal administratif de");
  });

  it("suspension + LRAR : reste à l'administration (préfet), pas de titre de requête", () => {
    const lettre = formaterLettreOfficielle({
      type: "SUSPENSION",
      canal: "LRAR",
      corps,
    });
    expect(lettre).toContain("Monsieur le Préfet");
    expect(lettre).not.toContain(titreRequete());
    expect(lettre).not.toContain("Tribunal administratif");
  });

  it("amende : le canal TELERECOURS ne détourne jamais la lettre vers le juge", () => {
    const lettre = formaterLettreOfficielle({
      type: "AMENDE",
      canal: "TELERECOURS",
      corps: "Je conteste le PV 42.",
    });
    expect(lettre).toContain("Monsieur l'Officier du ministère public");
    expect(lettre).not.toContain("Tribunal administratif");
  });

  it("ré-habilitation : une lettre au préfet convertie en requête vise le TA, sans perdre le corps", () => {
    const auPrefet = formaterLettreOfficielle({
      type: "SUSPENSION",
      canal: "LRAR",
      corps,
      numRef: "456",
      date: "2026-10-20",
    });
    const requete = formaterLettreOfficielle({
      type: "SUSPENSION",
      canal: "TELERECOURS",
      corps: auPrefet,
      numRef: "456",
      date: "2026-10-20",
    });
    expect(requete).toContain("Tribunal administratif");
    expect(requete).not.toContain("Monsieur le Préfet");
    // Le corps d'origine est conservé, une seule fois.
    expect(requete.split(corps).length - 1).toBe(1);
    // Re-habillage idempotent une fois au bon destinataire.
    const relance = formaterLettreOfficielle({
      type: "SUSPENSION",
      canal: "TELERECOURS",
      corps: requete,
      numRef: "456",
      date: "2026-10-20",
    });
    expect(relance).toBe(requete);
    expect(relance.split(titreRequete()).length - 1).toBe(1);
  });

  it("corpsDepuisLettreHabillee : extrait le corps entre appel et politesse", () => {
    expect(corpsDepuisLettreHabillee(corps)).toBe(corps);
    const habillee = formaterLettreOfficielle({
      type: "SUSPENSION",
      canal: "LRAR",
      corps,
    });
    expect(corpsDepuisLettreHabillee(habillee)).toBe(corps);
  });
});
